
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// dist/server/assets/_tanstack-start-manifest_v-1I4XAs5H.js
var tanstack_start_manifest_v_1I4XAs5H_exports = {};
__export(tanstack_start_manifest_v_1I4XAs5H_exports, {
  tsrStartManifest: () => tsrStartManifest
});
var tsrStartManifest;
var init_tanstack_start_manifest_v_1I4XAs5H = __esm({
  "dist/server/assets/_tanstack-start-manifest_v-1I4XAs5H.js"() {
    "use strict";
    tsrStartManifest = () => ({ "routes": { "__root__": { "filePath": "/Users/anle/Downloads/AI/WBA/HACK/start-bare/src/routes/__root.tsx", "children": ["/", "/(authenticated)", "/email/invitation-response", "/login/callback", "/login/", "/api/auth/$"], "preloads": ["/assets/main-BADtD3-T.js"], "assets": [{ "tag": "link", "attrs": { "rel": "stylesheet", "href": "/assets/main-DteXXvTD.css", "type": "text/css" } }] }, "/": { "filePath": "/Users/anle/Downloads/AI/WBA/HACK/start-bare/src/routes/index.tsx", "assets": [{ "tag": "link", "attrs": { "rel": "stylesheet", "href": "/assets/main-DteXXvTD.css", "type": "text/css" } }], "preloads": ["/assets/index-I7KpuGZI.js", "/assets/proxy-kEPjn12I.js", "/assets/check-CoL3VF1r.js", "/assets/play-BVT3LOk7.js", "/assets/message-square-B8chCekx.js"] }, "/(authenticated)": { "filePath": "/Users/anle/Downloads/AI/WBA/HACK/start-bare/src/routes/(authenticated)/route.tsx", "children": ["/(authenticated)/live", "/(authenticated)/project", "/(authenticated)/refine"], "assets": [{ "tag": "link", "attrs": { "rel": "stylesheet", "href": "/assets/main-DteXXvTD.css", "type": "text/css" } }], "preloads": ["/assets/route-2hHvQ-XD.js"] }, "/(authenticated)/live": { "filePath": "/Users/anle/Downloads/AI/WBA/HACK/start-bare/src/routes/(authenticated)/live.tsx", "parent": "/(authenticated)", "assets": [{ "tag": "link", "attrs": { "rel": "stylesheet", "href": "/assets/main-DteXXvTD.css", "type": "text/css" } }], "preloads": ["/assets/live-D65i7fbH.js", "/assets/select-B8Rh0z0d.js", "/assets/checkbox-DzOHLd4S.js", "/assets/play-BVT3LOk7.js", "/assets/check-CoL3VF1r.js"] }, "/(authenticated)/project": { "filePath": "/Users/anle/Downloads/AI/WBA/HACK/start-bare/src/routes/(authenticated)/project.tsx", "parent": "/(authenticated)", "assets": [{ "tag": "link", "attrs": { "rel": "stylesheet", "href": "/assets/main-DteXXvTD.css", "type": "text/css" } }], "preloads": ["/assets/project-BM0HOMlD.js", "/assets/select-B8Rh0z0d.js", "/assets/task-card-wqD7Du2p.js", "/assets/checkbox-DzOHLd4S.js", "/assets/check-CoL3VF1r.js", "/assets/proxy-kEPjn12I.js", "/assets/message-square-B8chCekx.js"] }, "/(authenticated)/refine": { "filePath": "/Users/anle/Downloads/AI/WBA/HACK/start-bare/src/routes/(authenticated)/refine.tsx", "parent": "/(authenticated)", "assets": [{ "tag": "link", "attrs": { "rel": "stylesheet", "href": "/assets/main-DteXXvTD.css", "type": "text/css" } }], "preloads": ["/assets/refine-Dzh-Ixc6.js", "/assets/select-B8Rh0z0d.js", "/assets/task-card-wqD7Du2p.js", "/assets/message-square-B8chCekx.js", "/assets/check-CoL3VF1r.js"] }, "/login/callback": { "filePath": "/Users/anle/Downloads/AI/WBA/HACK/start-bare/src/routes/login/callback.tsx", "assets": [{ "tag": "link", "attrs": { "rel": "stylesheet", "href": "/assets/main-DteXXvTD.css", "type": "text/css" } }], "preloads": ["/assets/callback-BDaTo2pF.js"] }, "/login/": { "filePath": "/Users/anle/Downloads/AI/WBA/HACK/start-bare/src/routes/login/index.tsx", "assets": [{ "tag": "link", "attrs": { "rel": "stylesheet", "href": "/assets/main-DteXXvTD.css", "type": "text/css" } }], "preloads": ["/assets/index-B66QvQqd.js"] } }, "clientEntry": "/assets/main-BADtD3-T.js" });
  }
});

// dist/server/assets/app-header-DDCic_DU.js
import { jsx, jsxs } from "react/jsx-runtime";
import { useState, useEffect, useMemo } from "react";
import { useNavigate, Link, ClientOnly, useRouterState } from "@tanstack/react-router";
import { User, ChevronDown, Mail, LogOut, XIcon, Menu } from "lucide-react";
import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { createAuthClient } from "better-auth/react";
import { convexClient } from "@convex-dev/better-auth/client/plugins";
import * as DropdownMenuPrimitive from "@radix-ui/react-dropdown-menu";
import { Slot } from "@radix-ui/react-slot";
import { cva } from "class-variance-authority";
import * as AvatarPrimitive from "@radix-ui/react-avatar";
import * as SheetPrimitive from "@radix-ui/react-dialog";
import { VisuallyHidden } from "@radix-ui/react-visually-hidden";
function getBaseURL() {
  if (typeof window !== "undefined") {
    return window.location.origin;
  }
  return process.env.SITE_URL || process.env.CONVEX_SITE_URL || "http://localhost:3000";
}
function cn(...inputs) {
  return twMerge(clsx(inputs));
}
function DropdownMenu({
  ...props
}) {
  return /* @__PURE__ */ jsx(DropdownMenuPrimitive.Root, { "data-slot": "dropdown-menu", ...props });
}
function DropdownMenuTrigger({
  ...props
}) {
  return /* @__PURE__ */ jsx(
    DropdownMenuPrimitive.Trigger,
    {
      "data-slot": "dropdown-menu-trigger",
      ...props
    }
  );
}
function DropdownMenuContent({
  className,
  sideOffset = 4,
  ...props
}) {
  return /* @__PURE__ */ jsx(DropdownMenuPrimitive.Portal, { children: /* @__PURE__ */ jsx(
    DropdownMenuPrimitive.Content,
    {
      "data-slot": "dropdown-menu-content",
      sideOffset,
      className: cn(
        "bg-popover text-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 max-h-(--radix-dropdown-menu-content-available-height) min-w-[8rem] origin-(--radix-dropdown-menu-content-transform-origin) overflow-x-hidden overflow-y-auto rounded-md border p-1 shadow-md",
        className
      ),
      ...props
    }
  ) });
}
function DropdownMenuItem({
  className,
  inset,
  variant = "default",
  ...props
}) {
  return /* @__PURE__ */ jsx(
    DropdownMenuPrimitive.Item,
    {
      "data-slot": "dropdown-menu-item",
      "data-inset": inset,
      "data-variant": variant,
      className: cn(
        "focus:bg-accent focus:text-accent-foreground data-[variant=destructive]:text-destructive data-[variant=destructive]:focus:bg-destructive/10 dark:data-[variant=destructive]:focus:bg-destructive/20 data-[variant=destructive]:focus:text-destructive data-[variant=destructive]:*:[svg]:!text-destructive [&_svg:not([class*='text-'])]:text-muted-foreground relative flex cursor-default items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 data-[inset]:pl-8 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
        className
      ),
      ...props
    }
  );
}
function DropdownMenuLabel({
  className,
  inset,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    DropdownMenuPrimitive.Label,
    {
      "data-slot": "dropdown-menu-label",
      "data-inset": inset,
      className: cn(
        "px-2 py-1.5 text-sm font-medium data-[inset]:pl-8",
        className
      ),
      ...props
    }
  );
}
function DropdownMenuSeparator({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    DropdownMenuPrimitive.Separator,
    {
      "data-slot": "dropdown-menu-separator",
      className: cn("bg-border -mx-1 my-1 h-px", className),
      ...props
    }
  );
}
function Button({
  className,
  variant,
  size,
  asChild = false,
  ...props
}) {
  const Comp = asChild ? Slot : "button";
  return /* @__PURE__ */ jsx(
    Comp,
    {
      "data-slot": "button",
      className: cn(buttonVariants({ variant, size, className })),
      ...props
    }
  );
}
function Skeleton({ className, ...props }) {
  return /* @__PURE__ */ jsx(
    "div",
    {
      "data-slot": "skeleton",
      className: cn("bg-accent animate-pulse rounded-md", className),
      ...props
    }
  );
}
function Avatar({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    AvatarPrimitive.Root,
    {
      "data-slot": "avatar",
      className: cn(
        "relative flex size-8 shrink-0 overflow-hidden rounded-full",
        className
      ),
      ...props
    }
  );
}
function AvatarImage({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    AvatarPrimitive.Image,
    {
      "data-slot": "avatar-image",
      className: cn("aspect-square size-full", className),
      ...props
    }
  );
}
function AvatarFallback({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    AvatarPrimitive.Fallback,
    {
      "data-slot": "avatar-fallback",
      className: cn(
        "bg-muted flex size-full items-center justify-center rounded-full",
        className
      ),
      ...props
    }
  );
}
function AppUserMenu() {
  const navigate = useNavigate();
  const { data: session, isPending } = authClient.useSession();
  const getInitials = (name) => name.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2);
  if (isPending) {
    return /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ jsx(Skeleton, { className: "h-8 w-8 animate-pulse rounded-full bg-muted" }),
      /* @__PURE__ */ jsxs("div", { className: "hidden sm:flex flex-col gap-1", children: [
        /* @__PURE__ */ jsx(Skeleton, { className: "h-3 w-16 animate-pulse bg-muted" }),
        /* @__PURE__ */ jsx(Skeleton, { className: "h-2 w-12 animate-pulse bg-muted" })
      ] })
    ] });
  }
  if (!session) {
    return /* @__PURE__ */ jsx(
      Button,
      {
        variant: "outline",
        asChild: true,
        className: "border-border bg-background text-foreground shadow-sm transition-colors hover:bg-accent hover:text-accent-foreground",
        children: /* @__PURE__ */ jsxs(Link, { to: "/login", className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(User, { className: "h-4 w-4" }),
          "Sign In"
        ] })
      }
    );
  }
  return /* @__PURE__ */ jsxs(DropdownMenu, { children: [
    /* @__PURE__ */ jsx(DropdownMenuTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(
      Button,
      {
        variant: "ghost",
        className: "flex items-center gap-3 rounded-full border border-border/60 bg-white/80 px-3 py-2 text-sm font-medium shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md hover:bg-white/95 dark:border-slate-700/50 dark:bg-slate-800/90 dark:hover:bg-slate-800",
        children: [
          /* @__PURE__ */ jsxs(Avatar, { className: "h-8 w-8", children: [
            /* @__PURE__ */ jsx(
              AvatarImage,
              {
                src: session.user.image || void 0,
                alt: session.user.name || "User avatar",
                onError: (event) => {
                  event.currentTarget.style.display = "none";
                }
              }
            ),
            /* @__PURE__ */ jsx(AvatarFallback, { className: "bg-sky-600 text-xs font-medium text-white", children: getInitials(session.user.name || "U") })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "hidden text-left sm:flex sm:flex-col", children: [
            /* @__PURE__ */ jsx("span", { className: "text-sm font-medium leading-tight", children: session.user.name }),
            /* @__PURE__ */ jsx("span", { className: "mt-0.5 text-xs text-muted-foreground leading-tight", children: "Account" })
          ] }),
          /* @__PURE__ */ jsx(ChevronDown, { className: "h-4 w-4 text-muted-foreground" })
        ]
      }
    ) }),
    /* @__PURE__ */ jsxs(
      DropdownMenuContent,
      {
        className: "w-64 rounded-xl border border-slate-200/80 bg-white/95 p-1 shadow-2xl ring-1 ring-black/5 dark:border-slate-700/50 dark:bg-slate-800 dark:ring-slate-700/20",
        align: "end",
        sideOffset: 8,
        children: [
          /* @__PURE__ */ jsx(DropdownMenuLabel, { className: "px-3 py-2 text-sm font-medium", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(User, { className: "h-4 w-4" }),
            "My Account"
          ] }) }),
          /* @__PURE__ */ jsx(DropdownMenuSeparator, {}),
          /* @__PURE__ */ jsx("div", { className: "px-3 py-2", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxs(Avatar, { className: "h-10 w-10", children: [
              /* @__PURE__ */ jsx(
                AvatarImage,
                {
                  src: session.user.image || void 0,
                  alt: session.user.name || "User avatar",
                  onError: (event) => {
                    event.currentTarget.style.display = "none";
                  }
                }
              ),
              /* @__PURE__ */ jsx(AvatarFallback, { className: "bg-sky-600 text-white", children: getInitials(session.user.name || "U") })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex flex-col", children: [
              /* @__PURE__ */ jsx("span", { className: "text-sm font-medium", children: session.user.name }),
              /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-1 text-xs text-muted-foreground", children: [
                /* @__PURE__ */ jsx(Mail, { className: "h-3 w-3" }),
                session.user.email
              ] })
            ] })
          ] }) }),
          /* @__PURE__ */ jsx(DropdownMenuSeparator, {}),
          /* @__PURE__ */ jsx(DropdownMenuItem, { asChild: true, className: "p-0", children: /* @__PURE__ */ jsxs(
            Button,
            {
              variant: "ghost",
              className: "h-auto w-full justify-start gap-2 px-3 py-2 text-destructive transition-colors hover:bg-destructive/10 hover:text-destructive",
              onClick: async () => {
                try {
                  await authClient.signOut();
                  navigate({ to: "/" });
                } catch (error) {
                  console.error("Sign out failed:", error);
                }
              },
              children: [
                /* @__PURE__ */ jsx(LogOut, { className: "h-4 w-4" }),
                "Sign Out"
              ]
            }
          ) })
        ]
      }
    )
  ] });
}
function DarkModeToggle() {
  const [isDark, setIsDark] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);
  const toggleDarkMode = () => {
    setIsAnimating(true);
    const html = document.documentElement;
    const next = !isDark;
    html.classList.toggle("dark", next);
    setIsDark(next);
    localStorage.setItem("theme", next ? "dark" : "light");
    setTimeout(() => setIsAnimating(false), 300);
  };
  useEffect(() => {
    const stored = localStorage.getItem("theme");
    const prefersDark = window.matchMedia(
      "(prefers-color-scheme: dark)"
    ).matches;
    const shouldUseDark = stored === "dark" || !stored && prefersDark;
    document.documentElement.classList.toggle("dark", shouldUseDark);
    setIsDark(shouldUseDark);
  }, []);
  return /* @__PURE__ */ jsx("div", { className: "relative", children: /* @__PURE__ */ jsx(
    "button",
    {
      onClick: toggleDarkMode,
      type: "button",
      role: "switch",
      "aria-checked": isDark,
      "aria-label": "Toggle dark mode",
      tabIndex: 0,
      className: `
          relative inline-flex items-center w-11 h-6 rounded-full p-0
          bg-zinc-300 dark:bg-zinc-700
          border border-transparent
          transition-colors duration-300 ease-out
          appearance-none
          focus:outline-none focus:ring-0 focus:ring-offset-0
          hover:scale-[1.02] active:scale-[0.98]
        `,
      style: {
        WebkitTapHighlightColor: "transparent",
        transition: "all 300ms ease"
      },
      children: /* @__PURE__ */ jsxs(
        "div",
        {
          className: "w-5 h-5 bg-white dark:bg-zinc-100 rounded-full shadow-sm transform transition-all duration-300 ease-out relative",
          style: {
            transform: `translateX(${isDark ? "20px" : "0"}) ${isAnimating ? "scale(0.95)" : "scale(1)"}`
          },
          children: [
            /* @__PURE__ */ jsx(
              "div",
              {
                className: "absolute inset-0 flex items-center justify-center transition-opacity duration-200 ease-out",
                style: {
                  opacity: isDark ? 0 : 1,
                  transform: `rotate(${isDark ? "180deg" : "0"}) scale(${isDark ? 0 : 1})`,
                  transition: "all 200ms ease-out"
                },
                children: /* @__PURE__ */ jsx(
                  "svg",
                  {
                    className: "w-3 h-3 text-gray-600 dark:text-gray-600",
                    viewBox: "0 0 20 20",
                    fill: "currentColor",
                    children: /* @__PURE__ */ jsx(
                      "path",
                      {
                        fillRule: "evenodd",
                        d: "M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 000 2h1z",
                        clipRule: "evenodd"
                      }
                    )
                  }
                )
              }
            ),
            /* @__PURE__ */ jsx(
              "div",
              {
                className: "absolute inset-0 flex items-center justify-center transition-opacity duration-200 ease-out",
                style: {
                  opacity: isDark ? 1 : 0,
                  transform: `rotate(${isDark ? 0 : -180}deg) scale(${isDark ? 1 : 0})`,
                  transition: "all 200ms ease-out"
                },
                children: /* @__PURE__ */ jsx(
                  "svg",
                  {
                    className: "w-3 h-3 text-gray-600 dark:text-gray-600",
                    viewBox: "0 0 20 20",
                    fill: "currentColor",
                    children: /* @__PURE__ */ jsx("path", { d: "M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z" })
                  }
                )
              }
            )
          ]
        }
      )
    }
  ) });
}
function Sheet({ ...props }) {
  return /* @__PURE__ */ jsx(SheetPrimitive.Root, { "data-slot": "sheet", ...props });
}
function SheetTrigger({
  ...props
}) {
  return /* @__PURE__ */ jsx(SheetPrimitive.Trigger, { "data-slot": "sheet-trigger", ...props });
}
function SheetPortal({
  ...props
}) {
  return /* @__PURE__ */ jsx(SheetPrimitive.Portal, { "data-slot": "sheet-portal", ...props });
}
function SheetOverlay({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    SheetPrimitive.Overlay,
    {
      "data-slot": "sheet-overlay",
      className: cn(
        "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 fixed inset-0 z-50 bg-black/50",
        className
      ),
      ...props
    }
  );
}
function SheetContent({
  className,
  children,
  side = "right",
  ...props
}) {
  return /* @__PURE__ */ jsxs(SheetPortal, { children: [
    /* @__PURE__ */ jsx(SheetOverlay, {}),
    /* @__PURE__ */ jsxs(
      SheetPrimitive.Content,
      {
        "data-slot": "sheet-content",
        className: cn(
          "bg-background data-[state=open]:animate-in data-[state=closed]:animate-out fixed z-50 flex flex-col gap-4 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500",
          side === "right" && "data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right inset-y-0 right-0 h-full w-3/4 border-l sm:max-w-sm",
          side === "left" && "data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left inset-y-0 left-0 h-full w-3/4 border-r sm:max-w-sm",
          side === "top" && "data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top inset-x-0 top-0 h-auto border-b",
          side === "bottom" && "data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom inset-x-0 bottom-0 h-auto border-t",
          className
        ),
        ...props,
        children: [
          children,
          /* @__PURE__ */ jsxs(SheetPrimitive.Close, { className: "ring-offset-background focus:ring-ring data-[state=open]:bg-secondary absolute top-4 right-4 rounded-xs opacity-70 transition-opacity hover:opacity-100 focus:ring-2 focus:ring-offset-2 focus:outline-hidden disabled:pointer-events-none", children: [
            /* @__PURE__ */ jsx(XIcon, { className: "size-4" }),
            /* @__PURE__ */ jsx("span", { className: "sr-only", children: "Close" })
          ] })
        ]
      }
    )
  ] });
}
function SheetTitle({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    SheetPrimitive.Title,
    {
      "data-slot": "sheet-title",
      className: cn("text-foreground font-semibold", className),
      ...props
    }
  );
}
function SheetDescription({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    SheetPrimitive.Description,
    {
      "data-slot": "sheet-description",
      className: cn("text-muted-foreground text-sm", className),
      ...props
    }
  );
}
function AppLogo() {
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
    /* @__PURE__ */ jsx("div", { className: "relative flex-shrink-0", children: /* @__PURE__ */ jsx("div", { className: "flex h-10 w-10 items-center justify-center rounded-2xl overflow-hidden shadow-lg", children: /* @__PURE__ */ jsx(
      "img",
      {
        src: "/CG.png",
        alt: "CoGrind Logo",
        className: "h-full w-full object-contain"
      }
    ) }) }),
    /* @__PURE__ */ jsx("div", { className: "hidden sm:block flex-shrink-0", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col", children: [
      /* @__PURE__ */ jsx("span", { className: "text-xl font-bold tracking-tight text-transparent bg-gradient-to-r from-blue-500 via-purple-500 via-pink-500 to-rose-500 bg-clip-text drop-shadow-sm", children: "CoGrind" }),
      /* @__PURE__ */ jsx("span", { className: "text-[10px] font-medium tracking-wider text-muted-foreground/70 uppercase", children: "Collaborate. Execute. Deliver." })
    ] }) })
  ] });
}
function NavigationLinks({
  className = "",
  onLinkClick,
  showRing = true
}) {
  const router2 = useRouterState();
  const currentPath = router2.location.pathname;
  const { data: session } = authClient.useSession();
  const links = useMemo(() => {
    return NAV_LINKS;
  }, []);
  return /* @__PURE__ */ jsx("div", { className: "flex w-full justify-center", children: /* @__PURE__ */ jsx(
    "nav",
    {
      className: cn(
        "relative flex w-full max-w-md items-center justify-center gap-1 rounded-full",
        "px-1 py-1",
        showRing && "bg-muted/70 ring-1 ring-border/60 shadow-[0_10px_30px_-20px_rgba(15,23,42,0.45)] backdrop-blur-md",
        className
      ),
      children: links.map(({ to, label }) => {
        const isActive = currentPath === to || to !== "/" && currentPath.startsWith(to);
        return /* @__PURE__ */ jsxs(
          Link,
          {
            to,
            onClick: onLinkClick,
            className: cn(
              "relative z-10 rounded-full px-3 py-2 text-sm font-semibold tracking-wide transition-all",
              "hover:bg-foreground/10 hover:text-foreground",
              isActive ? "bg-background text-foreground shadow-sm ring-1 ring-border" : "text-muted-foreground"
            ),
            children: [
              label,
              isActive && /* @__PURE__ */ jsx("span", { className: "absolute -bottom-1 left-1/2 h-1.5 w-1.5 -translate-x-1/2 rounded-full bg-primary" })
            ]
          },
          to
        );
      })
    }
  ) });
}
function MobileNav() {
  const [isOpen, setIsOpen] = useState(false);
  return /* @__PURE__ */ jsxs(Sheet, { open: isOpen, onOpenChange: setIsOpen, children: [
    /* @__PURE__ */ jsx(SheetTrigger, { asChild: true, className: "md:hidden", children: /* @__PURE__ */ jsxs(
      Button,
      {
        variant: "ghost",
        size: "icon",
        className: "rounded-full border border-border/60 bg-background/60 shadow-sm backdrop-blur hover:bg-background/90",
        children: [
          /* @__PURE__ */ jsx(Menu, { className: "h-5 w-5" }),
          /* @__PURE__ */ jsx("span", { className: "sr-only", children: "Toggle menu" })
        ]
      }
    ) }),
    /* @__PURE__ */ jsxs(SheetContent, { side: "left", className: "w-72", children: [
      /* @__PURE__ */ jsx(VisuallyHidden, { asChild: true, children: /* @__PURE__ */ jsx(SheetTitle, { children: "Navigation" }) }),
      /* @__PURE__ */ jsx(VisuallyHidden, { asChild: true, children: /* @__PURE__ */ jsx(SheetDescription, { children: "Application primary navigation" }) }),
      /* @__PURE__ */ jsxs("div", { className: "mt-8 flex flex-col gap-6", children: [
        /* @__PURE__ */ jsx(
          Link,
          {
            to: "/",
            onClick: () => setIsOpen(false),
            className: "flex items-center gap-3",
            children: /* @__PURE__ */ jsx(AppLogo, {})
          }
        ),
        /* @__PURE__ */ jsx(
          NavigationLinks,
          {
            className: "flex-col gap-2 rounded-2xl bg-muted/60 px-3 py-3 shadow-inner",
            onLinkClick: () => setIsOpen(false),
            showRing: false
          }
        )
      ] })
    ] })
  ] });
}
function AppHeader() {
  return /* @__PURE__ */ jsx("header", { className: "sticky top-0 z-50 w-full border-b border-border/60 bg-gradient-to-r from-background via-background/95 to-background/90 shadow-lg shadow-black/5 backdrop-blur-xl supports-[backdrop-filter]:bg-background/70", children: /* @__PURE__ */ jsx("div", { className: "w-full px-4 sm:px-6 lg:px-10", children: /* @__PURE__ */ jsxs("div", { className: "flex h-20 items-center justify-between", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4 pl-2 sm:pl-4 lg:pl-6", children: [
      /* @__PURE__ */ jsx(MobileNav, {}),
      /* @__PURE__ */ jsx(
        Link,
        {
          to: "/",
          className: "flex-shrink-0 rounded-full bg-background/60 p-1 transition-opacity duration-200 hover:opacity-90",
          children: /* @__PURE__ */ jsx(AppLogo, {})
        }
      )
    ] }),
    /* @__PURE__ */ jsx("div", { className: "hidden flex-1 justify-center md:flex", children: /* @__PURE__ */ jsx(NavigationLinks, {}) }),
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-end gap-3 pr-2 sm:pr-4 lg:pr-6 md:gap-4", children: [
      /* @__PURE__ */ jsx(ClientOnly, { fallback: /* @__PURE__ */ jsx("div", { className: "h-10 w-10" }), children: /* @__PURE__ */ jsx(DarkModeToggle, {}) }),
      /* @__PURE__ */ jsx(ClientOnly, { fallback: /* @__PURE__ */ jsx("div", { className: "h-10 w-10" }), children: /* @__PURE__ */ jsx(AppUserMenu, {}) })
    ] })
  ] }) }) });
}
var authClient, buttonVariants, NAV_LINKS;
var init_app_header_DDCic_DU = __esm({
  "dist/server/assets/app-header-DDCic_DU.js"() {
    "use strict";
    authClient = createAuthClient({
      baseURL: getBaseURL(),
      plugins: [convexClient()]
    });
    buttonVariants = cva(
      "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",
      {
        variants: {
          variant: {
            default: "bg-primary text-primary-foreground hover:bg-primary/90",
            destructive: "bg-destructive text-white hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",
            outline: "border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50",
            secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
            ghost: "hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",
            link: "text-primary underline-offset-4 hover:underline"
          },
          size: {
            default: "h-9 px-4 py-2 has-[>svg]:px-3",
            sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
            lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
            icon: "size-9",
            "icon-sm": "size-8",
            "icon-lg": "size-10"
          }
        },
        defaultVariants: {
          variant: "default",
          size: "default"
        }
      }
    );
    NAV_LINKS = [
      { to: "/", label: "Home" },
      { to: "/project", label: "Project" },
      { to: "/live", label: "Live Run" },
      { to: "/refine", label: "Review" }
    ];
  }
});

// dist/server/assets/api-DiONElen.js
import { anyApi, componentsGeneric } from "convex/server";
var api, components;
var init_api_DiONElen = __esm({
  "dist/server/assets/api-DiONElen.js"() {
    "use strict";
    api = anyApi;
    components = componentsGeneric();
  }
});

// dist/server/assets/auth-BOVWFHt3.js
var auth_BOVWFHt3_exports = {};
__export(auth_BOVWFHt3_exports, {
  authComponent: () => authComponent,
  createAuth: () => createAuth
});
import { createClient } from "@convex-dev/better-auth";
import { convex } from "@convex-dev/better-auth/plugins";
import { queryGeneric } from "convex/server";
import { betterAuth } from "better-auth";
function getEnvVar(key, fallback = "") {
  return process.env[key] || fallback;
}
function buildSocialProviders() {
  const providers = {};
  if (githubCredentials.id && githubCredentials.secret) {
    providers.github = {
      clientId: githubCredentials.id,
      clientSecret: githubCredentials.secret
    };
    console.log("GitHub OAuth provider configured");
  } else {
    console.warn("GitHub OAuth provider not configured - missing credentials");
  }
  if (googleCredentials.id && googleCredentials.secret) {
    providers.google = {
      clientId: googleCredentials.id,
      clientSecret: googleCredentials.secret
    };
    console.log("Google OAuth provider configured");
  } else {
    console.warn("Google OAuth provider not configured - missing credentials", {
      hasId: !!googleCredentials.id,
      hasSecret: !!googleCredentials.secret
    });
  }
  console.log("Social providers configured:", Object.keys(providers));
  return providers;
}
var query, siteUrl, githubCredentials, googleCredentials, authComponent, createAuth;
var init_auth_BOVWFHt3 = __esm({
  "dist/server/assets/auth-BOVWFHt3.js"() {
    "use strict";
    init_api_DiONElen();
    query = queryGeneric;
    siteUrl = getEnvVar("SITE_URL") || getEnvVar("CONVEX_SITE_URL") || "http://localhost:3000";
    console.log("Better Auth baseURL:", siteUrl, {
      hasCustomSiteUrl: !!process.env.SITE_URL,
      hasBuiltInConvexSiteUrl: !!process.env.CONVEX_SITE_URL
    });
    githubCredentials = {
      id: getEnvVar("GITHUB_CLIENT_ID"),
      secret: getEnvVar("GITHUB_CLIENT_SECRET")
    };
    googleCredentials = {
      id: getEnvVar("GOOGLE_CLIENT_ID"),
      secret: getEnvVar("GOOGLE_CLIENT_SECRET")
    };
    authComponent = createClient(components.betterAuth);
    createAuth = (ctx, { optionsOnly = false } = {}) => {
      const socialProviders = buildSocialProviders();
      console.log("Creating Better Auth instance with:", {
        baseURL: siteUrl,
        socialProviders: Object.keys(socialProviders),
        hasEmailPassword: true
      });
      return betterAuth({
        logger: { disabled: optionsOnly },
        baseURL: siteUrl,
        database: authComponent.adapter(ctx),
        emailAndPassword: {
          enabled: true,
          requireEmailVerification: false
        },
        socialProviders,
        plugins: [convex()]
      });
    };
    query({
      args: {},
      handler: async (ctx) => {
        return authComponent.getAuthUser(ctx);
      }
    });
    query({
      args: {},
      handler: async (ctx) => {
        const result = await ctx.runQuery(components.betterAuth.adapter.findMany, {
          model: "user",
          paginationOpts: { numItems: 100, cursor: null }
        });
        return result.page;
      }
    });
  }
});

// dist/server/assets/__root-B0zzklJl.js
var root_B0zzklJl_exports = {};
__export(root_B0zzklJl_exports, {
  fetchAuth_createServerFn_handler: () => fetchAuth_createServerFn_handler
});
import { jsx as jsx2, jsxs as jsxs2 } from "react/jsx-runtime";
import { createRootRouteWithContext, useRouteContext, Outlet, HeadContent, Scripts } from "@tanstack/react-router";
import { ConvexBetterAuthProvider } from "@convex-dev/better-auth/react";
import { fetchSession, getCookieName } from "@convex-dev/better-auth/react-start";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core";
import "@tanstack/router-core/ssr/server";
import "h3-v2";
import "tiny-invariant";
import "seroval";
import "@tanstack/react-router/ssr/server";
import "react";
import "lucide-react";
import "clsx";
import "tailwind-merge";
import "better-auth/react";
import "@convex-dev/better-auth/client/plugins";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-avatar";
import "@radix-ui/react-dialog";
import "@radix-ui/react-visually-hidden";
function RootComponent() {
  const context = useRouteContext({
    from: Route.id
  });
  return /* @__PURE__ */ jsx2(ConvexBetterAuthProvider, { client: context.convexClient, authClient, children: /* @__PURE__ */ jsx2(RootDocument, { children: /* @__PURE__ */ jsx2(Outlet, {}) }) });
}
function RootDocument({
  children
}) {
  return /* @__PURE__ */ jsxs2("html", { lang: "en", className: "h-full", children: [
    /* @__PURE__ */ jsxs2("head", { children: [
      /* @__PURE__ */ jsx2("script", { dangerouslySetInnerHTML: {
        __html: `
              (function() {
                const stored = localStorage.getItem('theme');
                const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
                const shouldUseDark = stored === 'dark' || (!stored && prefersDark);
                if (shouldUseDark) {
                  document.documentElement.classList.add('dark');
                }
              })();
            `
      } }),
      /* @__PURE__ */ jsx2(HeadContent, {})
    ] }),
    /* @__PURE__ */ jsxs2("body", { className: "h-full", children: [
      /* @__PURE__ */ jsx2(AppHeader, {}),
      /* @__PURE__ */ jsx2("main", { className: "w-full", children }),
      /* @__PURE__ */ jsx2(Scripts, {})
    ] })
  ] });
}
var fetchAuth_createServerFn_handler, fetchAuth, Route;
var init_root_B0zzklJl = __esm({
  "dist/server/assets/__root-B0zzklJl.js"() {
    "use strict";
    init_server();
    init_app_header_DDCic_DU();
    fetchAuth_createServerFn_handler = createServerRpc("6154ff9ba122adcee8332d695693036b02edeab9765af4af6c11e985f19736d6", (opts, signal) => {
      return fetchAuth.__executeServer(opts, signal);
    });
    fetchAuth = createServerFn({
      method: "GET"
    }).handler(fetchAuth_createServerFn_handler, async () => {
      const {
        createAuth: createAuth2
      } = await Promise.resolve().then(() => (init_auth_BOVWFHt3(), auth_BOVWFHt3_exports));
      const {
        session
      } = await fetchSession(getRequest());
      const sessionCookieName = getCookieName(createAuth2);
      const token = getCookie(sessionCookieName);
      return {
        userId: session?.user.id,
        token
      };
    });
    Route = createRootRouteWithContext()({
      head: () => ({
        meta: [{
          charSet: "utf-8"
        }, {
          name: "viewport",
          content: "width=device-width, initial-scale=1"
        }],
        links: [{
          rel: "icon",
          href: "/favicon.ico"
        }]
      }),
      beforeLoad: async (ctx) => {
        const {
          userId,
          token
        } = await fetchAuth();
        if (token) {
          ctx.context.convexQueryClient.serverHttpClient?.setAuth(token);
        }
        return {
          userId,
          token
        };
      },
      component: RootComponent
    });
  }
});

// dist/server/assets/route-BR6Ftn3K.js
var route_BR6Ftn3K_exports = {};
__export(route_BR6Ftn3K_exports, {
  component: () => RouteComponent,
  useRequireAuth: () => useRequireAuth,
  useSession: () => useSession
});
import { jsx as jsx3 } from "react/jsx-runtime";
import { Outlet as Outlet2 } from "@tanstack/react-router";
import { useEffect as useEffect2 } from "react";
import "lucide-react";
import "clsx";
import "tailwind-merge";
import "better-auth/react";
import "@convex-dev/better-auth/client/plugins";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-avatar";
import "@radix-ui/react-dialog";
import "@radix-ui/react-visually-hidden";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core";
import "@tanstack/router-core/ssr/server";
import "h3-v2";
import "tiny-invariant";
import "seroval";
import "@tanstack/react-router/ssr/server";
import "@convex-dev/better-auth/react";
import "@convex-dev/better-auth/react-start";
import "sonner";
import "@convex-dev/react-query";
import "convex/server";
import "@tanstack/react-router-with-query";
import "convex/react";
import "@tanstack/react-query";
function useRequireAuth() {
  const navigate = Route$8.useNavigate();
  const {
    data: session,
    isPending
  } = authClient.useSession();
  useEffect2(() => {
    if (!session && !isPending) {
      const timer = setTimeout(() => {
        const currentPath = window.location.pathname + window.location.search;
        navigate({
          to: "/login",
          search: {
            redirect: currentPath
          },
          replace: true
        });
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [session, isPending, navigate]);
  return {
    session,
    isPending
  };
}
function useSession() {
  const {
    data: session
  } = authClient.useSession();
  return session;
}
function RouteComponent() {
  const {
    session,
    isPending: isSessionPending
  } = useRequireAuth();
  if (isSessionPending) {
    return /* @__PURE__ */ jsx3("div", { "aria-live": "polite", children: "Checking session..." });
  }
  if (!session) {
    return /* @__PURE__ */ jsx3("div", { "aria-live": "polite", children: "Redirecting to login..." });
  }
  return /* @__PURE__ */ jsx3("main", { className: "flex-1 flex flex-col min-h-screen", role: "main", children: /* @__PURE__ */ jsx3(Outlet2, {}) });
}
var init_route_BR6Ftn3K = __esm({
  "dist/server/assets/route-BR6Ftn3K.js"() {
    "use strict";
    init_app_header_DDCic_DU();
    init_router_BrR6fF9p();
  }
});

// dist/server/assets/index-ClHeH7Ce.js
var index_ClHeH7Ce_exports = {};
__export(index_ClHeH7Ce_exports, {
  component: () => HomeComponent
});
import { jsx as jsx4, jsxs as jsxs3 } from "react/jsx-runtime";
import { Check, Circle, FolderKanban, Play, MessageSquare } from "lucide-react";
import { motion } from "motion/react";
import "@tanstack/react-router";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core";
import "@tanstack/router-core/ssr/server";
import "h3-v2";
import "tiny-invariant";
import "seroval";
import "@tanstack/react-router/ssr/server";
import "@convex-dev/better-auth/react";
import "@convex-dev/better-auth/react-start";
import "react";
import "sonner";
import "@convex-dev/react-query";
import "convex/server";
import "clsx";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@tanstack/react-router-with-query";
import "convex/react";
import "@tanstack/react-query";
import "tailwind-merge";
import "better-auth/react";
import "@convex-dev/better-auth/client/plugins";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "@radix-ui/react-dialog";
import "@radix-ui/react-visually-hidden";
function WorkflowStepper({
  steps,
  orientation = "horizontal",
  className
}) {
  const isHorizontal = orientation === "horizontal";
  return /* @__PURE__ */ jsx4(
    "div",
    {
      className: cn(
        "flex",
        isHorizontal ? "flex-col sm:flex-row gap-4" : "flex-col gap-6",
        className
      ),
      children: steps.map((step, index) => {
        const isLast = index === steps.length - 1;
        const isCompleted = step.status === "completed";
        const isCurrent = step.status === "current";
        return /* @__PURE__ */ jsx4(
          "div",
          {
            className: cn(
              "flex",
              isHorizontal ? "flex-1 flex-col items-center" : "flex-row items-start"
            ),
            children: /* @__PURE__ */ jsxs3(
              "div",
              {
                className: cn(
                  "flex",
                  isHorizontal ? "flex-col items-center text-center" : "flex-row items-start gap-4 w-full"
                ),
                children: [
                  /* @__PURE__ */ jsxs3("div", { className: "flex items-center justify-center relative", children: [
                    /* @__PURE__ */ jsx4(
                      motion.div,
                      {
                        initial: { scale: 0 },
                        animate: { scale: 1 },
                        transition: { delay: index * 0.1, duration: 0.3 },
                        className: cn(
                          "relative z-10 flex h-10 w-10 items-center justify-center rounded-full border-2 transition-all duration-300",
                          isCompleted && "bg-gradient-to-br from-green-500 to-green-600 border-green-600 shadow-lg shadow-green-500/30",
                          isCurrent && "bg-gradient-to-br from-blue-500 to-blue-600 border-blue-600 shadow-lg shadow-blue-500/30 animate-pulse-soft",
                          !isCompleted && !isCurrent && "bg-white dark:bg-slate-800 border-slate-300 dark:border-slate-600"
                        ),
                        children: isCompleted ? /* @__PURE__ */ jsx4(Check, { className: "h-5 w-5 text-white", strokeWidth: 3 }) : /* @__PURE__ */ jsx4(
                          Circle,
                          {
                            className: cn(
                              "h-5 w-5",
                              isCurrent ? "text-white" : "text-slate-400 dark:text-slate-500"
                            ),
                            strokeWidth: 2
                          }
                        )
                      }
                    ),
                    isCurrent && /* @__PURE__ */ jsx4(
                      motion.div,
                      {
                        className: "absolute inset-0 rounded-full border-2 border-blue-500",
                        initial: { scale: 1, opacity: 0.5 },
                        animate: { scale: 1.5, opacity: 0 },
                        transition: {
                          duration: 1.5,
                          repeat: Infinity,
                          repeatType: "loop"
                        }
                      }
                    )
                  ] }),
                  !isLast && /* @__PURE__ */ jsx4(
                    "div",
                    {
                      className: cn(
                        "absolute",
                        isHorizontal ? "hidden sm:block left-1/2 top-5 h-0.5 w-full -translate-y-1/2" : "left-5 top-10 h-full w-0.5",
                        isCompleted ? "bg-gradient-to-r from-green-500 to-green-600" : "bg-slate-200 dark:bg-slate-700"
                      ),
                      style: isHorizontal ? { width: "calc(100% - 2.5rem)" } : { height: "calc(100% - 2.5rem)" },
                      children: isCurrent && /* @__PURE__ */ jsx4(
                        motion.div,
                        {
                          className: cn(
                            "absolute inset-0 bg-gradient-to-r from-blue-500 to-blue-600",
                            isHorizontal ? "h-full" : "w-full"
                          ),
                          initial: isHorizontal ? { width: "0%" } : { height: "0%" },
                          animate: isHorizontal ? { width: "100%" } : { height: "100%" },
                          transition: {
                            duration: 2,
                            repeat: Infinity,
                            ease: "easeInOut"
                          }
                        }
                      )
                    }
                  ),
                  /* @__PURE__ */ jsxs3(
                    motion.div,
                    {
                      initial: { opacity: 0, y: 10 },
                      animate: { opacity: 1, y: 0 },
                      transition: { delay: index * 0.1 + 0.2, duration: 0.3 },
                      className: cn(
                        "flex-1",
                        isHorizontal ? "mt-4" : "mt-0 pt-1"
                      ),
                      children: [
                        /* @__PURE__ */ jsx4(
                          "h3",
                          {
                            className: cn(
                              "font-semibold text-sm sm:text-base transition-colors duration-300",
                              isCompleted && "text-green-700 dark:text-green-400",
                              isCurrent && "text-blue-700 dark:text-blue-400",
                              !isCompleted && !isCurrent && "text-slate-500 dark:text-slate-400"
                            ),
                            children: step.title
                          }
                        ),
                        /* @__PURE__ */ jsx4(
                          "p",
                          {
                            className: cn(
                              "mt-1 text-xs sm:text-sm transition-colors duration-300",
                              isCompleted || isCurrent ? "text-slate-600 dark:text-slate-300" : "text-slate-400 dark:text-slate-500"
                            ),
                            children: step.description
                          }
                        )
                      ]
                    }
                  )
                ]
              }
            )
          },
          step.id
        );
      })
    }
  );
}
function HomeComponent() {
  const workflowSteps = [{
    id: "project",
    title: "Project",
    description: "Define project and tasks, share with collaborators.",
    status: "completed"
  }, {
    id: "live-run",
    title: "Live Run",
    description: "Pick and run tasks based on your plan.",
    status: "current"
  }, {
    id: "review",
    title: "Review",
    description: "Refine internal tasks, and spot new GitHub issues.",
    status: "current"
  }];
  return /* @__PURE__ */ jsx4("div", { className: "mx-auto mt-8 w-full max-w-6xl px-6 pb-16", children: /* @__PURE__ */ jsx4("div", { className: "flex min-h-[calc(100vh-8rem)] flex-col items-center justify-center", children: /* @__PURE__ */ jsxs3("div", { className: "mx-auto w-full max-w-6xl space-y-12", children: [
    /* @__PURE__ */ jsxs3("div", { className: "text-center space-y-4", children: [
      /* @__PURE__ */ jsxs3("h1", { className: "text-4xl font-bold tracking-tight text-foreground sm:text-5xl md:text-6xl", children: [
        "Welcome to",
        " ",
        /* @__PURE__ */ jsx4("span", { className: "bg-gradient-to-r from-blue-500 via-purple-500 via-pink-500 to-rose-500 bg-clip-text text-transparent drop-shadow-sm", children: "CoGrind" })
      ] }),
      /* @__PURE__ */ jsx4("p", { className: "text-xl sm:text-2xl font-medium text-foreground/80 max-w-3xl mx-auto leading-relaxed", children: "Streamline your workflow, collaborate seamlessly, and turn your ideas into reality." })
    ] }),
    /* @__PURE__ */ jsx4("div", { className: "mt-8", children: /* @__PURE__ */ jsxs3(Card, { className: "border border-slate-200/80 dark:border-slate-800 shadow-lg shadow-slate-200/50 dark:shadow-slate-900/50 bg-gradient-to-br from-white via-slate-50/50 to-white dark:from-slate-900 dark:via-slate-900 dark:to-slate-900", children: [
      /* @__PURE__ */ jsx4(CardHeader, { className: "pb-4", children: /* @__PURE__ */ jsx4(CardTitle, { className: "text-2xl font-bold text-center text-foreground", children: "Workflow" }) }),
      /* @__PURE__ */ jsx4(CardContent, { className: "pt-2 pb-8 px-6", children: /* @__PURE__ */ jsx4(WorkflowStepper, { steps: workflowSteps, orientation: "horizontal" }) })
    ] }) }),
    /* @__PURE__ */ jsxs3("div", { className: "grid gap-6 md:grid-cols-3 mt-8", children: [
      /* @__PURE__ */ jsxs3(Card, { className: "group border border-slate-200/80 dark:border-slate-800 shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white dark:bg-slate-900", children: [
        /* @__PURE__ */ jsx4(CardHeader, { className: "pb-4", children: /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsx4("div", { className: "flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-blue-100 to-blue-200 dark:from-blue-900/40 dark:to-blue-800/40 shadow-sm group-hover:shadow-md transition-shadow", children: /* @__PURE__ */ jsx4(FolderKanban, { className: "h-6 w-6 text-blue-600 dark:text-blue-400" }) }),
          /* @__PURE__ */ jsx4(CardTitle, { className: "text-xl font-semibold", children: "Project page" })
        ] }) }),
        /* @__PURE__ */ jsxs3(CardContent, { className: "space-y-3 pt-2", children: [
          /* @__PURE__ */ jsx4(CardDescription, { className: "text-sm leading-relaxed text-slate-600 dark:text-slate-400", children: "\u2022 Create project and invite collaborators to join your project" }),
          /* @__PURE__ */ jsx4(CardDescription, { className: "text-sm leading-relaxed text-slate-600 dark:text-slate-400", children: "\u2022 Create or generate tasks with AI and assign them to your project, then share tasks with collaborators." })
        ] })
      ] }),
      /* @__PURE__ */ jsxs3(Card, { className: "group border border-slate-200/80 dark:border-slate-800 shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white dark:bg-slate-900", children: [
        /* @__PURE__ */ jsx4(CardHeader, { className: "pb-4", children: /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsx4("div", { className: "flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-100 to-emerald-200 dark:from-emerald-900/40 dark:to-emerald-800/40 shadow-sm group-hover:shadow-md transition-shadow", children: /* @__PURE__ */ jsx4(Play, { className: "h-6 w-6 text-emerald-600 dark:text-emerald-400" }) }),
          /* @__PURE__ */ jsx4(CardTitle, { className: "text-xl font-semibold", children: "Live Run page" })
        ] }) }),
        /* @__PURE__ */ jsxs3(CardContent, { className: "space-y-3 pt-2", children: [
          /* @__PURE__ */ jsx4(CardDescription, { className: "text-sm leading-relaxed text-slate-600 dark:text-slate-400", children: "\u2022 Select active tasks from Task List section." }),
          /* @__PURE__ */ jsx4(CardDescription, { className: "text-sm leading-relaxed text-slate-600 dark:text-slate-400", children: "\u2022 Run selected tasks from Live Run section." })
        ] })
      ] }),
      /* @__PURE__ */ jsxs3(Card, { className: "group border border-slate-200/80 dark:border-slate-800 shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white dark:bg-slate-900", children: [
        /* @__PURE__ */ jsx4(CardHeader, { className: "pb-4", children: /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsx4("div", { className: "flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-purple-100 to-purple-200 dark:from-purple-900/40 dark:to-purple-800/40 shadow-sm group-hover:shadow-md transition-shadow", children: /* @__PURE__ */ jsx4(MessageSquare, { className: "h-6 w-6 text-purple-600 dark:text-purple-400" }) }),
          /* @__PURE__ */ jsx4(CardTitle, { className: "text-xl font-semibold", children: "Review page" })
        ] }) }),
        /* @__PURE__ */ jsxs3(CardContent, { className: "space-y-3 pt-2", children: [
          /* @__PURE__ */ jsx4(CardDescription, { className: "text-sm leading-relaxed text-slate-600 dark:text-slate-400", children: "\u2022 Review/refine all shared tasks when needed." }),
          /* @__PURE__ */ jsx4(CardDescription, { className: "text-sm leading-relaxed text-slate-600 dark:text-slate-400", children: "\u2022 Review and spot newly created GitHub issues." })
        ] })
      ] })
    ] })
  ] }) }) });
}
var init_index_ClHeH7Ce = __esm({
  "dist/server/assets/index-ClHeH7Ce.js"() {
    "use strict";
    init_router_BrR6fF9p();
    init_app_header_DDCic_DU();
  }
});

// dist/server/assets/index-x2YHdY2P.js
var index_x2YHdY2P_exports = {};
__export(index_x2YHdY2P_exports, {
  component: () => RouteComponent2
});
import { jsx as jsx5, jsxs as jsxs4, Fragment } from "react/jsx-runtime";
import { useNavigate as useNavigate2 } from "@tanstack/react-router";
import { useState as useState2, useRef, useEffect as useEffect3 } from "react";
import "lucide-react";
import "clsx";
import "tailwind-merge";
import "better-auth/react";
import "@convex-dev/better-auth/client/plugins";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-avatar";
import "@radix-ui/react-dialog";
import "@radix-ui/react-visually-hidden";
function RouteComponent2() {
  const navigate = useNavigate2();
  const {
    data: session,
    isPending
  } = authClient.useSession();
  const [oauthLoading, setOAuthLoading] = useState2(null);
  const hasNavigated = useRef(false);
  useEffect3(() => {
    const handleRedirect = async () => {
      if (session && !hasNavigated.current) {
        hasNavigated.current = true;
        navigate({
          to: "/project",
          replace: true
        });
      }
    };
    handleRedirect();
  }, [session, navigate]);
  const handleOAuthSignIn = async (provider) => {
    setOAuthLoading(provider);
    try {
      await authClient.signIn.social({
        provider,
        callbackURL: "/login/callback"
      });
    } catch (error) {
      console.error("OAuth sign-in error:", error);
      alert(`Failed to sign in with ${provider}`);
    } finally {
      setOAuthLoading(null);
    }
  };
  if (isPending || session) {
    return /* @__PURE__ */ jsx5("div", { className: "min-h-screen flex items-center justify-center", children: /* @__PURE__ */ jsxs4("div", { className: "text-center", children: [
      /* @__PURE__ */ jsx5("div", { className: "animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto" }),
      /* @__PURE__ */ jsx5("p", { className: "mt-4", children: "Loading..." })
    ] }) });
  }
  return /* @__PURE__ */ jsx5("div", { className: "min-h-screen flex items-center justify-center p-4 sm:p-6 lg:p-8", children: /* @__PURE__ */ jsx5("div", { className: "w-full max-w-md", children: /* @__PURE__ */ jsx5("div", { className: "relative overflow-hidden rounded-2xl bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl shadow-2xl border border-white/20 dark:border-slate-700/50", children: /* @__PURE__ */ jsxs4("div", { className: "relative p-6 sm:p-8 lg:p-10", children: [
    /* @__PURE__ */ jsxs4("div", { className: "text-center mb-6", children: [
      /* @__PURE__ */ jsx5("h1", { className: "text-2xl sm:text-3xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 dark:from-white dark:to-slate-200 bg-clip-text text-transparent mb-2", children: "Welcome" }),
      /* @__PURE__ */ jsx5("p", { className: "text-gray-600 dark:text-slate-400 text-sm", children: "Sign in to continue" })
    ] }),
    /* @__PURE__ */ jsxs4("div", { className: "space-y-3", children: [
      /* @__PURE__ */ jsx5("button", { onClick: () => handleOAuthSignIn("google"), disabled: oauthLoading !== null, className: "flex w-full items-center justify-center gap-3 px-4 py-3 border-2 border-gray-200 dark:border-slate-700 text-gray-700 dark:text-slate-300 hover:bg-gray-50 dark:hover:bg-slate-800 hover:border-gray-300 dark:hover:border-slate-600 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 focus:ring-offset-2 transition-all duration-200 rounded-xl font-medium shadow-lg hover:shadow-xl", children: oauthLoading === "google" ? /* @__PURE__ */ jsxs4(Fragment, { children: [
        /* @__PURE__ */ jsx5("div", { className: "animate-spin rounded-full h-5 w-5 border-b-2 border-gray-700 dark:border-gray-300" }),
        /* @__PURE__ */ jsx5("span", { children: "Connecting..." })
      ] }) : /* @__PURE__ */ jsxs4(Fragment, { children: [
        /* @__PURE__ */ jsxs4("svg", { className: "h-5 w-5", viewBox: "0 0 24 24", children: [
          /* @__PURE__ */ jsx5("path", { fill: "currentColor", d: "M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" }),
          /* @__PURE__ */ jsx5("path", { fill: "currentColor", d: "M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" }),
          /* @__PURE__ */ jsx5("path", { fill: "currentColor", d: "M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" }),
          /* @__PURE__ */ jsx5("path", { fill: "currentColor", d: "M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" })
        ] }),
        "Google"
      ] }) }),
      /* @__PURE__ */ jsx5("button", { onClick: () => handleOAuthSignIn("github"), disabled: oauthLoading !== null, className: "flex w-full items-center justify-center gap-3 px-4 py-3 border-2 border-gray-200 dark:border-slate-700 text-gray-700 dark:text-slate-300 hover:bg-gray-50 dark:hover:bg-slate-800 hover:border-gray-300 dark:hover:border-slate-600 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 focus:ring-offset-2 transition-all duration-200 rounded-xl font-medium shadow-lg hover:shadow-xl", children: oauthLoading === "github" ? /* @__PURE__ */ jsxs4(Fragment, { children: [
        /* @__PURE__ */ jsx5("div", { className: "animate-spin rounded-full h-5 w-5 border-b-2 border-gray-700 dark:border-gray-300" }),
        /* @__PURE__ */ jsx5("span", { children: "Connecting..." })
      ] }) : /* @__PURE__ */ jsxs4(Fragment, { children: [
        /* @__PURE__ */ jsx5("svg", { className: "h-5 w-5", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ jsx5("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M12 2C6.477 2 2 6.477 2 12c0 4.42 2.865 8.17 6.839 9.49.5.092.682-.217.682-.482 0-.237-.008-.866-.013-1.7-2.782.603-3.369-1.34-3.369-1.34-.454-1.156-1.11-1.463-1.11-1.463-.908-.62.069-.608.069-.608 1.003.07 1.531 1.03 1.531 1.03.892 1.529 2.341 1.087 2.91.831.092-.646.35-1.086.636-1.336-2.22-.253-4.555-1.11-4.555-4.943 0-1.091.39-1.984 1.029-2.683-.103-.253-.446-1.27.098-2.647 0 0 .84-.269 2.75 1.025A9.578 9.578 0 0112 6.836c.85.004 1.705.114 2.504.336 1.909-1.294 2.747-1.025 2.747-1.025.546 1.377.203 2.394.1 2.647.64.699 1.028 1.592 1.028 2.683 0 3.842-2.339 4.687-4.566 4.935.359.309.678.919.678 1.852 0 1.336-.012 2.415-.012 2.743 0 .267.18.578.688.48C19.138 20.167 22 16.418 22 12c0-5.523-4.477-10-10-10z" }) }),
        "GitHub"
      ] }) })
    ] })
  ] }) }) }) });
}
var init_index_x2YHdY2P = __esm({
  "dist/server/assets/index-x2YHdY2P.js"() {
    "use strict";
    init_app_header_DDCic_DU();
  }
});

// dist/server/assets/callback-DfYxWBcJ.js
var callback_DfYxWBcJ_exports = {};
__export(callback_DfYxWBcJ_exports, {
  component: () => RouteComponent3
});
import { jsx as jsx6, jsxs as jsxs5 } from "react/jsx-runtime";
import { useNavigate as useNavigate3, useSearch } from "@tanstack/react-router";
import { useRef as useRef2, useEffect as useEffect4 } from "react";
import "lucide-react";
import "clsx";
import "tailwind-merge";
import "better-auth/react";
import "@convex-dev/better-auth/client/plugins";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-avatar";
import "@radix-ui/react-dialog";
import "@radix-ui/react-visually-hidden";
function RouteComponent3() {
  const navigate = useNavigate3();
  const {
    redirect
  } = useSearch({
    from: "/login/callback"
  });
  const {
    data: session,
    isPending
  } = authClient.useSession();
  const hasNavigated = useRef2(false);
  useEffect4(() => {
    const handleRedirect = async () => {
      if (session && !hasNavigated.current) {
        hasNavigated.current = true;
        const targetPath = redirect || "/project";
        navigate({
          to: targetPath,
          replace: true
        });
      } else if (!isPending && !session) {
        navigate({
          to: "/login",
          replace: true
        });
      }
    };
    handleRedirect();
  }, [session, isPending, navigate, redirect]);
  return /* @__PURE__ */ jsx6("div", { className: "min-h-screen flex items-center justify-center", children: /* @__PURE__ */ jsxs5("div", { className: "text-center", children: [
    /* @__PURE__ */ jsx6("div", { className: "animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto" }),
    /* @__PURE__ */ jsx6("p", { className: "mt-4", children: "Completing sign in..." })
  ] }) });
}
var init_callback_DfYxWBcJ = __esm({
  "dist/server/assets/callback-DfYxWBcJ.js"() {
    "use strict";
    init_app_header_DDCic_DU();
  }
});

// dist/server/assets/select-CNs7Rl3z.js
import { jsx as jsx7, jsxs as jsxs6 } from "react/jsx-runtime";
import * as React from "react";
import * as SelectPrimitive from "@radix-ui/react-select";
import { ChevronDown as ChevronDown2, Check as Check2, ChevronUp } from "lucide-react";
function Input({ className, type, ...props }) {
  return /* @__PURE__ */ jsx7(
    "input",
    {
      type,
      "data-slot": "input",
      className: cn(
        "file:text-foreground placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground dark:bg-input/30 border-input h-9 w-full min-w-0 rounded-md border bg-transparent px-3 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
        "focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]",
        "aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",
        className
      ),
      ...props
    }
  );
}
var Select, SelectValue, SelectTrigger, SelectScrollUpButton, SelectScrollDownButton, SelectContent, SelectLabel, SelectItem, SelectSeparator;
var init_select_CNs7Rl3z = __esm({
  "dist/server/assets/select-CNs7Rl3z.js"() {
    "use strict";
    init_app_header_DDCic_DU();
    Select = SelectPrimitive.Root;
    SelectValue = SelectPrimitive.Value;
    SelectTrigger = React.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ jsxs6(
      SelectPrimitive.Trigger,
      {
        ref,
        className: cn(
          "flex h-9 w-full items-center justify-between rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-xs ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-[3px] focus:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1",
          className
        ),
        ...props,
        children: [
          children,
          /* @__PURE__ */ jsx7(SelectPrimitive.Icon, { asChild: true, children: /* @__PURE__ */ jsx7(ChevronDown2, { className: "h-4 w-4 opacity-50" }) })
        ]
      }
    ));
    SelectTrigger.displayName = SelectPrimitive.Trigger.displayName;
    SelectScrollUpButton = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx7(
      SelectPrimitive.ScrollUpButton,
      {
        ref,
        className: cn(
          "flex cursor-default items-center justify-center py-1",
          className
        ),
        ...props,
        children: /* @__PURE__ */ jsx7(ChevronUp, { className: "h-4 w-4" })
      }
    ));
    SelectScrollUpButton.displayName = SelectPrimitive.ScrollUpButton.displayName;
    SelectScrollDownButton = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx7(
      SelectPrimitive.ScrollDownButton,
      {
        ref,
        className: cn(
          "flex cursor-default items-center justify-center py-1",
          className
        ),
        ...props,
        children: /* @__PURE__ */ jsx7(ChevronDown2, { className: "h-4 w-4" })
      }
    ));
    SelectScrollDownButton.displayName = SelectPrimitive.ScrollDownButton.displayName;
    SelectContent = React.forwardRef(({ className, children, position = "popper", ...props }, ref) => /* @__PURE__ */ jsx7(SelectPrimitive.Portal, { children: /* @__PURE__ */ jsxs6(
      SelectPrimitive.Content,
      {
        ref,
        className: cn(
          "relative z-50 max-h-96 min-w-[8rem] overflow-hidden rounded-md border bg-popover text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
          position === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1",
          className
        ),
        position,
        ...props,
        children: [
          /* @__PURE__ */ jsx7(SelectScrollUpButton, {}),
          /* @__PURE__ */ jsx7(
            SelectPrimitive.Viewport,
            {
              className: cn(
                "p-1",
                position === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"
              ),
              children
            }
          ),
          /* @__PURE__ */ jsx7(SelectScrollDownButton, {})
        ]
      }
    ) }));
    SelectContent.displayName = SelectPrimitive.Content.displayName;
    SelectLabel = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx7(
      SelectPrimitive.Label,
      {
        ref,
        className: cn("py-1.5 pl-8 pr-2 text-sm font-semibold", className),
        ...props
      }
    ));
    SelectLabel.displayName = SelectPrimitive.Label.displayName;
    SelectItem = React.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ jsxs6(
      SelectPrimitive.Item,
      {
        ref,
        className: cn(
          "relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
          className
        ),
        ...props,
        children: [
          /* @__PURE__ */ jsx7("span", { className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center", children: /* @__PURE__ */ jsx7(SelectPrimitive.ItemIndicator, { children: /* @__PURE__ */ jsx7(Check2, { className: "h-4 w-4" }) }) }),
          /* @__PURE__ */ jsx7(SelectPrimitive.ItemText, { children })
        ]
      }
    ));
    SelectItem.displayName = SelectPrimitive.Item.displayName;
    SelectSeparator = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx7(
      SelectPrimitive.Separator,
      {
        ref,
        className: cn("-mx-1 my-1 h-px bg-muted", className),
        ...props
      }
    ));
    SelectSeparator.displayName = SelectPrimitive.Separator.displayName;
  }
});

// dist/server/assets/task-card-CGreDeOa.js
import { jsx as jsx8, jsxs as jsxs7, Fragment as Fragment2 } from "react/jsx-runtime";
import * as React2 from "react";
import { useLayoutEffect, useEffect as useEffect5, useMemo as useMemo2, useState as useState3, useId } from "react";
import { functionalUpdate, FieldApi, FormApi } from "@tanstack/form-core";
import { useStore } from "@tanstack/react-store";
import * as SheetPrimitive2 from "@radix-ui/react-dialog";
import { XIcon as XIcon2, ListTodo, FileText, Flag, Clock, FolderKanban as FolderKanban2, Link2, MessageSquare as MessageSquare2, HelpCircle, User as User2, Users, CheckCircle2, MoreVertical, Share2, Pencil, Trash2 } from "lucide-react";
import { useConvexMutation, useConvexQuery } from "@convex-dev/react-query";
import * as LabelPrimitive from "@radix-ui/react-label";
import { cva as cva2 } from "class-variance-authority";
import { toast } from "sonner";
function Dialog({
  ...props
}) {
  return /* @__PURE__ */ jsx8(SheetPrimitive2.Root, { "data-slot": "dialog", ...props });
}
function DialogPortal({
  ...props
}) {
  return /* @__PURE__ */ jsx8(SheetPrimitive2.Portal, { "data-slot": "dialog-portal", ...props });
}
function DialogOverlay({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx8(
    SheetPrimitive2.Overlay,
    {
      "data-slot": "dialog-overlay",
      className: cn(
        "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 fixed inset-0 z-50 bg-black/50",
        className
      ),
      ...props
    }
  );
}
function DialogContent({
  className,
  children,
  showCloseButton = true,
  ...props
}) {
  return /* @__PURE__ */ jsxs7(DialogPortal, { "data-slot": "dialog-portal", children: [
    /* @__PURE__ */ jsx8(DialogOverlay, {}),
    /* @__PURE__ */ jsxs7(
      SheetPrimitive2.Content,
      {
        "data-slot": "dialog-content",
        className: cn(
          "bg-background data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 fixed top-[50%] left-[50%] z-50 grid w-full max-w-[calc(100%-2rem)] translate-x-[-50%] translate-y-[-50%] gap-4 rounded-lg border p-6 shadow-lg duration-200 sm:max-w-lg",
          className
        ),
        ...props,
        children: [
          children,
          showCloseButton && /* @__PURE__ */ jsxs7(
            SheetPrimitive2.Close,
            {
              "data-slot": "dialog-close",
              className: "ring-offset-background focus:ring-ring data-[state=open]:bg-accent data-[state=open]:text-muted-foreground absolute top-4 right-4 rounded-xs opacity-70 transition-opacity hover:opacity-100 focus:ring-2 focus:ring-offset-2 focus:outline-hidden disabled:pointer-events-none [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
              children: [
                /* @__PURE__ */ jsx8(XIcon2, {}),
                /* @__PURE__ */ jsx8("span", { className: "sr-only", children: "Close" })
              ]
            }
          )
        ]
      }
    )
  ] });
}
function DialogHeader({ className, ...props }) {
  return /* @__PURE__ */ jsx8(
    "div",
    {
      "data-slot": "dialog-header",
      className: cn("flex flex-col gap-2 text-center sm:text-left", className),
      ...props
    }
  );
}
function DialogFooter({ className, ...props }) {
  return /* @__PURE__ */ jsx8(
    "div",
    {
      "data-slot": "dialog-footer",
      className: cn(
        "flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",
        className
      ),
      ...props
    }
  );
}
function DialogTitle({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx8(
    SheetPrimitive2.Title,
    {
      "data-slot": "dialog-title",
      className: cn("text-lg leading-none font-semibold", className),
      ...props
    }
  );
}
function DialogDescription({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx8(
    SheetPrimitive2.Description,
    {
      "data-slot": "dialog-description",
      className: cn("text-muted-foreground text-sm", className),
      ...props
    }
  );
}
function useField(opts) {
  const [fieldApi] = useState3(() => {
    const api2 = new FieldApi({
      ...opts,
      form: opts.form,
      name: opts.name
    });
    const extendedApi = api2;
    extendedApi.Field = Field;
    return extendedApi;
  });
  useIsomorphicLayoutEffect(fieldApi.mount, [fieldApi]);
  useIsomorphicLayoutEffect(() => {
    fieldApi.update(opts);
  });
  useStore(
    fieldApi.store,
    opts.mode === "array" ? (state) => {
      return [
        state.meta,
        Object.keys(state.value ?? []).length
      ];
    } : void 0
  );
  return fieldApi;
}
function LocalSubscribe({
  form,
  selector,
  children
}) {
  const data = useStore(form.store, selector);
  return functionalUpdate(children, data);
}
function useForm(opts) {
  const formId = useId();
  const [formApi] = useState3(() => {
    const api2 = new FormApi({ ...opts, formId });
    const extendedApi = api2;
    extendedApi.Field = function APIField(props) {
      return /* @__PURE__ */ jsx8(Field, { ...props, form: api2 });
    };
    extendedApi.Subscribe = function Subscribe(props) {
      return /* @__PURE__ */ jsx8(
        LocalSubscribe,
        {
          form: api2,
          selector: props.selector,
          children: props.children
        }
      );
    };
    return extendedApi;
  });
  useIsomorphicLayoutEffect(formApi.mount, []);
  useIsomorphicLayoutEffect(() => {
    formApi.update(opts);
  });
  return formApi;
}
function AddTaskModal({ open, onOpenChange, projectId, initialTask }) {
  const createTask = useConvexMutation(api.tasks.createTask);
  const projects = useConvexQuery(api.projects.listProjects, {});
  const form = useForm({
    defaultValues: {
      text: "",
      details: "",
      priority: "medium",
      status: "todo",
      hrs: "1",
      refLink: "",
      projectId: ""
    },
    onSubmit: async ({ value, formApi }) => {
      if (!value.text.trim()) {
        formApi.setFieldMeta("text", (prev) => ({
          ...prev,
          errors: ["Task name is required"]
        }));
        return;
      }
      const resolvedProjectId = value.projectId ? value.projectId : projectId ?? initialTask?.projectId;
      try {
        await createTask({
          text: value.text.trim(),
          details: value.details.trim(),
          priority: value.priority,
          status: value.status,
          hrs: parseFloat(value.hrs) || 1,
          refLink: value.refLink.trim() || "",
          projectId: resolvedProjectId
        });
        formApi.reset();
        onOpenChange(false);
      } catch (error) {
        console.error("Failed to create task:", error);
      }
    }
  });
  useEffect5(() => {
    if (open) {
      const initialValues = {
        text: initialTask?.text ?? "",
        details: initialTask?.details ?? "",
        priority: initialTask?.priority ?? "medium",
        status: initialTask?.status ?? "todo",
        hrs: initialTask?.hrs !== void 0 ? String(initialTask.hrs) : "1",
        refLink: initialTask?.refLink ?? "",
        projectId: initialTask?.projectId ?? projectId ?? ""
      };
      form.reset(initialValues);
    }
  }, [open, initialTask, projectId, form]);
  const handleClose = (nextOpen) => {
    if (!nextOpen && !form.state.isSubmitting) {
      form.reset();
      onOpenChange(false);
      return;
    }
    if (nextOpen) {
      onOpenChange(true);
    }
  };
  const renderPriorityTone = (value) => {
    const fallback = PRIORITY_OPTIONS.find((option) => option.value === value);
    return fallback?.tone ?? "";
  };
  const renderStatusTone = (value) => {
    const fallback = STATUS_OPTIONS.find((option) => option.value === value);
    return fallback?.tone ?? "";
  };
  return /* @__PURE__ */ jsx8(Dialog, { open, onOpenChange: handleClose, children: /* @__PURE__ */ jsxs7(DialogContent, { className: "sm:max-w-[580px] max-h-[90vh] overflow-y-auto px-0 border border-border/60 bg-white dark:bg-slate-800 dark:border-slate-700 backdrop-blur-xl supports-[backdrop-filter]:bg-white/90", children: [
    /* @__PURE__ */ jsxs7(DialogHeader, { className: "px-6 pb-4", children: [
      /* @__PURE__ */ jsxs7(DialogTitle, { className: "flex items-center gap-2 text-xl", children: [
        /* @__PURE__ */ jsx8("div", { className: "flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10", children: /* @__PURE__ */ jsx8(ListTodo, { className: "h-4 w-4 text-primary" }) }),
        /* @__PURE__ */ jsx8("span", { children: "Create New Task" })
      ] }),
      /* @__PURE__ */ jsx8(DialogDescription, { className: "text-base", children: "Add a new task with the details your team needs to stay aligned." })
    ] }),
    /* @__PURE__ */ jsxs7(
      "form",
      {
        onSubmit: (event) => {
          event.preventDefault();
          form.handleSubmit();
        },
        className: "px-6",
        children: [
          /* @__PURE__ */ jsxs7("div", { className: "space-y-5", children: [
            /* @__PURE__ */ jsx8("div", { className: "space-y-2", children: /* @__PURE__ */ jsx8(
              form.Field,
              {
                name: "text",
                validators: {
                  onChange: ({ value }) => !value.trim() ? "Task name is required" : void 0,
                  onBlur: ({ value }) => !value.trim() ? "Task name is required" : void 0,
                  onSubmit: ({ value }) => !value.trim() ? "Task name is required" : void 0
                },
                children: (field) => {
                  const errorMessage = field.state.meta.errors?.[0];
                  return /* @__PURE__ */ jsxs7("div", { className: "space-y-2", children: [
                    /* @__PURE__ */ jsxs7(Label3, { htmlFor: "task-text", className: "flex items-center gap-2 text-sm font-semibold", children: [
                      /* @__PURE__ */ jsx8(FileText, { className: "h-4 w-4 text-muted-foreground" }),
                      "Task Name",
                      /* @__PURE__ */ jsx8("span", { className: "text-destructive", children: "*" })
                    ] }),
                    /* @__PURE__ */ jsx8(
                      Input,
                      {
                        id: "task-text",
                        type: "text",
                        placeholder: "e.g., Complete project documentation",
                        value: field.state.value,
                        onBlur: field.handleBlur,
                        onChange: (event) => field.handleChange(event.target.value),
                        required: true,
                        disabled: form.state.isSubmitting,
                        className: "h-11 pl-4"
                      }
                    ),
                    errorMessage ? /* @__PURE__ */ jsx8("p", { className: "text-sm text-red-600 dark:text-red-400", children: errorMessage }) : null
                  ] });
                }
              }
            ) }),
            /* @__PURE__ */ jsx8("div", { className: "space-y-2", children: /* @__PURE__ */ jsx8(form.Field, { name: "details", children: (field) => /* @__PURE__ */ jsxs7("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxs7(Label3, { htmlFor: "task-details", className: "flex items-center gap-2 text-sm font-semibold", children: [
                /* @__PURE__ */ jsx8(FileText, { className: "h-4 w-4 text-muted-foreground" }),
                "Details",
                /* @__PURE__ */ jsx8("span", { className: "text-xs text-muted-foreground font-normal", children: "(optional)" })
              ] }),
              /* @__PURE__ */ jsx8(
                "textarea",
                {
                  id: "task-details",
                  placeholder: "Add additional context...",
                  value: field.state.value,
                  onBlur: field.handleBlur,
                  onChange: (event) => field.handleChange(event.target.value),
                  disabled: form.state.isSubmitting,
                  rows: 4,
                  className: "w-full rounded-lg border border-input bg-background px-4 py-3 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
                }
              )
            ] }) }) }),
            /* @__PURE__ */ jsxs7("div", { className: "grid gap-4 sm:grid-cols-2", children: [
              /* @__PURE__ */ jsx8("div", { className: "space-y-2", children: /* @__PURE__ */ jsx8(form.Field, { name: "priority", children: (field) => /* @__PURE__ */ jsxs7("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxs7(Label3, { htmlFor: "task-priority", className: "flex items-center gap-2 text-sm font-semibold", children: [
                  /* @__PURE__ */ jsx8(Flag, { className: "h-4 w-4 text-muted-foreground" }),
                  "Priority"
                ] }),
                /* @__PURE__ */ jsx8(
                  "select",
                  {
                    id: "task-priority",
                    value: field.state.value,
                    onBlur: field.handleBlur,
                    onChange: (event) => field.handleChange(event.target.value),
                    disabled: form.state.isSubmitting,
                    className: "h-11 w-full rounded-lg border border-input bg-background px-4 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50",
                    children: PRIORITY_OPTIONS.map((option) => /* @__PURE__ */ jsx8("option", { value: option.value, children: option.label }, option.value))
                  }
                ),
                /* @__PURE__ */ jsxs7(
                  "div",
                  {
                    className: `inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-xs font-medium ${renderPriorityTone(field.state.value)}`,
                    children: [
                      /* @__PURE__ */ jsx8(Flag, { className: "h-3.5 w-3.5" }),
                      PRIORITY_OPTIONS.find((option) => option.value === field.state.value)?.label ?? field.state.value
                    ]
                  }
                )
              ] }) }) }),
              /* @__PURE__ */ jsx8("div", { className: "space-y-2", children: /* @__PURE__ */ jsx8(form.Field, { name: "status", children: (field) => /* @__PURE__ */ jsxs7("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxs7(Label3, { htmlFor: "task-status", className: "flex items-center gap-2 text-sm font-semibold", children: [
                  /* @__PURE__ */ jsx8(Clock, { className: "h-4 w-4 text-muted-foreground" }),
                  "Status"
                ] }),
                /* @__PURE__ */ jsx8(
                  "select",
                  {
                    id: "task-status",
                    value: field.state.value,
                    onBlur: field.handleBlur,
                    onChange: (event) => field.handleChange(event.target.value),
                    disabled: form.state.isSubmitting,
                    className: "h-11 w-full rounded-lg border border-input bg-background px-4 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50",
                    children: STATUS_OPTIONS.map((option) => /* @__PURE__ */ jsx8("option", { value: option.value, children: option.label }, option.value))
                  }
                ),
                /* @__PURE__ */ jsxs7(
                  "div",
                  {
                    className: `inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-xs font-medium ${renderStatusTone(field.state.value)}`,
                    children: [
                      /* @__PURE__ */ jsx8(Clock, { className: "h-3.5 w-3.5" }),
                      STATUS_OPTIONS.find((option) => option.value === field.state.value)?.label ?? field.state.value
                    ]
                  }
                )
              ] }) }) })
            ] }),
            /* @__PURE__ */ jsxs7("div", { className: "grid gap-4 sm:grid-cols-2", children: [
              /* @__PURE__ */ jsx8("div", { className: "space-y-2", children: /* @__PURE__ */ jsx8(form.Field, { name: "hrs", children: (field) => /* @__PURE__ */ jsxs7("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxs7(Label3, { htmlFor: "task-hrs", className: "flex items-center gap-2 text-sm font-semibold", children: [
                  /* @__PURE__ */ jsx8(Clock, { className: "h-4 w-4 text-muted-foreground" }),
                  "Estimated Hours"
                ] }),
                /* @__PURE__ */ jsx8(
                  Input,
                  {
                    id: "task-hrs",
                    type: "number",
                    min: "0.25",
                    step: "0.25",
                    value: field.state.value,
                    onBlur: field.handleBlur,
                    onChange: (event) => field.handleChange(event.target.value),
                    disabled: form.state.isSubmitting,
                    className: "h-11 pl-4"
                  }
                )
              ] }) }) }),
              /* @__PURE__ */ jsx8("div", { className: "space-y-2", children: /* @__PURE__ */ jsx8(form.Field, { name: "projectId", children: (field) => /* @__PURE__ */ jsxs7("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxs7(Label3, { htmlFor: "task-project", className: "flex items-center gap-2 text-sm font-semibold", children: [
                  /* @__PURE__ */ jsx8(FolderKanban2, { className: "h-4 w-4 text-muted-foreground" }),
                  "Project",
                  projectId && /* @__PURE__ */ jsx8(Badge, { variant: "secondary", className: "text-xs", children: "Locked" })
                ] }),
                /* @__PURE__ */ jsxs7(
                  "select",
                  {
                    id: "task-project",
                    value: field.state.value || projectId || "",
                    onBlur: field.handleBlur,
                    onChange: (event) => field.handleChange(event.target.value),
                    disabled: form.state.isSubmitting || !!projectId,
                    className: "h-11 w-full appearance-none rounded-lg border border-input bg-background px-4 py-2 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50",
                    children: [
                      /* @__PURE__ */ jsx8("option", { value: "", children: "No Project" }),
                      projects?.map((project) => /* @__PURE__ */ jsx8("option", { value: project._id, children: project.name }, project._id))
                    ]
                  }
                )
              ] }) }) })
            ] }),
            /* @__PURE__ */ jsx8("div", { className: "space-y-2", children: /* @__PURE__ */ jsx8(form.Field, { name: "refLink", children: (field) => /* @__PURE__ */ jsxs7("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxs7(Label3, { htmlFor: "task-ref-link", className: "flex items-center gap-2 text-sm font-semibold", children: [
                /* @__PURE__ */ jsx8(Link2, { className: "h-4 w-4 text-muted-foreground" }),
                "Reference Link",
                /* @__PURE__ */ jsx8("span", { className: "text-xs text-muted-foreground font-normal", children: "(optional)" })
              ] }),
              /* @__PURE__ */ jsx8(
                Input,
                {
                  id: "task-ref-link",
                  type: "url",
                  placeholder: "https://example.com/reference",
                  value: field.state.value,
                  onBlur: field.handleBlur,
                  onChange: (event) => field.handleChange(event.target.value),
                  disabled: form.state.isSubmitting,
                  className: "h-11 pl-4"
                }
              )
            ] }) }) })
          ] }),
          /* @__PURE__ */ jsxs7(DialogFooter, { className: "mt-6 gap-2 sm:gap-0", children: [
            /* @__PURE__ */ jsx8(
              Button,
              {
                type: "button",
                variant: "outline",
                onClick: () => handleClose(false),
                disabled: form.state.isSubmitting,
                className: "h-11",
                children: "Cancel"
              }
            ),
            /* @__PURE__ */ jsx8(
              Button,
              {
                type: "submit",
                disabled: form.state.isSubmitting || !form.state.values.text.trim(),
                className: "h-11",
                children: form.state.isSubmitting ? /* @__PURE__ */ jsxs7(Fragment2, { children: [
                  /* @__PURE__ */ jsx8("span", { className: "mr-2", children: "Creating..." }),
                  /* @__PURE__ */ jsx8("div", { className: "h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" })
                ] }) : /* @__PURE__ */ jsxs7(Fragment2, { children: [
                  /* @__PURE__ */ jsx8(ListTodo, { className: "mr-2 h-4 w-4" }),
                  "Create Task"
                ] })
              }
            )
          ] })
        ]
      }
    )
  ] }) });
}
function TaskRefinementSection({ taskId, isOwner, currentUserId }) {
  const [showAddNote, setShowAddNote] = useState3(false);
  const [showAddQuestion, setShowAddQuestion] = useState3(false);
  const [noteContent, setNoteContent] = useState3("");
  const [questionContent, setQuestionContent] = useState3("");
  const [answeringQuestionId, setAnsweringQuestionId] = useState3(null);
  const [answerContent, setAnswerContent] = useState3("");
  const refinements = useConvexQuery(api.refinements.getTaskRefinements, { taskId });
  const addRefinement = useConvexMutation(api.refinements.addTaskRefinement);
  const answerQuestion = useConvexMutation(api.refinements.answerQuestion);
  const groupedRefinements = useMemo2(() => {
    if (!refinements) {
      return {
        notes: [],
        questionGroups: [],
        updates: []
      };
    }
    const questions = refinements.filter((r) => r.type === "question");
    const answers = refinements.filter((r) => r.type === "answer");
    const notes = refinements.filter((r) => r.type === "note");
    const updates = refinements.filter((r) => r.type === "update");
    const questionGroups = questions.map((question) => {
      const questionAnswers = answers.filter((answer) => answer.parentId === question._id);
      return {
        question,
        answers: questionAnswers.sort((a, b) => a.createdAt - b.createdAt)
      };
    });
    return {
      notes: notes.sort((a, b) => a.createdAt - b.createdAt),
      questionGroups: questionGroups.sort((a, b) => a.question.createdAt - b.question.createdAt),
      updates: updates.sort((a, b) => a.createdAt - b.createdAt)
    };
  }, [refinements]);
  const handleAddNote = async () => {
    if (!noteContent.trim()) {
      toast.error("Please enter a note");
      return;
    }
    try {
      await addRefinement({
        taskId,
        type: "note",
        content: noteContent.trim()
      });
      setNoteContent("");
      setShowAddNote(false);
      toast.success("Note added");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to add note");
    }
  };
  const handleAddQuestion = async () => {
    if (!questionContent.trim()) {
      toast.error("Please enter a question");
      return;
    }
    try {
      await addRefinement({
        taskId,
        type: "question",
        content: questionContent.trim()
      });
      setQuestionContent("");
      setShowAddQuestion(false);
      toast.success("Question added");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to add question");
    }
  };
  const handleAnswerQuestion = async (questionId) => {
    if (!answerContent.trim()) {
      toast.error("Please enter an answer");
      return;
    }
    try {
      await answerQuestion({
        questionId,
        answer: answerContent.trim()
      });
      setAnswerContent("");
      setAnsweringQuestionId(null);
      toast.success("Answer added");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to add answer");
    }
  };
  const formatTime = (timestamp) => {
    const date = new Date(timestamp);
    const now = /* @__PURE__ */ new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 6e4);
    const diffHours = Math.floor(diffMs / 36e5);
    const diffDays = Math.floor(diffMs / 864e5);
    if (diffMins < 1) return "just now";
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString();
  };
  const getAuthorDisplay = (refinement) => {
    const name = refinement.authorName || refinement.authorEmail.split("@")[0];
    const role = refinement.role === "owner" ? "Owner" : "Collaborator";
    return `${name} (${role})`;
  };
  return /* @__PURE__ */ jsxs7("div", { className: "mt-4 border-t border-slate-200 dark:border-slate-800 pt-4", children: [
    /* @__PURE__ */ jsxs7("div", { className: "flex items-center justify-between mb-4", children: [
      /* @__PURE__ */ jsxs7("h3", { className: "text-sm font-semibold text-foreground flex items-center gap-2", children: [
        /* @__PURE__ */ jsx8(MessageSquare2, { className: "h-4 w-4" }),
        "Refinement"
      ] }),
      /* @__PURE__ */ jsxs7("div", { className: "flex gap-2", children: [
        !isOwner && /* @__PURE__ */ jsxs7(Fragment2, { children: [
          /* @__PURE__ */ jsxs7(
            Button,
            {
              variant: "outline",
              size: "sm",
              onClick: () => {
                setShowAddNote(true);
                setShowAddQuestion(false);
              },
              className: "text-xs",
              children: [
                /* @__PURE__ */ jsx8(FileText, { className: "h-3 w-3 mr-1" }),
                "Add Note"
              ]
            }
          ),
          /* @__PURE__ */ jsxs7(
            Button,
            {
              variant: "outline",
              size: "sm",
              onClick: () => {
                setShowAddQuestion(true);
                setShowAddNote(false);
              },
              className: "text-xs",
              children: [
                /* @__PURE__ */ jsx8(HelpCircle, { className: "h-3 w-3 mr-1" }),
                "Ask Question"
              ]
            }
          )
        ] }),
        isOwner && /* @__PURE__ */ jsxs7(Fragment2, { children: [
          /* @__PURE__ */ jsxs7(
            Button,
            {
              variant: "outline",
              size: "sm",
              onClick: () => {
                setShowAddNote(true);
                setShowAddQuestion(false);
              },
              className: "text-xs",
              children: [
                /* @__PURE__ */ jsx8(FileText, { className: "h-3 w-3 mr-1" }),
                "Add Note"
              ]
            }
          ),
          /* @__PURE__ */ jsxs7(
            Button,
            {
              variant: "outline",
              size: "sm",
              onClick: () => {
                setShowAddQuestion(true);
                setShowAddNote(false);
              },
              className: "text-xs",
              children: [
                /* @__PURE__ */ jsx8(HelpCircle, { className: "h-3 w-3 mr-1" }),
                "Ask Question"
              ]
            }
          )
        ] })
      ] })
    ] }),
    showAddNote && /* @__PURE__ */ jsxs7(Card, { className: "p-3 mb-4 bg-slate-50 dark:bg-slate-900", children: [
      /* @__PURE__ */ jsx8(
        Textarea,
        {
          placeholder: "Add a note...",
          value: noteContent,
          onChange: (e) => setNoteContent(e.target.value),
          className: "min-h-[80px] mb-2"
        }
      ),
      /* @__PURE__ */ jsxs7("div", { className: "flex justify-end gap-2", children: [
        /* @__PURE__ */ jsx8(Button, { variant: "ghost", size: "sm", onClick: () => {
          setShowAddNote(false);
          setNoteContent("");
        }, children: "Cancel" }),
        /* @__PURE__ */ jsx8(Button, { size: "sm", onClick: handleAddNote, children: "Add Note" })
      ] })
    ] }),
    showAddQuestion && /* @__PURE__ */ jsxs7(Card, { className: "p-3 mb-4 bg-slate-50 dark:bg-slate-900", children: [
      /* @__PURE__ */ jsx8(
        Textarea,
        {
          placeholder: "Ask a question...",
          value: questionContent,
          onChange: (e) => setQuestionContent(e.target.value),
          className: "min-h-[80px] mb-2"
        }
      ),
      /* @__PURE__ */ jsxs7("div", { className: "flex justify-end gap-2", children: [
        /* @__PURE__ */ jsx8(Button, { variant: "ghost", size: "sm", onClick: () => {
          setShowAddQuestion(false);
          setQuestionContent("");
        }, children: "Cancel" }),
        /* @__PURE__ */ jsx8(Button, { size: "sm", onClick: handleAddQuestion, children: "Ask Question" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs7("div", { className: "space-y-4", children: [
      groupedRefinements.notes.length > 0 && /* @__PURE__ */ jsxs7("div", { children: [
        /* @__PURE__ */ jsxs7("h4", { className: "text-xs font-medium text-muted-foreground mb-2 flex items-center gap-1", children: [
          /* @__PURE__ */ jsx8(FileText, { className: "h-3 w-3" }),
          "Notes"
        ] }),
        /* @__PURE__ */ jsx8("div", { className: "space-y-2", children: groupedRefinements.notes.map((note) => /* @__PURE__ */ jsxs7(Card, { className: "p-3 bg-slate-50 dark:bg-slate-900", children: [
          /* @__PURE__ */ jsx8("p", { className: "text-sm text-foreground mb-2", children: note.content }),
          /* @__PURE__ */ jsxs7("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxs7("span", { className: "text-xs text-muted-foreground", children: [
              getAuthorDisplay(note),
              " \u2022 ",
              formatTime(note.createdAt)
            ] }),
            /* @__PURE__ */ jsxs7(Badge, { variant: note.role === "owner" ? "default" : "secondary", className: "text-xs", children: [
              note.role === "owner" ? /* @__PURE__ */ jsx8(User2, { className: "h-2 w-2 mr-1" }) : /* @__PURE__ */ jsx8(Users, { className: "h-2 w-2 mr-1" }),
              note.role
            ] })
          ] })
        ] }, note._id)) })
      ] }),
      groupedRefinements.questionGroups.length > 0 && /* @__PURE__ */ jsxs7("div", { children: [
        /* @__PURE__ */ jsxs7("h4", { className: "text-xs font-medium text-muted-foreground mb-2 flex items-center gap-1", children: [
          /* @__PURE__ */ jsx8(HelpCircle, { className: "h-3 w-3" }),
          "Questions & Answers"
        ] }),
        /* @__PURE__ */ jsx8("div", { className: "space-y-3", children: groupedRefinements.questionGroups.map(({ question, answers }) => /* @__PURE__ */ jsxs7(Card, { className: "p-3 bg-slate-50 dark:bg-slate-900", children: [
          /* @__PURE__ */ jsxs7("div", { className: "mb-2", children: [
            /* @__PURE__ */ jsxs7("div", { className: "flex items-start gap-2 mb-1", children: [
              /* @__PURE__ */ jsx8(HelpCircle, { className: "h-4 w-4 text-blue-500 mt-0.5" }),
              /* @__PURE__ */ jsx8("p", { className: "text-sm font-medium text-foreground flex-1", children: question.content })
            ] }),
            /* @__PURE__ */ jsxs7("div", { className: "flex items-center justify-between ml-6", children: [
              /* @__PURE__ */ jsxs7("span", { className: "text-xs text-muted-foreground", children: [
                getAuthorDisplay(question),
                " \u2022 ",
                formatTime(question.createdAt)
              ] }),
              /* @__PURE__ */ jsxs7(Badge, { variant: question.role === "owner" ? "default" : "secondary", className: "text-xs", children: [
                question.role === "owner" ? /* @__PURE__ */ jsx8(User2, { className: "h-2 w-2 mr-1" }) : /* @__PURE__ */ jsx8(Users, { className: "h-2 w-2 mr-1" }),
                question.role
              ] })
            ] })
          ] }),
          answers.length > 0 && /* @__PURE__ */ jsx8("div", { className: "ml-6 mt-3 space-y-2 border-l-2 border-slate-200 dark:border-slate-700 pl-3", children: answers.map((answer) => /* @__PURE__ */ jsxs7("div", { className: "bg-white dark:bg-slate-800 rounded p-2", children: [
            /* @__PURE__ */ jsx8("p", { className: "text-sm text-foreground mb-1", children: answer.content }),
            /* @__PURE__ */ jsxs7("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxs7("span", { className: "text-xs text-muted-foreground", children: [
                getAuthorDisplay(answer),
                " \u2022 ",
                formatTime(answer.createdAt)
              ] }),
              /* @__PURE__ */ jsxs7(Badge, { variant: "default", className: "text-xs", children: [
                /* @__PURE__ */ jsx8(User2, { className: "h-2 w-2 mr-1" }),
                "Owner"
              ] })
            ] })
          ] }, answer._id)) }),
          isOwner && answeringQuestionId === question._id && /* @__PURE__ */ jsxs7("div", { className: "ml-6 mt-3 border-l-2 border-slate-200 dark:border-slate-700 pl-3", children: [
            /* @__PURE__ */ jsx8(
              Textarea,
              {
                placeholder: "Type your answer...",
                value: answerContent,
                onChange: (e) => setAnswerContent(e.target.value),
                className: "min-h-[60px] mb-2"
              }
            ),
            /* @__PURE__ */ jsxs7("div", { className: "flex justify-end gap-2", children: [
              /* @__PURE__ */ jsx8(
                Button,
                {
                  variant: "ghost",
                  size: "sm",
                  onClick: () => {
                    setAnsweringQuestionId(null);
                    setAnswerContent("");
                  },
                  children: "Cancel"
                }
              ),
              /* @__PURE__ */ jsx8(Button, { size: "sm", onClick: () => handleAnswerQuestion(question._id), children: "Answer" })
            ] })
          ] }),
          isOwner && answeringQuestionId !== question._id && /* @__PURE__ */ jsx8("div", { className: "ml-6 mt-2", children: /* @__PURE__ */ jsx8(
            Button,
            {
              variant: "outline",
              size: "sm",
              onClick: () => {
                setAnsweringQuestionId(question._id);
                setAnswerContent("");
              },
              className: "text-xs",
              children: answers.length > 0 ? "Add Another Answer" : "Answer Question"
            }
          ) })
        ] }, question._id)) })
      ] }),
      groupedRefinements.updates.length > 0 && /* @__PURE__ */ jsxs7("div", { children: [
        /* @__PURE__ */ jsxs7("h4", { className: "text-xs font-medium text-muted-foreground mb-2 flex items-center gap-1", children: [
          /* @__PURE__ */ jsx8(CheckCircle2, { className: "h-3 w-3" }),
          "Updates"
        ] }),
        /* @__PURE__ */ jsx8("div", { className: "space-y-2", children: groupedRefinements.updates.map((update) => /* @__PURE__ */ jsxs7(Card, { className: "p-3 bg-slate-50 dark:bg-slate-900", children: [
          /* @__PURE__ */ jsx8("p", { className: "text-sm text-foreground mb-2", children: update.content }),
          /* @__PURE__ */ jsxs7("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxs7("span", { className: "text-xs text-muted-foreground", children: [
              getAuthorDisplay(update),
              " \u2022 ",
              formatTime(update.createdAt)
            ] }),
            /* @__PURE__ */ jsxs7(Badge, { variant: "default", className: "text-xs", children: [
              /* @__PURE__ */ jsx8(User2, { className: "h-2 w-2 mr-1" }),
              "Owner"
            ] })
          ] })
        ] }, update._id)) })
      ] }),
      !refinements || refinements.length === 0 ? /* @__PURE__ */ jsxs7("div", { className: "text-center py-8 text-muted-foreground text-sm", children: [
        /* @__PURE__ */ jsx8(MessageSquare2, { className: "h-8 w-8 mx-auto mb-2 opacity-50" }),
        /* @__PURE__ */ jsx8("p", { children: "No refinements yet. Start a conversation!" })
      ] }) : null
    ] })
  ] });
}
function TaskCard({
  task,
  projectName,
  isOwner,
  sharedEmails,
  isEditing,
  editForm,
  isSubmitting,
  projects,
  wrapperStyle,
  onEdit,
  onDelete,
  onToggle,
  onShare,
  onUnshare,
  onCancelEdit,
  onSaveEdit,
  onEditFormChange,
  runningTimeLabel,
  isRunning,
  showRefinement = false,
  currentUserId
}) {
  const [isMenuOpen, setIsMenuOpen] = useState3(false);
  const statusTag = useMemo2(() => getStatusTag(task.status), [task.status]);
  const isCompleted = task.status === "done" || task.status === "Completed";
  const isUnassigned = !task.projectId;
  const isMarkDoneDisabled = !isCompleted && isUnassigned;
  const canShare = isOwner && !!onShare && sharedEmails.length === 0;
  const canUnshare = isOwner && !!onUnshare && sharedEmails.length > 0;
  const handleEditField = (field, value) => {
    if (!onEditFormChange) return;
    onEditFormChange((prev) => ({
      ...prev,
      [field]: value
    }));
  };
  const combinedWrapperStyle = {
    margin: 0,
    ...wrapperStyle ?? {}
  };
  if (isEditing) {
    return /* @__PURE__ */ jsxs7(
      "div",
      {
        style: combinedWrapperStyle,
        className: "bg-white dark:bg-slate-800 rounded-2xl border border-blue-200 dark:border-blue-700 shadow-lg p-6 space-y-6 transition-all",
        children: [
          /* @__PURE__ */ jsxs7("div", { children: [
            /* @__PURE__ */ jsx8("label", { className: "block text-sm font-semibold mb-2 text-foreground", children: "Task Name" }),
            /* @__PURE__ */ jsx8(
              "input",
              {
                type: "text",
                value: editForm.text,
                onChange: (e) => handleEditField("text", e.target.value),
                className: "w-full px-3 py-2.5 border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-700 dark:text-slate-100 text-foreground focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all",
                placeholder: "Enter task name..."
              }
            )
          ] }),
          /* @__PURE__ */ jsxs7("div", { children: [
            /* @__PURE__ */ jsx8("label", { className: "block text-sm font-semibold mb-2 text-foreground", children: "Details" }),
            /* @__PURE__ */ jsx8(
              "textarea",
              {
                value: editForm.details,
                onChange: (e) => handleEditField("details", e.target.value),
                className: "w-full px-3 py-2.5 border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-700 text-foreground focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none",
                rows: 3,
                placeholder: "Add more context..."
              }
            )
          ] }),
          /* @__PURE__ */ jsxs7("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxs7("div", { children: [
              /* @__PURE__ */ jsx8("label", { className: "block text-sm font-semibold mb-2 text-foreground", children: "Reference Link" }),
              /* @__PURE__ */ jsx8(
                "input",
                {
                  type: "url",
                  value: editForm.refLink,
                  onChange: (e) => handleEditField("refLink", e.target.value),
                  className: "w-full px-3 py-2.5 border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-700 dark:text-slate-100 text-foreground focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all",
                  placeholder: "https://..."
                }
              )
            ] }),
            /* @__PURE__ */ jsxs7("div", { children: [
              /* @__PURE__ */ jsx8("label", { className: "block text-sm font-semibold mb-2 text-foreground", children: "Project" }),
              /* @__PURE__ */ jsxs7(
                "select",
                {
                  value: editForm.projectId,
                  onChange: (e) => handleEditField("projectId", e.target.value),
                  className: "w-full px-3 py-2.5 border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-700 dark:text-slate-100 text-foreground focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all",
                  children: [
                    /* @__PURE__ */ jsx8("option", { value: "", children: "No Project" }),
                    projects?.map((project) => /* @__PURE__ */ jsx8("option", { value: project._id, children: project.name }, project._id))
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxs7("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxs7("div", { children: [
              /* @__PURE__ */ jsx8("label", { className: "block text-sm font-semibold mb-2 text-foreground", children: "Priority" }),
              /* @__PURE__ */ jsx8("div", { className: "flex gap-2", children: ["low", "medium", "high"].map((priority) => /* @__PURE__ */ jsx8(
                "button",
                {
                  type: "button",
                  onClick: () => handleEditField("priority", priority),
                  className: cn(
                    "px-3 py-1.5 rounded-lg text-sm font-medium transition-all",
                    editForm.priority === priority ? {
                      high: "bg-red-500 text-white shadow-md",
                      medium: "bg-amber-500 text-white shadow-md",
                      low: "bg-emerald-500 text-white shadow-md"
                    }[priority] : "bg-slate-100 dark:bg-slate-700/50 text-foreground hover:bg-slate-200 dark:hover:bg-slate-600/50"
                  ),
                  children: PRIORITY_LABELS[priority]
                },
                priority
              )) })
            ] }),
            /* @__PURE__ */ jsxs7("div", { children: [
              /* @__PURE__ */ jsx8("label", { className: "block text-sm font-semibold mb-2 text-foreground", children: "Estimated Hours" }),
              /* @__PURE__ */ jsx8(
                "select",
                {
                  value: editForm.hrs,
                  onChange: (e) => handleEditField("hrs", Number(e.target.value)),
                  className: "w-full px-3 py-2.5 border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-700 dark:text-slate-100 text-foreground focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all",
                  children: hoursOptions.map((hour) => /* @__PURE__ */ jsxs7("option", { value: hour, children: [
                    hour,
                    "h"
                  ] }, hour))
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxs7("div", { children: [
            /* @__PURE__ */ jsx8("label", { className: "block text-sm font-semibold mb-2 text-foreground", children: "Share with (emails)" }),
            /* @__PURE__ */ jsx8(
              "input",
              {
                type: "text",
                value: editForm.sharedWith,
                onChange: (e) => handleEditField("sharedWith", e.target.value),
                placeholder: "user@example.com, teammate@example.com",
                className: "w-full px-3 py-2.5 border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-700 dark:text-slate-100 text-foreground focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs7("div", { className: "flex flex-col sm:flex-row sm:justify-end gap-2 pt-2", children: [
            /* @__PURE__ */ jsx8(
              "button",
              {
                type: "button",
                onClick: onCancelEdit,
                className: "px-4 py-2 text-foreground border border-slate-200 dark:border-slate-600/70 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700/50 transition-all",
                children: "Cancel"
              }
            ),
            /* @__PURE__ */ jsx8(
              "button",
              {
                type: "button",
                onClick: onSaveEdit,
                disabled: isSubmitting,
                className: "px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all disabled:opacity-60 disabled:cursor-not-allowed",
                children: isSubmitting ? "Saving..." : "Save Changes"
              }
            )
          ] })
        ]
      }
    );
  }
  return /* @__PURE__ */ jsx8(
    "div",
    {
      style: combinedWrapperStyle,
      className: cn(
        "group w-full rounded-2xl border transition-all duration-300",
        isCompleted ? "bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700" : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-lg hover:-translate-y-0.5"
      ),
      children: /* @__PURE__ */ jsxs7("div", { className: "px-4 py-4 sm:px-5 sm:py-5", children: [
        /* @__PURE__ */ jsxs7("div", { className: "flex items-start justify-between gap-3", children: [
          /* @__PURE__ */ jsxs7("div", { className: "flex items-start gap-2.5 flex-1 min-w-0", children: [
            task.priority && /* @__PURE__ */ jsx8(
              "div",
              {
                className: cn(
                  "mt-1 h-10 w-1 rounded-full transition-all",
                  PRIORITY_COLORS[task.priority.toLowerCase()] ?? "bg-slate-300"
                )
              }
            ),
            /* @__PURE__ */ jsx8("div", { className: "flex-1 min-w-0", children: /* @__PURE__ */ jsx8(
              "h3",
              {
                className: cn(
                  "font-semibold text-lg leading-snug transition-colors line-clamp-2",
                  isCompleted ? "line-through text-slate-500 dark:text-slate-500" : "text-foreground dark:text-slate-100"
                ),
                children: task.text
              }
            ) })
          ] }),
          isOwner && /* @__PURE__ */ jsx8("div", { className: "flex-shrink-0", children: /* @__PURE__ */ jsxs7(DropdownMenu, { open: isMenuOpen, onOpenChange: setIsMenuOpen, children: [
            /* @__PURE__ */ jsx8(DropdownMenuTrigger, { asChild: true, children: /* @__PURE__ */ jsx8(
              "button",
              {
                type: "button",
                className: "flex h-8 w-8 items-center justify-center rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700/50 flex-shrink-0",
                "aria-label": "Task actions",
                children: /* @__PURE__ */ jsx8(MoreVertical, { className: "h-4 w-4" })
              }
            ) }),
            /* @__PURE__ */ jsxs7(
              DropdownMenuContent,
              {
                align: "end",
                sideOffset: 8,
                className: "z-50 w-48 rounded-xl border border-slate-200/90 dark:border-slate-700 bg-white dark:bg-slate-800 shadow-xl p-1",
                children: [
                  canShare && /* @__PURE__ */ jsxs7(
                    DropdownMenuItem,
                    {
                      className: "flex items-center gap-2 px-3 py-2 text-sm text-slate-900 dark:text-slate-200 cursor-pointer rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700/50 focus:bg-slate-100 dark:focus:bg-slate-700/50",
                      onSelect: (event) => {
                        event.preventDefault();
                        onShare?.(task);
                        setIsMenuOpen(false);
                      },
                      children: [
                        /* @__PURE__ */ jsx8(Share2, { className: "h-4 w-4" }),
                        "Share"
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsxs7(
                    DropdownMenuItem,
                    {
                      className: "flex items-center gap-2 px-3 py-2 text-sm text-slate-900 dark:text-slate-100 cursor-pointer rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 focus:bg-slate-100 dark:focus:bg-slate-800",
                      onSelect: (event) => {
                        event.preventDefault();
                        onEdit(task);
                        setIsMenuOpen(false);
                      },
                      children: [
                        /* @__PURE__ */ jsx8(Pencil, { className: "h-4 w-4" }),
                        "Edit"
                      ]
                    }
                  ),
                  canUnshare && /* @__PURE__ */ jsxs7(
                    DropdownMenuItem,
                    {
                      className: "flex items-center gap-2 px-3 py-2 text-sm text-slate-900 dark:text-slate-200 cursor-pointer rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700/50 focus:bg-slate-100 dark:focus:bg-slate-700/50",
                      onSelect: (event) => {
                        event.preventDefault();
                        onUnshare?.(task);
                        setIsMenuOpen(false);
                      },
                      children: [
                        /* @__PURE__ */ jsx8(Share2, { className: "h-4 w-4" }),
                        "Unshare"
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsx8(DropdownMenuSeparator, { className: "my-1 bg-slate-200/80 dark:bg-slate-700/80" }),
                  /* @__PURE__ */ jsxs7(
                    DropdownMenuItem,
                    {
                      className: "flex items-center gap-2 px-3 py-2 text-sm text-red-600 dark:text-red-400 cursor-pointer rounded-lg hover:bg-red-50 dark:hover:bg-red-950/20 focus:bg-red-50 dark:focus:bg-red-950/20 focus:text-red-600 dark:focus:text-red-400",
                      onSelect: (event) => {
                        event.preventDefault();
                        if (window.confirm(`Delete "${task.text}"? This action cannot be undone.`)) {
                          onDelete(task);
                        }
                        setIsMenuOpen(false);
                      },
                      children: [
                        /* @__PURE__ */ jsx8(Trash2, { className: "h-4 w-4" }),
                        "Delete"
                      ]
                    }
                  )
                ]
              }
            )
          ] }) })
        ] }),
        /* @__PURE__ */ jsxs7("div", { className: "flex flex-wrap items-center gap-2 mt-3 mb-4", children: [
          /* @__PURE__ */ jsxs7(
            "span",
            {
              className: cn(
                "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold",
                statusTag.color
              ),
              children: [
                /* @__PURE__ */ jsx8("span", { children: statusTag.icon }),
                statusTag.label
              ]
            }
          ),
          task.priority && /* @__PURE__ */ jsx8(
            "span",
            {
              className: cn(
                "inline-flex items-center px-3 py-1.5 rounded-full text-xs font-semibold",
                PRIORITY_COLORS[task.priority.toLowerCase()] ?? "bg-slate-200 text-slate-700"
              ),
              children: PRIORITY_LABELS[task.priority.toLowerCase()] ?? task.priority
            }
          ),
          typeof task.hrs === "number" && /* @__PURE__ */ jsxs7("span", { className: "inline-flex items-center px-3 py-1.5 rounded-full text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200", children: [
            "\u23F1\uFE0F ",
            task.hrs,
            "h"
          ] }),
          runningTimeLabel && /* @__PURE__ */ jsxs7(
            "span",
            {
              className: cn(
                "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border",
                isRunning ? "border-emerald-300 text-emerald-700 dark:border-emerald-700 dark:text-emerald-200 bg-emerald-50/70 dark:bg-emerald-900/30" : "border-slate-300 text-slate-600 dark:border-slate-600 dark:text-slate-300 bg-white/80 dark:bg-slate-900/40"
              ),
              children: [
                /* @__PURE__ */ jsx8(Clock, { className: "h-3.5 w-3.5" }),
                runningTimeLabel
              ]
            }
          ),
          projectName && /* @__PURE__ */ jsxs7("span", { className: "inline-flex items-center px-3 py-1.5 rounded-full text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200", children: [
            "\u{1F4C1} ",
            projectName
          ] }),
          sharedEmails.length > 0 && /* @__PURE__ */ jsxs7("span", { className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-200", children: [
            /* @__PURE__ */ jsx8(Users, { className: "h-3.5 w-3.5" }),
            "Shared"
          ] })
        ] }),
        task.details && /* @__PURE__ */ jsx8(
          "div",
          {
            className: "border-b border-slate-200 dark:border-slate-800",
            style: { paddingTop: "24px", paddingBottom: "24px", margin: 0 },
            children: /* @__PURE__ */ jsx8("p", { className: "text-sm text-muted-foreground leading-relaxed", children: task.details })
          }
        ),
        sharedEmails.length > 0 && /* @__PURE__ */ jsx8(
          "div",
          {
            className: cn(
              "border-b border-slate-200 dark:border-slate-800",
              !task.details && "pt-4"
            ),
            style: { paddingBottom: "16px", margin: 0 },
            children: /* @__PURE__ */ jsxs7("p", { className: "text-xs text-muted-foreground", children: [
              "Shared with: ",
              sharedEmails.join(", ")
            ] })
          }
        ),
        /* @__PURE__ */ jsxs7("div", { className: "flex flex-col lg:flex-row lg:items-center justify-between gap-3 text-xs text-muted-foreground", children: [
          /* @__PURE__ */ jsxs7("div", { className: "flex items-center gap-4 flex-wrap", children: [
            task.refLink && /* @__PURE__ */ jsxs7(
              "a",
              {
                href: task.refLink,
                target: "_blank",
                rel: "noopener noreferrer",
                className: "inline-flex items-center gap-1.5 text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-medium transition-colors",
                children: [
                  /* @__PURE__ */ jsx8(Link2, { className: "h-3.5 w-3.5" }),
                  "Reference"
                ]
              }
            ),
            /* @__PURE__ */ jsxs7("span", { children: [
              "Created",
              " ",
              new Date(task._creationTime || Date.now()).toLocaleDateString("en-US", {
                month: "short",
                day: "numeric"
              })
            ] })
          ] }),
          isOwner && /* @__PURE__ */ jsx8(
            "button",
            {
              type: "button",
              onClick: () => onToggle(task),
              disabled: isMarkDoneDisabled,
              className: cn(
                "inline-flex items-center justify-center px-3 py-1.5 rounded-md font-medium text-xs transition-all hover:shadow-md",
                isCompleted ? "bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-slate-700" : "bg-emerald-100 dark:bg-emerald-900 text-emerald-700 dark:text-emerald-200 hover:bg-emerald-200 dark:hover:bg-emerald-800",
                isMarkDoneDisabled && "cursor-not-allowed opacity-60 hover:shadow-none hover:bg-emerald-100 dark:hover:bg-emerald-900"
              ),
              title: isMarkDoneDisabled ? "Assign this task to a project before marking it done." : void 0,
              children: isCompleted ? "\u21BA Reopen Task" : "\u2713 Mark Done"
            }
          )
        ] }),
        showRefinement && sharedEmails.length > 0 && currentUserId && /* @__PURE__ */ jsx8(
          TaskRefinementSection,
          {
            taskId: task._id,
            isOwner,
            currentUserId
          }
        )
      ] })
    }
  );
}
var useIsomorphicLayoutEffect, Field, labelVariants, Label3, PRIORITY_OPTIONS, STATUS_OPTIONS, Textarea, PRIORITY_LABELS, PRIORITY_COLORS, hoursOptions, getStatusTag;
var init_task_card_CGreDeOa = __esm({
  "dist/server/assets/task-card-CGreDeOa.js"() {
    "use strict";
    init_app_header_DDCic_DU();
    init_select_CNs7Rl3z();
    init_api_DiONElen();
    init_router_BrR6fF9p();
    useIsomorphicLayoutEffect = typeof window !== "undefined" ? useLayoutEffect : useEffect5;
    Field = ({
      children,
      ...fieldOptions
    }) => {
      const fieldApi = useField(fieldOptions);
      const jsxToDisplay = useMemo2(
        () => functionalUpdate(children, fieldApi),
        /**
         * The reason this exists is to fix an issue with the React Compiler.
         * Namely, functionalUpdate is memoized where it checks for `fieldApi`, which is a static type.
         * This means that when `state.value` changes, it does not trigger a re-render. The useMemo explicitly fixes this problem
         */
        // eslint-disable-next-line react-hooks/exhaustive-deps
        [children, fieldApi, fieldApi.state.value, fieldApi.state.meta]
      );
      return /* @__PURE__ */ jsx8(Fragment2, { children: jsxToDisplay });
    };
    labelVariants = cva2(
      "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
    );
    Label3 = React2.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx8(
      LabelPrimitive.Root,
      {
        ref,
        className: cn(labelVariants(), className),
        ...props
      }
    ));
    Label3.displayName = LabelPrimitive.Root.displayName;
    PRIORITY_OPTIONS = [
      { value: "low", label: "Low", tone: "text-green-600 bg-green-50 border-green-200" },
      { value: "medium", label: "Medium", tone: "text-yellow-600 bg-yellow-50 border-yellow-200" },
      { value: "high", label: "High", tone: "text-red-600 bg-red-50 border-red-200" }
    ];
    STATUS_OPTIONS = [
      { value: "todo", label: "To do", tone: "text-slate-600 bg-slate-50 border-slate-200" },
      { value: "in-progress", label: "In progress", tone: "text-blue-600 bg-blue-50 border-blue-200" },
      { value: "done", label: "Done", tone: "text-emerald-600 bg-emerald-50 border-emerald-200" }
    ];
    Textarea = React2.forwardRef(({ className, ...props }, ref) => {
      return /* @__PURE__ */ jsx8(
        "textarea",
        {
          className: cn(
            "flex min-h-[80px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-base shadow-xs transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
            className
          ),
          ref,
          ...props
        }
      );
    });
    Textarea.displayName = "Textarea";
    PRIORITY_LABELS = {
      low: "Low",
      medium: "Medium",
      high: "High"
    };
    PRIORITY_COLORS = {
      high: "bg-red-500 text-white",
      medium: "bg-amber-500 text-white",
      low: "bg-emerald-500 text-white"
    };
    hoursOptions = Array.from({ length: 8 }, (_, idx) => idx + 1);
    getStatusTag = (status) => {
      const normalized = (status || "").toLowerCase();
      if (normalized === "in progress" || normalized === "in-progress" || normalized === "running") {
        return {
          label: "Running",
          icon: "\u23F1",
          color: "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300"
        };
      }
      if (normalized === "done" || normalized === "completed") {
        return {
          label: "Done",
          icon: "\u2713",
          color: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300"
        };
      }
      return {
        label: "Backlog",
        icon: "\u25CB",
        color: "bg-slate-100 text-slate-700 dark:bg-slate-700/50 dark:text-slate-300"
      };
    };
  }
});

// dist/server/assets/refine-D_ImU73t.js
var refine_D_ImU73t_exports = {};
__export(refine_D_ImU73t_exports, {
  component: () => RouteComponent4
});
import { jsxs as jsxs8, jsx as jsx9, Fragment as Fragment3 } from "react/jsx-runtime";
import { useConvexMutation as useConvexMutation2, useConvexQuery as useConvexQuery2 } from "@convex-dev/react-query";
import { useQueryClient } from "@tanstack/react-query";
import { useState as useState4, useMemo as useMemo3, useEffect as useEffect6 } from "react";
import { MessageSquare as MessageSquare3, GitBranch, Users as Users2, User as User3, CheckSquare, Github, Loader2, ArrowUpRight, AlertCircle, ListTodo as ListTodo2 } from "lucide-react";
import { toast as toast2 } from "sonner";
import "convex/server";
import "@tanstack/react-router";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core";
import "@tanstack/router-core/ssr/server";
import "h3-v2";
import "tiny-invariant";
import "seroval";
import "@tanstack/react-router/ssr/server";
import "@convex-dev/better-auth/react";
import "@convex-dev/better-auth/react-start";
import "clsx";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@tanstack/react-router-with-query";
import "convex/react";
import "tailwind-merge";
import "better-auth/react";
import "@convex-dev/better-auth/client/plugins";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "@radix-ui/react-dialog";
import "@radix-ui/react-visually-hidden";
import "@radix-ui/react-select";
import "@tanstack/form-core";
import "@tanstack/react-store";
import "@radix-ui/react-label";
function extractGitHubRepoFromUrl(url) {
  if (!url) return void 0;
  try {
    const parsed = new URL(url);
    if (!parsed.hostname.includes("github.com")) {
      return void 0;
    }
    const segments = parsed.pathname.replace(/^\/+/, "").split("/");
    if (segments.length < 2) {
      return void 0;
    }
    const owner = segments[0]?.trim();
    let repo = segments[1]?.trim() ?? "";
    if (repo.endsWith(".git")) {
      repo = repo.slice(0, -4);
    }
    if (!owner || !repo) {
      return void 0;
    }
    return `${owner}/${repo}`;
  } catch {
    return void 0;
  }
}
function formatRelativeTime(dateInput) {
  const date = new Date(dateInput);
  if (Number.isNaN(date.getTime())) {
    return "";
  }
  const diffInMs = Date.now() - date.getTime();
  const diffInDays = diffInMs / (1e3 * 60 * 60 * 24);
  if (diffInDays < 1) {
    const diffInHours = diffInMs / (1e3 * 60 * 60);
    if (diffInHours < 1) {
      const diffInMinutes = Math.max(Math.round(diffInMs / (1e3 * 60)), 0);
      if (diffInMinutes === 0) return "just now";
      return `${diffInMinutes} minute${diffInMinutes === 1 ? "" : "s"} ago`;
    }
    const roundedHours = Math.round(diffInHours);
    return `${roundedHours} hour${roundedHours === 1 ? "" : "s"} ago`;
  }
  if (diffInDays < 7) {
    const roundedDays = Math.round(diffInDays);
    return `${roundedDays} day${roundedDays === 1 ? "" : "s"} ago`;
  }
  const diffInWeeks = diffInDays / 7;
  if (diffInWeeks < 5) {
    const roundedWeeks = Math.round(diffInWeeks);
    return `${roundedWeeks} week${roundedWeeks === 1 ? "" : "s"} ago`;
  }
  const diffInMonths = diffInDays / 30;
  if (diffInMonths < 12) {
    const roundedMonths = Math.round(diffInMonths);
    return `${roundedMonths} month${roundedMonths === 1 ? "" : "s"} ago`;
  }
  const diffInYears = diffInDays / 365;
  const roundedYears = Math.round(diffInYears);
  return `${roundedYears} year${roundedYears === 1 ? "" : "s"} ago`;
}
function RouteComponent4() {
  const session = useSession2();
  const [isAddModalOpen, setIsAddModalOpen] = useState4(false);
  const [addTaskPrefill, setAddTaskPrefill] = useState4(null);
  const [editingTaskId, setEditingTaskId] = useState4(null);
  const [editTaskForm, setEditTaskForm] = useState4({
    text: "",
    details: "",
    priority: "low",
    hrs: 1,
    refLink: "",
    projectId: "",
    sharedWith: ""
  });
  const [isSubmitting, setIsSubmitting] = useState4(false);
  const [now, setNow] = useState4(() => Date.now());
  const [viewMode, setViewMode] = useState4("collaborator");
  const queryClient = useQueryClient();
  const updateTask = useConvexMutation2(api.tasks.updateTask);
  const deleteTask = useConvexMutation2(api.tasks.deleteTask);
  const shareTaskWithCollaborators = useConvexMutation2(api.tasks.shareTaskWithCollaborators);
  const unshareTaskMutation = useConvexMutation2(api.tasks.unshareTask);
  const tasks = useConvexQuery2(api.tasks.listTasks, {});
  const projects = useConvexQuery2(api.projects.listProjects, {});
  const allCollaborators = useConvexQuery2(api.projects.getAllCollaborators, {});
  const emailToNameMap = useMemo3(() => {
    const map = /* @__PURE__ */ new Map();
    if (!allCollaborators) return map;
    allCollaborators.forEach((collaborator) => {
      const email = collaborator.email.toLowerCase().trim();
      if (collaborator.userName) {
        map.set(email, collaborator.userName);
      }
    });
    return map;
  }, [allCollaborators]);
  const getDisplayName = (email) => {
    const normalizedEmail = email.toLowerCase().trim();
    return emailToNameMap.get(normalizedEmail) || email;
  };
  const projectOptions = useMemo3(() => {
    if (!projects) return [];
    return projects.map((project) => ({
      _id: project._id,
      id: String(project._id),
      name: project.name,
      description: project.description,
      type: project.type,
      category: project.category,
      status: "",
      githubUrl: project.githubUrl
    }));
  }, [projects]);
  useEffect6(() => {
    const interval = window.setInterval(() => setNow(Date.now()), 6e4);
    return () => window.clearInterval(interval);
  }, []);
  const computeTrackedTime = (task) => {
    const base = task.trackedTimeMs ?? 0;
    const normalizedStatus = (task.status || "").toLowerCase();
    const isRunning = normalizedStatus === "in progress" || normalizedStatus === "in-progress" || normalizedStatus === "running";
    const active = task.startedAt && isRunning ? Math.max(0, now - task.startedAt) : 0;
    return base + active;
  };
  const formatDuration2 = (milliseconds) => {
    const totalSeconds = Math.floor(milliseconds / 1e3);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor(totalSeconds % 3600 / 60);
    const seconds = totalSeconds % 60;
    return [hours, minutes, seconds].map((part) => String(part).padStart(2, "0")).join(":");
  };
  const getProjectName = (projectId) => {
    if (!projectId || !projects) return null;
    return projects.find((p) => p._id === projectId)?.name || null;
  };
  const githubProjects = useMemo3(() => {
    if (!projects) return [];
    return projects.filter((project) => {
      const hasRepo = Boolean(project.githubRepo || extractGitHubRepoFromUrl(project.githubUrl));
      return hasRepo;
    });
  }, [projects]);
  const [selectedProjectId, setSelectedProjectId] = useState4(null);
  const [issueFetchNonce, setIssueFetchNonce] = useState4(0);
  const [selectedProjectIssues, setSelectedProjectIssues] = useState4({
    status: "idle",
    issues: [],
    error: void 0
  });
  useEffect6(() => {
    if (!githubProjects.length) {
      if (selectedProjectId !== null) {
        setSelectedProjectId(null);
      }
      return;
    }
    const exists = githubProjects.some((project) => String(project._id) === selectedProjectId);
    if (!exists) {
      setSelectedProjectId(String(githubProjects[0]._id));
    }
  }, [githubProjects, selectedProjectId]);
  const selectedProject = useMemo3(() => {
    if (!selectedProjectId) return null;
    return githubProjects.find((project) => String(project._id) === selectedProjectId) ?? null;
  }, [githubProjects, selectedProjectId]);
  useEffect6(() => {
    if (!selectedProject) {
      setSelectedProjectIssues({
        status: "idle",
        issues: [],
        error: void 0
      });
      return;
    }
    let cancelled = false;
    const fetchIssues = async () => {
      setSelectedProjectIssues({
        status: "loading",
        issues: [],
        error: void 0
      });
      const repo = selectedProject.githubRepo || extractGitHubRepoFromUrl(selectedProject.githubUrl);
      if (!repo) {
        setSelectedProjectIssues({
          status: "error",
          issues: [],
          error: "Repository link missing"
        });
        return;
      }
      try {
        const response = await fetch(`https://api.github.com/repos/${repo}/issues?per_page=10&sort=created&state=open`);
        if (!response.ok) {
          setSelectedProjectIssues({
            status: "error",
            issues: [],
            error: `GitHub responded ${response.status}`
          });
          return;
        }
        const data = await response.json();
        const issues = Array.isArray(data) ? data.filter((issue) => !issue.pull_request).slice(0, ISSUES_PER_PROJECT) : [];
        if (cancelled) return;
        setSelectedProjectIssues({
          status: "success",
          issues,
          error: void 0
        });
      } catch (error) {
        if (cancelled) return;
        const message = error instanceof Error ? error.message : "Failed to load issues";
        setSelectedProjectIssues({
          status: "error",
          issues: [],
          error: message
        });
      }
    };
    fetchIssues();
    return () => {
      cancelled = true;
    };
  }, [selectedProject, issueFetchNonce]);
  const handleRetry = () => {
    setIssueFetchNonce((prev) => prev + 1);
  };
  const getSharedEmails = (sharedWith) => {
    if (!sharedWith) return [];
    try {
      const emails = JSON.parse(sharedWith);
      return Array.isArray(emails) ? emails : [];
    } catch {
      return [];
    }
  };
  const userEmail = session?.user?.email;
  const userId = session?.user?.id;
  const sharedTasks = (tasks || []).filter((task) => {
    if (!userEmail || !userId) return false;
    const isOwnedByMe = task.userId === userId;
    const sharedEmails = getSharedEmails(task.sharedWith);
    const isSharedWithMe = sharedEmails.includes(userEmail);
    const isSharedByMe = isOwnedByMe && sharedEmails.length > 0;
    return isSharedWithMe || isSharedByMe;
  });
  const tasksSharedWithMe = sharedTasks.filter((task) => {
    if (task.userId === userId) return false;
    const status = (task.status || "").toLowerCase();
    return !status || status === "todo" || status === "backlog" || status === "not started";
  });
  const myTasksSharedWithOthers = sharedTasks.filter((task) => {
    if (task.userId !== userId) return false;
    const status = (task.status || "").toLowerCase();
    return !status || status === "todo" || status === "backlog" || status === "not started";
  });
  const handleCancelEdit = () => {
    setEditingTaskId(null);
    setEditTaskForm({
      text: "",
      details: "",
      priority: "low",
      hrs: 1,
      refLink: "",
      projectId: "",
      sharedWith: ""
    });
  };
  const handleEditTask = (task) => {
    setEditingTaskId(task._id);
    const sharedEmails = getSharedEmails(task.sharedWith);
    setEditTaskForm({
      text: task.text,
      details: task.details || "",
      priority: task.priority || "low",
      hrs: task.hrs || 1,
      refLink: task.refLink || "",
      projectId: task.projectId || "",
      sharedWith: sharedEmails.join(", ")
    });
  };
  const handleSubmitEdit = async () => {
    if (!editingTaskId || !editTaskForm.text.trim()) {
      return;
    }
    const taskId = editingTaskId;
    setIsSubmitting(true);
    try {
      const sharedWithJson = editTaskForm.sharedWith ? JSON.stringify(editTaskForm.sharedWith.split(",").map((email) => email.trim()).filter((email) => email)) : void 0;
      await updateTask({
        taskId,
        text: editTaskForm.text,
        details: editTaskForm.details || "",
        priority: editTaskForm.priority,
        hrs: editTaskForm.hrs,
        refLink: editTaskForm.refLink || "",
        projectId: editTaskForm.projectId || void 0,
        sharedWith: sharedWithJson
      });
      queryClient.invalidateQueries({
        predicate: (query2) => {
          const key = query2.queryKey;
          return Array.isArray(key) && key[0] === api.tasks.listTasks;
        }
      });
      setEditingTaskId(null);
      setEditTaskForm({
        text: "",
        details: "",
        priority: "low",
        hrs: 1,
        refLink: "",
        projectId: "",
        sharedWith: ""
      });
      toast2.success("Task updated successfully!");
    } catch (error) {
      console.error("Failed to update task:", error);
      toast2.error("Failed to update task. Please try again.");
      setEditingTaskId(taskId);
    } finally {
      setIsSubmitting(false);
    }
  };
  const handleToggleTask = async (task) => {
    const currentStatus = task.status || "todo";
    const newStatus = currentStatus === "done" ? "todo" : "done";
    try {
      await updateTask({
        taskId: task._id,
        status: newStatus
      });
      queryClient.invalidateQueries({
        predicate: (query2) => {
          const key = query2.queryKey;
          return Array.isArray(key) && key[0] === api.tasks.listTasks;
        }
      });
    } catch (error) {
      console.error("Failed to toggle task:", error);
      toast2.error("Failed to update task. Please try again.");
    }
  };
  const handleDeleteTask = async (task) => {
    try {
      await deleteTask({
        taskId: task._id
      });
      queryClient.invalidateQueries({
        predicate: (query2) => {
          const key = query2.queryKey;
          return Array.isArray(key) && key[0] === api.tasks.listTasks;
        }
      });
      toast2.success("Task deleted successfully");
    } catch (error) {
      console.error("Failed to delete task:", error);
      toast2.error("Failed to delete task. Please try again.");
    }
  };
  const handleShareTask = async (task) => {
    try {
      const result = await shareTaskWithCollaborators({
        taskId: task._id
      });
      if (!result?.success) {
        toast2.info(result?.message || "No collaborators to share with yet");
      } else if (result.added === 0) {
        toast2.info(result.message || "Task already shared with collaborators");
      } else {
        toast2.success(result.message || "Task shared with project collaborators");
      }
      queryClient.invalidateQueries({
        predicate: (query2) => {
          const key = query2.queryKey;
          return Array.isArray(key) && key[0] === api.tasks.listTasks;
        }
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to share task";
      toast2.error(message);
    }
  };
  const handleUnshareTask = async (task) => {
    try {
      await unshareTaskMutation({
        taskId: task._id
      });
      toast2.success("Task unshared from collaborators");
      queryClient.invalidateQueries({
        predicate: (query2) => {
          const key = query2.queryKey;
          return Array.isArray(key) && key[0] === api.tasks.listTasks;
        }
      });
    } catch (error) {
      console.error("Failed to unshare task:", error);
      toast2.error("Failed to unshare task. Please try again.");
    }
  };
  return /* @__PURE__ */ jsxs8("main", { className: "mx-auto flex w-full max-w-6xl flex-col gap-8 px-6 py-10 min-h-screen", children: [
    /* @__PURE__ */ jsxs8("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxs8("div", { children: [
        /* @__PURE__ */ jsx9("h1", { className: "text-3xl font-bold mb-6 text-foreground", children: "Review Center" }),
        /* @__PURE__ */ jsxs8("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxs8("div", { className: "flex items-start gap-2", children: [
            /* @__PURE__ */ jsx9(MessageSquare3, { className: "h-5 w-5 mt-0.5 text-blue-600 dark:text-blue-400 flex-shrink-0" }),
            /* @__PURE__ */ jsx9("p", { className: "text-base font-semibold leading-relaxed text-blue-700 dark:text-blue-300", children: "Task discussion and refinement" })
          ] }),
          /* @__PURE__ */ jsxs8("div", { className: "flex items-start gap-2", children: [
            /* @__PURE__ */ jsx9(GitBranch, { className: "h-5 w-5 mt-0.5 text-emerald-600 dark:text-emerald-400 flex-shrink-0" }),
            /* @__PURE__ */ jsxs8("p", { className: "text-base font-semibold leading-relaxed text-emerald-700 dark:text-emerald-300", children: [
              "Review new issues from ",
              /* @__PURE__ */ jsx9("span", { className: "font-bold text-emerald-800 dark:text-emerald-200", children: "GitHub" })
            ] })
          ] })
        ] })
      ] }),
      sharedTasks.length > 0 && /* @__PURE__ */ jsxs8("div", { className: "flex items-center gap-2 rounded-lg border border-slate-200/80 bg-white/90 p-1 shadow-sm dark:border-slate-700 dark:bg-slate-800", children: [
        /* @__PURE__ */ jsxs8("button", { type: "button", onClick: () => setViewMode("collaborator"), className: cn("flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors", viewMode === "collaborator" ? "bg-black text-white dark:bg-white dark:text-black" : "text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100"), children: [
          /* @__PURE__ */ jsx9(Users2, { className: "h-4 w-4" }),
          "Collaborator"
        ] }),
        /* @__PURE__ */ jsxs8("button", { type: "button", onClick: () => setViewMode("owner"), className: cn("flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors", viewMode === "owner" ? "bg-black text-white dark:bg-white dark:text-black" : "text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100"), children: [
          /* @__PURE__ */ jsx9(User3, { className: "h-4 w-4" }),
          "Owner"
        ] })
      ] })
    ] }),
    sharedTasks.length === 0 ? /* @__PURE__ */ jsxs8(Card, { className: "p-12 text-center", children: [
      /* @__PURE__ */ jsx9("p", { className: "text-muted-foreground text-lg", children: "No shared tasks available to refine." }),
      /* @__PURE__ */ jsx9("p", { className: "text-muted-foreground/70 text-sm mt-2", children: "Tasks shared with you or tasks you've shared with others will appear here." })
    ] }) : /* @__PURE__ */ jsxs8("div", { className: "mt-12 pt-10 border-t border-slate-200 dark:border-slate-800", children: [
      viewMode === "collaborator" && tasksSharedWithMe.length > 0 && /* @__PURE__ */ jsxs8("div", { children: [
        /* @__PURE__ */ jsxs8("h2", { className: "text-xl font-semibold mb-6 text-foreground flex items-center gap-2", children: [
          /* @__PURE__ */ jsx9(CheckSquare, { className: "h-5 w-5 text-blue-600 dark:text-blue-400" }),
          "From Collaborator (",
          tasksSharedWithMe.length,
          " task",
          tasksSharedWithMe.length !== 1 ? "s" : "",
          ")"
        ] }),
        /* @__PURE__ */ jsx9("div", { className: "flex flex-col items-center gap-6", children: tasksSharedWithMe.map((task, index) => {
          const normalizedStatus = (task.status || "").toLowerCase();
          const totalTrackedMs = computeTrackedTime(task);
          const isRunningTask = normalizedStatus === "in progress" || normalizedStatus === "in-progress" || normalizedStatus === "running";
          const runningTimeLabel = totalTrackedMs > 0 ? formatDuration2(totalTrackedMs) : null;
          const typedTask = {
            ...task,
            priority: task.priority ?? void 0,
            status: task.status,
            hrs: task.hrs ?? void 0,
            startedAt: task.startedAt ? new Date(task.startedAt) : null,
            completedAt: task.completedAt ? new Date(task.completedAt) : null,
            trackedTimeMs: task.trackedTimeMs ?? void 0
          };
          const projectName = typedTask.projectId ? getProjectName(typedTask.projectId) : null;
          const sharedEmails = getSharedEmails(typedTask.sharedWith);
          const sharedDisplayNames = sharedEmails.map((email) => getDisplayName(email));
          const isOwner = session?.user?.id === typedTask.userId;
          return /* @__PURE__ */ jsx9("div", { className: "mx-auto w-full max-w-3xl", style: {
            paddingTop: index === 0 ? "12px" : "32px"
          }, children: /* @__PURE__ */ jsx9(TaskCard, { task: typedTask, projectName, isOwner, sharedEmails: sharedDisplayNames, isEditing: editingTaskId === typedTask._id, editForm: editTaskForm, isSubmitting, projects: projectOptions, wrapperStyle: {
            margin: 0
          }, onEdit: () => handleEditTask(task), onDelete: () => handleDeleteTask(task), onToggle: () => handleToggleTask(task), onShare: () => handleShareTask(task), onUnshare: () => handleUnshareTask(task), onCancelEdit: handleCancelEdit, onSaveEdit: handleSubmitEdit, onEditFormChange: setEditTaskForm, runningTimeLabel, isRunning: isRunningTask, showRefinement: true, currentUserId: session?.user?.id || "" }) }, typedTask._id);
        }) })
      ] }),
      viewMode === "owner" && myTasksSharedWithOthers.length > 0 && /* @__PURE__ */ jsxs8("div", { children: [
        /* @__PURE__ */ jsxs8("h2", { className: "text-xl font-semibold mb-6 text-foreground flex items-center gap-2", children: [
          /* @__PURE__ */ jsx9(CheckSquare, { className: "h-5 w-5 text-emerald-600 dark:text-emerald-400" }),
          "To Collaborator (",
          myTasksSharedWithOthers.length,
          " task",
          myTasksSharedWithOthers.length !== 1 ? "s" : "",
          ")"
        ] }),
        /* @__PURE__ */ jsx9("div", { className: "flex flex-col items-center gap-6", children: myTasksSharedWithOthers.map((task, index) => {
          const normalizedStatus = (task.status || "").toLowerCase();
          const totalTrackedMs = computeTrackedTime(task);
          const isRunningTask = normalizedStatus === "in progress" || normalizedStatus === "in-progress" || normalizedStatus === "running";
          const runningTimeLabel = totalTrackedMs > 0 ? formatDuration2(totalTrackedMs) : null;
          const typedTask = {
            ...task,
            priority: task.priority ?? void 0,
            status: task.status,
            hrs: task.hrs ?? void 0,
            startedAt: task.startedAt ? new Date(task.startedAt) : null,
            completedAt: task.completedAt ? new Date(task.completedAt) : null,
            trackedTimeMs: task.trackedTimeMs ?? void 0
          };
          const projectName = typedTask.projectId ? getProjectName(typedTask.projectId) : null;
          const sharedEmails = getSharedEmails(typedTask.sharedWith);
          const sharedDisplayNames = sharedEmails.map((email) => getDisplayName(email));
          const isOwner = session?.user?.id === typedTask.userId;
          return /* @__PURE__ */ jsx9("div", { className: "mx-auto w-full max-w-3xl", style: {
            paddingTop: index === 0 ? "12px" : "32px"
          }, children: /* @__PURE__ */ jsx9(TaskCard, { task: typedTask, projectName, isOwner, sharedEmails: sharedDisplayNames, isEditing: editingTaskId === typedTask._id, editForm: editTaskForm, isSubmitting, projects: projectOptions, wrapperStyle: {
            margin: 0
          }, onEdit: () => handleEditTask(task), onDelete: () => handleDeleteTask(task), onToggle: () => handleToggleTask(task), onShare: () => handleShareTask(task), onUnshare: () => handleUnshareTask(task), onCancelEdit: handleCancelEdit, onSaveEdit: handleSubmitEdit, onEditFormChange: setEditTaskForm, runningTimeLabel, isRunning: isRunningTask, showRefinement: true, currentUserId: session?.user?.id || "" }) }, typedTask._id);
        }) })
      ] }),
      viewMode === "collaborator" && tasksSharedWithMe.length === 0 && /* @__PURE__ */ jsxs8(Card, { className: "p-12 text-center", children: [
        /* @__PURE__ */ jsx9("p", { className: "text-muted-foreground text-lg", children: "No tasks shared with you yet." }),
        /* @__PURE__ */ jsx9("p", { className: "text-muted-foreground/70 text-sm mt-2", children: "Tasks that others share with you will appear here." })
      ] }),
      viewMode === "owner" && myTasksSharedWithOthers.length === 0 && /* @__PURE__ */ jsxs8(Card, { className: "p-12 text-center", children: [
        /* @__PURE__ */ jsx9("p", { className: "text-muted-foreground text-lg", children: "No tasks shared with others yet." }),
        /* @__PURE__ */ jsx9("p", { className: "text-muted-foreground/70 text-sm mt-2", children: "Tasks you share with others will appear here." })
      ] })
    ] }),
    /* @__PURE__ */ jsxs8("section", { className: "mt-12 pt-10 border-t border-slate-200 dark:border-slate-800 flex flex-col gap-6", children: [
      /* @__PURE__ */ jsxs8("div", { children: [
        /* @__PURE__ */ jsxs8("h2", { className: "text-2xl font-bold mb-3 text-foreground flex items-center gap-2", children: [
          /* @__PURE__ */ jsx9(Github, { className: "h-5 w-5 text-blue-600 dark:text-blue-400" }),
          "GitHub Issue Radar"
        ] }),
        /* @__PURE__ */ jsx9("p", { className: "text-muted-foreground text-sm max-w-[640px] leading-relaxed", children: "We pull the two newest open issues from the project you pick\u2014perfect for spotting what needs attention next." })
      ] }),
      projects === void 0 ? /* @__PURE__ */ jsxs8(Card, { className: "p-8 flex items-center justify-center gap-3 bg-slate-50 dark:bg-slate-900/50 border-slate-200 dark:border-slate-800", children: [
        /* @__PURE__ */ jsx9(Loader2, { className: "h-5 w-5 animate-spin text-blue-600 dark:text-blue-400" }),
        /* @__PURE__ */ jsx9("span", { className: "text-muted-foreground text-sm font-medium", children: "Loading linked projects\u2026" })
      ] }) : githubProjects.length === 0 ? /* @__PURE__ */ jsx9(Card, { className: "p-8 bg-slate-50 dark:bg-slate-900/50 border-slate-200 dark:border-slate-800", children: /* @__PURE__ */ jsxs8("div", { className: "flex items-start gap-3", children: [
        /* @__PURE__ */ jsx9(Github, { className: "h-5 w-5 text-muted-foreground mt-0.5 flex-shrink-0" }),
        /* @__PURE__ */ jsx9("p", { className: "text-muted-foreground text-sm m-0 leading-relaxed", children: "Add a GitHub repository URL to one of your projects and it will appear here for quick issue syncing." })
      ] }) }) : /* @__PURE__ */ jsxs8("div", { className: "flex flex-col gap-6", children: [
        /* @__PURE__ */ jsxs8("div", { className: "flex flex-wrap items-center gap-4 bg-slate-50 dark:bg-slate-900/50 rounded-lg p-4 border border-slate-200 dark:border-slate-800", children: [
          /* @__PURE__ */ jsxs8("label", { className: "text-sm font-semibold text-foreground flex items-center gap-2", children: [
            /* @__PURE__ */ jsx9(Github, { className: "h-4 w-4 text-muted-foreground" }),
            "Project"
          ] }),
          /* @__PURE__ */ jsx9("div", { className: "min-w-[240px] flex-1", children: /* @__PURE__ */ jsxs8(Select, { value: selectedProjectId ?? void 0, onValueChange: (value) => setSelectedProjectId(value), children: [
            /* @__PURE__ */ jsx9(SelectTrigger, { className: "w-full bg-white dark:bg-slate-800", children: /* @__PURE__ */ jsx9(SelectValue, { placeholder: "Select a project" }) }),
            /* @__PURE__ */ jsx9(SelectContent, { children: githubProjects.map((project) => /* @__PURE__ */ jsx9(SelectItem, { value: String(project._id), children: project.name }, project._id)) })
          ] }) })
        ] }),
        selectedProject ? /* @__PURE__ */ jsx9(Card, { className: "border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden bg-white dark:bg-slate-900 shadow-sm hover:shadow-md transition-shadow", children: /* @__PURE__ */ jsxs8(CardContent, { className: "p-6 flex flex-col gap-6", children: [
          /* @__PURE__ */ jsxs8("div", { className: "flex justify-between items-start gap-4 flex-wrap pb-4 border-b border-slate-200 dark:border-slate-800", children: [
            /* @__PURE__ */ jsxs8("div", { className: "flex-[1_1_320px]", children: [
              /* @__PURE__ */ jsxs8("div", { className: "flex items-center gap-2 flex-wrap mb-3", children: [
                /* @__PURE__ */ jsx9(Github, { className: "h-5 w-5 text-blue-600 dark:text-blue-400" }),
                /* @__PURE__ */ jsx9("h3", { className: "text-xl font-bold text-foreground m-0", children: selectedProject.name })
              ] }),
              (() => {
                const repoSlug = selectedProject.githubRepo || extractGitHubRepoFromUrl(selectedProject.githubUrl);
                if (!repoSlug) return null;
                return /* @__PURE__ */ jsxs8("a", { href: `https://github.com/${repoSlug}`, target: "_blank", rel: "noopener noreferrer", className: "inline-flex items-center gap-1.5 text-sm font-medium text-blue-600 dark:text-blue-400 no-underline hover:text-blue-700 dark:hover:text-blue-300 hover:underline transition-colors", children: [
                  repoSlug,
                  /* @__PURE__ */ jsx9(ArrowUpRight, { size: 14 })
                ] });
              })(),
              selectedProject.description && selectedProject.description.trim().length > 0 && /* @__PURE__ */ jsx9("p", { className: "text-muted-foreground text-sm mt-3 mb-0 leading-relaxed", children: selectedProject.description })
            ] }),
            /* @__PURE__ */ jsx9(Badge, { variant: "outline", className: "text-xs px-3 py-1.5 bg-blue-50 dark:bg-blue-950/30 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800", children: "Latest Issues" })
          ] }),
          selectedProjectIssues.status === "loading" || selectedProjectIssues.status === "idle" ? /* @__PURE__ */ jsxs8("div", { className: "flex items-center justify-center gap-3 py-8 text-muted-foreground", children: [
            /* @__PURE__ */ jsx9(Loader2, { className: "h-5 w-5 animate-spin text-blue-600 dark:text-blue-400" }),
            /* @__PURE__ */ jsx9("span", { className: "text-sm font-medium", children: "Syncing GitHub issues\u2026" })
          ] }) : selectedProjectIssues.status === "error" ? /* @__PURE__ */ jsxs8("div", { className: "flex flex-col gap-4 p-4 bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-900 rounded-lg", children: [
            /* @__PURE__ */ jsxs8("div", { className: "flex items-center gap-2 text-red-700 dark:text-red-400", children: [
              /* @__PURE__ */ jsx9(AlertCircle, { className: "h-5 w-5" }),
              /* @__PURE__ */ jsx9("span", { className: "text-sm font-semibold", children: "We couldn't load issues for this repository." })
            ] }),
            /* @__PURE__ */ jsxs8("div", { className: "flex flex-wrap gap-3 items-center", children: [
              /* @__PURE__ */ jsx9(Button, { variant: "outline", size: "sm", onClick: handleRetry, className: "px-4 py-2 text-xs border-red-300 dark:border-red-800 text-red-700 dark:text-red-400 hover:bg-red-100 dark:hover:bg-red-950/40", children: "Try again" }),
              selectedProjectIssues.error && /* @__PURE__ */ jsx9("span", { className: "text-red-600 dark:text-red-500 text-xs", children: selectedProjectIssues.error })
            ] })
          ] }) : selectedProjectIssues.issues.length === 0 ? /* @__PURE__ */ jsxs8("div", { className: "text-center py-8", children: [
            /* @__PURE__ */ jsx9(Github, { className: "h-8 w-8 mx-auto mb-3 text-muted-foreground opacity-50" }),
            /* @__PURE__ */ jsx9("p", { className: "text-muted-foreground text-sm font-medium m-0", children: "No open issues found in the latest sync." })
          ] }) : /* @__PURE__ */ jsx9("div", { className: "flex flex-col gap-4", children: selectedProjectIssues.issues.map((issue, index) => /* @__PURE__ */ jsxs8("div", { className: "border border-slate-200 dark:border-slate-800 rounded-lg p-5 bg-slate-50 dark:bg-slate-900/50 hover:bg-slate-100 dark:hover:bg-slate-900 transition-colors flex flex-col gap-4", children: [
            /* @__PURE__ */ jsxs8("div", { className: "flex flex-wrap items-start justify-between gap-3", children: [
              /* @__PURE__ */ jsxs8("a", { href: issue.html_url, target: "_blank", rel: "noopener noreferrer", className: "inline-flex items-start gap-2 text-sm font-semibold text-foreground no-underline flex-[1_1_auto] min-w-0 hover:text-blue-600 dark:hover:text-blue-400 group transition-colors", children: [
                /* @__PURE__ */ jsxs8("span", { className: "text-muted-foreground font-mono text-xs mt-0.5", children: [
                  "#",
                  issue.number
                ] }),
                /* @__PURE__ */ jsx9("span", { className: "flex-[1_1_auto] min-w-0 leading-snug", children: issue.title }),
                /* @__PURE__ */ jsx9(ArrowUpRight, { size: 16, className: "mt-0.5 text-muted-foreground group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors flex-shrink-0" })
              ] }),
              /* @__PURE__ */ jsxs8(Button, { variant: "secondary", size: "sm", onClick: () => {
                if (!selectedProject) return;
                setAddTaskPrefill({
                  text: `${issue.title} #${issue.number}`,
                  refLink: issue.html_url,
                  projectId: selectedProject._id
                });
                setIsAddModalOpen(true);
              }, className: "inline-flex items-center gap-1.5 whitespace-nowrap bg-blue-50 dark:bg-blue-950/30 text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-950/50 border-blue-200 dark:border-blue-800", children: [
                /* @__PURE__ */ jsx9(ListTodo2, { size: 14 }),
                "Add Task"
              ] })
            ] }),
            /* @__PURE__ */ jsxs8("div", { className: "flex items-center gap-3 flex-wrap text-muted-foreground text-xs", children: [
              /* @__PURE__ */ jsx9(Badge, { variant: "outline", className: "text-[0.65rem] px-2 py-0.5 capitalize bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800", children: issue.state }),
              issue.user?.login && /* @__PURE__ */ jsxs8(Fragment3, { children: [
                /* @__PURE__ */ jsx9("span", { className: "text-slate-400 dark:text-slate-600", children: "\u2022" }),
                /* @__PURE__ */ jsxs8("span", { className: "font-medium", children: [
                  "by ",
                  issue.user.login
                ] })
              ] }),
              /* @__PURE__ */ jsx9("span", { className: "text-slate-400 dark:text-slate-600", children: "\u2022" }),
              /* @__PURE__ */ jsx9("span", { children: formatRelativeTime(issue.created_at) })
            ] }),
            Array.isArray(issue.labels) && issue.labels.length > 0 && /* @__PURE__ */ jsxs8("div", { className: "flex gap-2 flex-wrap pt-1", children: [
              issue.labels.slice(0, 3).map((label) => /* @__PURE__ */ jsx9(Badge, { variant: "outline", className: "text-[0.65rem] px-2 py-0.5 normal-case bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700", children: label.name }, `${issue.id}-${label.id ?? label.name}`)),
              issue.labels.length > 3 && /* @__PURE__ */ jsxs8(Badge, { variant: "outline", className: "text-[0.65rem] px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700", children: [
                "+",
                issue.labels.length - 3,
                " more"
              ] })
            ] })
          ] }, issue.id)) })
        ] }) }) : null
      ] })
    ] }),
    /* @__PURE__ */ jsx9(AddTaskModal, { open: isAddModalOpen, onOpenChange: (open) => {
      setIsAddModalOpen(open);
      if (!open) {
        setAddTaskPrefill(null);
        queryClient.invalidateQueries({
          predicate: (query2) => {
            const key = query2.queryKey;
            return Array.isArray(key) && key[0] === api.tasks.listTasks;
          }
        });
      }
    }, projectId: addTaskPrefill?.projectId, initialTask: addTaskPrefill ?? void 0 })
  ] });
}
var ISSUES_PER_PROJECT;
var init_refine_D_ImU73t = __esm({
  "dist/server/assets/refine-D_ImU73t.js"() {
    "use strict";
    init_api_DiONElen();
    init_router_BrR6fF9p();
    init_app_header_DDCic_DU();
    init_select_CNs7Rl3z();
    init_task_card_CGreDeOa();
    ISSUES_PER_PROJECT = 2;
  }
});

// dist/server/assets/checkbox-7uLehv8l.js
import { jsx as jsx10 } from "react/jsx-runtime";
import * as CheckboxPrimitive from "@radix-ui/react-checkbox";
import { CheckIcon } from "lucide-react";
function Checkbox({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx10(
    CheckboxPrimitive.Root,
    {
      "data-slot": "checkbox",
      className: cn(
        "peer border-input dark:bg-input/30 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground dark:data-[state=checked]:bg-primary data-[state=checked]:border-primary focus-visible:border-ring focus-visible:ring-ring/50 aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive size-4 shrink-0 rounded-[4px] border shadow-xs transition-shadow outline-none focus-visible:ring-[3px] disabled:cursor-not-allowed disabled:opacity-50",
        className
      ),
      ...props,
      children: /* @__PURE__ */ jsx10(
        CheckboxPrimitive.Indicator,
        {
          "data-slot": "checkbox-indicator",
          className: "grid place-content-center text-current transition-none flex items-center justify-center",
          children: /* @__PURE__ */ jsx10(CheckIcon, { className: "size-3.5 stroke-[3]" })
        }
      )
    }
  );
}
var init_checkbox_7uLehv8l = __esm({
  "dist/server/assets/checkbox-7uLehv8l.js"() {
    "use strict";
    init_app_header_DDCic_DU();
  }
});

// dist/server/assets/project-jEc4sHYE.js
var project_jEc4sHYE_exports = {};
__export(project_jEc4sHYE_exports, {
  ProjectCollaboratorsModal: () => ProjectCollaboratorsModal,
  component: () => ProjectsPage
});
import { jsx as jsx11, jsxs as jsxs9, Fragment as Fragment4 } from "react/jsx-runtime";
import { Link as Link3 } from "@tanstack/react-router";
import { useConvexMutation as useConvexMutation3, useConvexAction, useConvexQuery as useConvexQuery3 } from "@convex-dev/react-query";
import * as React3 from "react";
import React__default, { useEffect as useEffect7, useRef as useRef3, useState as useState5, useCallback, useMemo as useMemo4 } from "react";
import { Sparkles, X, ImageIcon, Upload, AlertCircle as AlertCircle2, Clock as Clock2, Check as Check3, RefreshCcw, Loader2 as Loader22, Flag as Flag2, Link2 as Link22, Pencil as Pencil2, Star, GitFork, Package, Target, Calendar, Github as Github2, ExternalLink, TrendingUp, Users as Users3, Plus, CheckCircle2 as CheckCircle22, XCircle, Trash2 as Trash22, Book, Wrench, Database, Monitor, Smartphone, Globe, MoreHorizontal, Edit, Download, Eye, RefreshCw, Crown, CheckSquare as CheckSquare2, FolderOpen, LayoutGrid, List, FolderKanban as FolderKanban3 } from "lucide-react";
import { useQueryClient as useQueryClient2 } from "@tanstack/react-query";
import { toast as toast3 } from "sonner";
import { z } from "zod";
import { useThreadMessages } from "@convex-dev/agent/react";
import * as SeparatorPrimitive from "@radix-ui/react-separator";
import * as TooltipPrimitive from "@radix-ui/react-tooltip";
import { cva as cva3 } from "class-variance-authority";
import { useMotionValue, motion as motion2, useTransform, useSpring } from "framer-motion";
import "convex/server";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core";
import "@tanstack/router-core/ssr/server";
import "h3-v2";
import "tiny-invariant";
import "seroval";
import "@tanstack/react-router/ssr/server";
import "@convex-dev/better-auth/react";
import "@convex-dev/better-auth/react-start";
import "clsx";
import "@radix-ui/react-slot";
import "@tanstack/react-router-with-query";
import "convex/react";
import "tailwind-merge";
import "better-auth/react";
import "@convex-dev/better-auth/client/plugins";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "@radix-ui/react-dialog";
import "@radix-ui/react-visually-hidden";
import "@radix-ui/react-select";
import "@tanstack/form-core";
import "@tanstack/react-store";
import "@radix-ui/react-label";
import "@radix-ui/react-checkbox";
function AddProjectModal({ open, onOpenChange }) {
  const queryClient = useQueryClient2();
  const createProject = useConvexMutation3(api.projects.createProject);
  const form = useForm({
    defaultValues: {
      name: "",
      description: "",
      status: "planning",
      githubUrl: ""
    },
    onSubmit: async ({ value, formApi }) => {
      try {
        const trimmedGithubUrl = value.githubUrl.trim();
        const submitData = {
          id: generateProjectId(value.name),
          name: value.name.trim(),
          description: value.description.trim(),
          status: value.status,
          githubUrl: trimmedGithubUrl ? trimmedGithubUrl : void 0
        };
        await createProject(submitData);
        queryClient.invalidateQueries({
          predicate: (query2) => {
            const key = query2.queryKey;
            return Array.isArray(key) && (key[0] === api.projects.listProjects || key[0] === api.projects.getProject);
          }
        });
        toast3.success("Project created successfully!");
        formApi.reset();
        onOpenChange(false);
      } catch (error) {
        toast3.error("Failed to create project");
        console.error("Create project error:", error);
      }
    }
  });
  const generateProjectId = (name) => {
    const base = name.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
    const fallback = "project";
    const slug = base.length > 0 ? base : fallback;
    const randomSuffix = Math.random().toString(36).slice(2, 8);
    return `${slug}-${randomSuffix}`;
  };
  const handleClose = () => {
    form.reset();
    onOpenChange(false);
  };
  useEffect7(() => {
    if (open) {
      form.reset();
    }
  }, [open, form]);
  return /* @__PURE__ */ jsx11(
    Dialog,
    {
      open,
      onOpenChange: (nextOpen) => {
        if (!nextOpen) {
          handleClose();
        } else {
          form.reset();
          onOpenChange(true);
        }
      },
      children: /* @__PURE__ */ jsxs9(DialogContent, { className: "max-w-2xl max-h-[90vh] overflow-y-auto border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800 backdrop-blur-xl supports-[backdrop-filter]:bg-white/90", children: [
        /* @__PURE__ */ jsxs9(DialogHeader, { children: [
          /* @__PURE__ */ jsxs9(DialogTitle, { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx11(Sparkles, { className: "h-5 w-5 text-gray-600 dark:text-gray-400" }),
            "Create New Project"
          ] }),
          /* @__PURE__ */ jsx11(DialogDescription, { children: "Create a new project to organize your tasks" })
        ] }),
        /* @__PURE__ */ jsxs9(
          "form",
          {
            onSubmit: (event) => {
              event.preventDefault();
              form.handleSubmit();
            },
            className: "space-y-6",
            children: [
              /* @__PURE__ */ jsxs9("div", { className: "space-y-4", children: [
                /* @__PURE__ */ jsx11("h3", { className: "text-lg font-medium", children: "Basic Information" }),
                /* @__PURE__ */ jsx11(
                  form.Field,
                  {
                    name: "name",
                    validators: {
                      onChange: ({ value }) => validateProjectName$1(value),
                      onBlur: ({ value }) => validateProjectName$1(value),
                      onSubmit: ({ value }) => validateProjectName$1(value)
                    },
                    children: (field) => {
                      const errorMessage = field.state.meta.errors?.[0];
                      return /* @__PURE__ */ jsxs9("div", { className: "space-y-2", children: [
                        /* @__PURE__ */ jsx11(Label3, { htmlFor: "name", children: "Project Name *" }),
                        /* @__PURE__ */ jsx11(
                          Input,
                          {
                            id: "name",
                            value: field.state.value,
                            placeholder: "e.g., My Awesome Project",
                            onBlur: field.handleBlur,
                            onChange: (event) => field.handleChange(event.target.value)
                          }
                        ),
                        errorMessage ? /* @__PURE__ */ jsx11("p", { className: "text-sm text-red-600 dark:text-red-400", children: errorMessage }) : null
                      ] });
                    }
                  }
                ),
                /* @__PURE__ */ jsx11(form.Field, { name: "description", children: (field) => /* @__PURE__ */ jsxs9("div", { className: "space-y-2", children: [
                  /* @__PURE__ */ jsx11(Label3, { htmlFor: "description", children: "Description" }),
                  /* @__PURE__ */ jsx11(
                    Textarea,
                    {
                      id: "description",
                      value: field.state.value,
                      placeholder: "Enter project description (optional)...",
                      rows: 3,
                      onBlur: field.handleBlur,
                      onChange: (event) => field.handleChange(event.target.value)
                    }
                  )
                ] }) }),
                /* @__PURE__ */ jsxs9("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                  /* @__PURE__ */ jsx11(
                    form.Field,
                    {
                      name: "status",
                      validators: {
                        onChange: ({ value }) => statusOptions$1.includes(value) ? void 0 : "Select a valid status",
                        onSubmit: ({ value }) => statusOptions$1.includes(value) ? void 0 : "Select a valid status"
                      },
                      children: (field) => {
                        const errorMessage = field.state.meta.errors?.[0];
                        return /* @__PURE__ */ jsxs9("div", { className: "space-y-2", children: [
                          /* @__PURE__ */ jsx11(Label3, { htmlFor: "status", children: "Status" }),
                          /* @__PURE__ */ jsxs9(Select, { value: field.state.value, onValueChange: (value) => field.handleChange(value), children: [
                            /* @__PURE__ */ jsx11(SelectTrigger, { className: "flex h-11 items-center justify-between rounded-lg border border-slate-200/80 bg-white/90 px-3 text-sm font-medium shadow-sm transition-colors focus:outline-none focus:ring-2 focus:ring-ring dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100", children: /* @__PURE__ */ jsx11(SelectValue, { placeholder: "Select status" }) }),
                            /* @__PURE__ */ jsx11(SelectContent, { className: "z-50 rounded-xl border border-slate-200/80 bg-white/95 shadow-xl dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100", children: statusOptions$1.map((status) => {
                              const displayLabel = status === "official-release" ? "Official Release" : status.charAt(0).toUpperCase() + status.slice(1);
                              return /* @__PURE__ */ jsx11(SelectItem, { value: status, children: displayLabel }, status);
                            }) })
                          ] }),
                          errorMessage ? /* @__PURE__ */ jsx11("p", { className: "text-sm text-red-600 dark:text-red-400", children: errorMessage }) : null
                        ] });
                      }
                    }
                  ),
                  /* @__PURE__ */ jsx11(
                    form.Field,
                    {
                      name: "githubUrl",
                      validators: {
                        onBlur: ({ value }) => validateGithubUrl$1(value),
                        onSubmit: ({ value }) => validateGithubUrl$1(value)
                      },
                      children: (field) => {
                        const errorMessage = field.state.meta.errors?.[0];
                        return /* @__PURE__ */ jsxs9("div", { className: "space-y-2", children: [
                          /* @__PURE__ */ jsx11(Label3, { htmlFor: "githubUrl", children: "GitHub URL" }),
                          /* @__PURE__ */ jsx11(
                            Input,
                            {
                              id: "githubUrl",
                              value: field.state.value,
                              placeholder: "https://github.com/username/repository",
                              onBlur: field.handleBlur,
                              onChange: (event) => field.handleChange(event.target.value)
                            }
                          ),
                          errorMessage ? /* @__PURE__ */ jsx11("p", { className: "text-sm text-red-600 dark:text-red-400", children: errorMessage }) : null
                        ] });
                      }
                    }
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsxs9(DialogFooter, { children: [
                /* @__PURE__ */ jsx11(Button, { type: "button", variant: "outline", onClick: handleClose, children: "Cancel" }),
                /* @__PURE__ */ jsx11(
                  Button,
                  {
                    type: "submit",
                    disabled: form.state.isSubmitting,
                    className: "bg-black dark:bg-white text-white dark:text-black hover:bg-gray-800 dark:hover:bg-gray-200",
                    children: form.state.isSubmitting ? "Creating..." : "Create Project"
                  }
                )
              ] })
            ]
          }
        )
      ] })
    }
  );
}
function EditProjectModal({
  open,
  onOpenChange,
  project
}) {
  const queryClient = useQueryClient2();
  const updateProject = useConvexMutation3(api.projects.updateProject);
  const form = useForm({
    defaultValues: {
      name: "",
      description: "",
      status: "planning",
      githubUrl: ""
    },
    onSubmit: async ({ value, formApi }) => {
      if (!project) {
        toast3.error("Project is missing. Please reopen the modal.");
        return;
      }
      try {
        await updateProject({
          projectId: project._id,
          name: value.name.trim(),
          description: value.description.trim(),
          status: value.status,
          githubUrl: value.githubUrl.trim() ? value.githubUrl.trim() : void 0
        });
        queryClient.invalidateQueries({
          predicate: (query2) => {
            const key = query2.queryKey;
            return Array.isArray(key) && (key[0] === api.projects.listProjects || key[0] === api.projects.getProject);
          }
        });
        toast3.success("Project updated successfully!");
        formApi.reset();
        onOpenChange(false);
      } catch (error) {
        console.error("Failed to update project:", error);
        toast3.error(error instanceof Error ? error.message : "Failed to update project. Please try again.");
      }
    }
  });
  useEffect7(() => {
    if (open && project) {
      const validStatus = statusOptions.includes(project.status) ? project.status : "planning";
      form.reset({
        name: project.name ?? "",
        description: project.description ?? "",
        status: validStatus,
        githubUrl: project.githubUrl || project.websiteUrl || ""
      });
    }
  }, [open, project?._id]);
  const handleClose = () => {
    if (!form.state.isSubmitting) {
      form.reset();
      onOpenChange(false);
    }
  };
  if (!project) {
    return null;
  }
  return /* @__PURE__ */ jsx11(
    Dialog,
    {
      open,
      onOpenChange: (nextOpen) => {
        if (!nextOpen) {
          handleClose();
        } else {
          onOpenChange(true);
        }
      },
      children: /* @__PURE__ */ jsxs9(DialogContent, { className: "max-w-2xl max-h-[90vh] overflow-y-auto bg-white dark:bg-slate-800 border-gray-200 dark:border-slate-700", children: [
        /* @__PURE__ */ jsxs9(DialogHeader, { children: [
          /* @__PURE__ */ jsxs9(DialogTitle, { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx11(Sparkles, { className: "h-5 w-5 text-gray-600 dark:text-gray-400" }),
            "Edit Project"
          ] }),
          /* @__PURE__ */ jsx11(DialogDescription, { children: "Update project details" })
        ] }),
        /* @__PURE__ */ jsxs9(
          "form",
          {
            onSubmit: (event) => {
              event.preventDefault();
              form.handleSubmit();
            },
            className: "space-y-6",
            children: [
              /* @__PURE__ */ jsxs9("div", { className: "space-y-4", children: [
                /* @__PURE__ */ jsx11("h3", { className: "text-lg font-medium", children: "Basic Information" }),
                /* @__PURE__ */ jsx11(
                  form.Field,
                  {
                    name: "name",
                    validators: {
                      onChange: ({ value }) => validateProjectName(value),
                      onBlur: ({ value }) => validateProjectName(value),
                      onSubmit: ({ value }) => validateProjectName(value)
                    },
                    children: (field) => {
                      const errorMessage = field.state.meta.errors?.[0];
                      return /* @__PURE__ */ jsxs9("div", { className: "space-y-2", children: [
                        /* @__PURE__ */ jsx11(Label3, { htmlFor: "edit-project-name", children: "Project Name *" }),
                        /* @__PURE__ */ jsx11(
                          Input,
                          {
                            id: "edit-project-name",
                            placeholder: "e.g., My Awesome Project",
                            value: field.state.value,
                            onBlur: field.handleBlur,
                            onChange: (event) => field.handleChange(event.target.value),
                            disabled: form.state.isSubmitting,
                            required: true
                          }
                        ),
                        errorMessage ? /* @__PURE__ */ jsx11("p", { className: "text-sm text-red-600 dark:text-red-400", children: errorMessage }) : null
                      ] });
                    }
                  }
                ),
                /* @__PURE__ */ jsx11(form.Field, { name: "description", children: (field) => /* @__PURE__ */ jsxs9("div", { className: "space-y-2", children: [
                  /* @__PURE__ */ jsx11(Label3, { htmlFor: "edit-project-description", children: "Description" }),
                  /* @__PURE__ */ jsx11(
                    Textarea,
                    {
                      id: "edit-project-description",
                      placeholder: "Enter project description (optional)...",
                      value: field.state.value,
                      onBlur: field.handleBlur,
                      onChange: (event) => field.handleChange(event.target.value),
                      disabled: form.state.isSubmitting,
                      rows: 3
                    }
                  )
                ] }) }),
                /* @__PURE__ */ jsxs9("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                  /* @__PURE__ */ jsx11(
                    form.Field,
                    {
                      name: "status",
                      validators: {
                        onChange: ({ value }) => statusOptions.includes(value) ? void 0 : "Select a valid status",
                        onSubmit: ({ value }) => statusOptions.includes(value) ? void 0 : "Select a valid status"
                      },
                      children: (field) => {
                        const errorMessage = field.state.meta.errors?.[0];
                        return /* @__PURE__ */ jsxs9("div", { className: "space-y-2", children: [
                          /* @__PURE__ */ jsx11(Label3, { htmlFor: "edit-project-status", children: "Status" }),
                          /* @__PURE__ */ jsxs9(
                            Select,
                            {
                              value: field.state.value,
                              onValueChange: (value) => {
                                field.handleChange(value);
                              },
                              disabled: form.state.isSubmitting,
                              children: [
                                /* @__PURE__ */ jsx11(SelectTrigger, { className: "flex h-11 items-center justify-between rounded-lg border border-slate-200/80 bg-white/90 px-3 text-sm font-medium shadow-sm transition-colors focus:outline-none focus:ring-2 focus:ring-ring dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100", children: /* @__PURE__ */ jsx11(SelectValue, { placeholder: "Select status" }) }),
                                /* @__PURE__ */ jsx11(SelectContent, { className: "z-50 rounded-xl border border-slate-200/80 bg-white/95 shadow-xl dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100", children: statusOptions.map((option) => {
                                  const displayLabel = option === "official-release" ? "Official Release" : option.charAt(0).toUpperCase() + option.slice(1);
                                  return /* @__PURE__ */ jsx11(SelectItem, { value: option, children: displayLabel }, option);
                                }) })
                              ]
                            }
                          ),
                          errorMessage ? /* @__PURE__ */ jsx11("p", { className: "text-sm text-red-600 dark:text-red-400", children: errorMessage }) : null
                        ] });
                      }
                    }
                  ),
                  /* @__PURE__ */ jsx11(
                    form.Field,
                    {
                      name: "githubUrl",
                      validators: {
                        onBlur: ({ value }) => validateGithubUrl(value),
                        onSubmit: ({ value }) => validateGithubUrl(value)
                      },
                      children: (field) => {
                        const errorMessage = field.state.meta.errors?.[0];
                        return /* @__PURE__ */ jsxs9("div", { className: "space-y-2", children: [
                          /* @__PURE__ */ jsx11(Label3, { htmlFor: "edit-project-github", children: "GitHub URL" }),
                          /* @__PURE__ */ jsx11(
                            Input,
                            {
                              id: "edit-project-github",
                              placeholder: "https://github.com/username/repository",
                              value: field.state.value,
                              onBlur: field.handleBlur,
                              onChange: (event) => field.handleChange(event.target.value),
                              disabled: form.state.isSubmitting
                            }
                          ),
                          errorMessage ? /* @__PURE__ */ jsx11("p", { className: "text-sm text-red-600 dark:text-red-400", children: errorMessage }) : null
                        ] });
                      }
                    }
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsxs9(DialogFooter, { children: [
                /* @__PURE__ */ jsx11(
                  Button,
                  {
                    type: "button",
                    variant: "outline",
                    onClick: handleClose,
                    disabled: form.state.isSubmitting,
                    children: "Cancel"
                  }
                ),
                /* @__PURE__ */ jsx11(
                  Button,
                  {
                    type: "submit",
                    disabled: form.state.isSubmitting || !form.state.values.name.trim(),
                    className: "bg-black dark:bg-white text-white dark:text-black hover:bg-gray-800 dark:hover:bg-gray-200",
                    children: form.state.isSubmitting ? "Updating..." : "Update Project"
                  }
                )
              ] })
            ]
          }
        )
      ] })
    }
  );
}
function ImageUpload({
  onImageSelect,
  onImageRemove,
  selectedImage,
  maxSizeMb = DEFAULT_MAX_SIZE_MB,
  acceptedFormats = DEFAULT_ACCEPTED,
  className
}) {
  const inputRef = useRef3(null);
  const [dragActive, setDragActive] = useState5(false);
  const [error, setError] = useState5(null);
  const [previewUrl, setPreviewUrl] = useState5(null);
  useEffect7(() => {
    if (!selectedImage) {
      setPreviewUrl(null);
      return;
    }
    const objectUrl = URL.createObjectURL(selectedImage);
    setPreviewUrl(objectUrl);
    return () => {
      URL.revokeObjectURL(objectUrl);
    };
  }, [selectedImage]);
  const validateFile = useCallback(
    (file) => {
      if (!acceptedFormats.includes(file.type)) {
        setError(`Unsupported file type. Allowed: ${acceptedFormats.join(", ")}`);
        return false;
      }
      const sizeMb = file.size / (1024 * 1024);
      if (sizeMb > maxSizeMb) {
        setError(`File is too large. Maximum size is ${maxSizeMb}MB.`);
        return false;
      }
      setError(null);
      return true;
    },
    [acceptedFormats, maxSizeMb]
  );
  const handleFiles = useCallback(
    (files) => {
      if (!files || files.length === 0) return;
      const file = files[0];
      if (!validateFile(file)) return;
      onImageSelect(file);
    },
    [onImageSelect, validateFile]
  );
  const handleDrop = useCallback(
    (event) => {
      event.preventDefault();
      setDragActive(false);
      if (event.dataTransfer.files && event.dataTransfer.files.length > 0) {
        handleFiles(event.dataTransfer.files);
        event.dataTransfer.clearData();
      }
    },
    [handleFiles]
  );
  const handleDragOver = useCallback((event) => {
    event.preventDefault();
    setDragActive(true);
  }, []);
  const handleDragLeave = useCallback((event) => {
    event.preventDefault();
    setDragActive(false);
  }, []);
  return /* @__PURE__ */ jsxs9("div", { className: cn("space-y-3", className), children: [
    /* @__PURE__ */ jsxs9(
      "div",
      {
        onDrop: handleDrop,
        onDragOver: handleDragOver,
        onDragLeave: handleDragLeave,
        className: cn(
          "relative flex flex-col items-center justify-center rounded-xl border-2 border-dashed p-8 transition-colors",
          dragActive ? "border-primary bg-primary/5" : "border-slate-200 dark:border-slate-800",
          selectedImage ? "bg-slate-50 dark:bg-slate-900/40" : "bg-white dark:bg-slate-950"
        ),
        children: [
          previewUrl ? /* @__PURE__ */ jsxs9("div", { className: "relative w-full max-w-sm", children: [
            /* @__PURE__ */ jsx11(
              "img",
              {
                src: previewUrl,
                alt: selectedImage?.name ?? "Uploaded image",
                className: "w-full rounded-lg object-cover shadow-lg"
              }
            ),
            /* @__PURE__ */ jsx11(
              Button,
              {
                type: "button",
                variant: "secondary",
                size: "icon",
                className: "absolute top-2 right-2 h-8 w-8 rounded-full bg-white/90 text-slate-700 shadow",
                onClick: () => {
                  onImageRemove?.();
                  setPreviewUrl(null);
                },
                children: /* @__PURE__ */ jsx11(X, { className: "h-4 w-4" })
              }
            )
          ] }) : /* @__PURE__ */ jsxs9("div", { className: "flex flex-col items-center text-center", children: [
            /* @__PURE__ */ jsx11("div", { className: "mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-slate-100 dark:bg-slate-900", children: /* @__PURE__ */ jsx11(ImageIcon, { className: "h-8 w-8 text-slate-400" }) }),
            /* @__PURE__ */ jsx11("p", { className: "text-base font-semibold text-slate-800 dark:text-slate-100", children: "Drag & drop an image here" }),
            /* @__PURE__ */ jsxs9("p", { className: "mt-1 text-sm text-slate-500 dark:text-slate-400", children: [
              "PNG, JPG, or WebP up to ",
              maxSizeMb,
              "MB"
            ] }),
            /* @__PURE__ */ jsxs9(
              Button,
              {
                type: "button",
                variant: "outline",
                className: "mt-4",
                onClick: () => inputRef.current?.click(),
                children: [
                  /* @__PURE__ */ jsx11(Upload, { className: "mr-2 h-4 w-4" }),
                  "Browse Files"
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsx11(
            "input",
            {
              ref: inputRef,
              type: "file",
              accept: acceptedFormats.join(","),
              className: "hidden",
              onChange: (event) => handleFiles(event.target.files)
            }
          )
        ]
      }
    ),
    selectedImage && /* @__PURE__ */ jsxs9("div", { className: "rounded-lg bg-slate-50 dark:bg-slate-900/60 p-4", children: [
      /* @__PURE__ */ jsx11("p", { className: "text-sm font-medium text-slate-700 dark:text-slate-200", children: selectedImage.name }),
      /* @__PURE__ */ jsxs9("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: [
        (selectedImage.size / (1024 * 1024)).toFixed(2),
        " MB \u2022 ",
        selectedImage.type
      ] })
    ] }),
    error && /* @__PURE__ */ jsx11("p", { className: "text-sm text-destructive", role: "alert", children: error })
  ] });
}
function ImageAnalyticsModal({
  isOpen,
  onClose,
  projectId,
  projectName,
  onBeginSession
}) {
  const [selectedImage, setSelectedImage] = useState5(null);
  const [imageDataUrl, setImageDataUrl] = useState5(null);
  const [contextNotes, setContextNotes] = useState5("");
  const [defaultPriority, setDefaultPriority] = useState5(DEFAULT_ANALYSIS_PRIORITY);
  const [defaultHours, setDefaultHours] = useState5(1);
  const [errorMessage, setErrorMessage] = useState5(null);
  useEffect7(() => {
    if (!isOpen) {
      setSelectedImage(null);
      setImageDataUrl(null);
      setContextNotes("");
      setDefaultPriority(DEFAULT_ANALYSIS_PRIORITY);
      setDefaultHours(1);
      setErrorMessage(null);
    }
  }, [isOpen]);
  const projectContext = useMemo4(() => {
    if (!projectName) return contextNotes.trim() || void 0;
    const extra = contextNotes.trim();
    return extra ? `${projectName} \u2014 ${extra}` : projectName;
  }, [projectName, contextNotes]);
  const handleImageSelect = useCallback((file) => {
    setSelectedImage(file);
    setErrorMessage(null);
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result;
      if (typeof result === "string") {
        setImageDataUrl(result);
      }
    };
    reader.onerror = () => {
      setErrorMessage("We couldn't read that file. Please try a different image.");
    };
    reader.readAsDataURL(file);
  }, []);
  const handleImageRemove = useCallback(() => {
    setSelectedImage(null);
    setImageDataUrl(null);
    setErrorMessage(null);
  }, []);
  const handleBeginSession = useCallback(() => {
    if (!imageDataUrl) {
      setErrorMessage("Upload an image before analyzing.");
      return;
    }
    onBeginSession({
      imageDataUrl,
      context: projectContext,
      defaultPriority,
      defaultHours,
      projectId,
      projectName
    });
    onClose();
  }, [imageDataUrl, projectContext, defaultPriority, defaultHours, projectId, projectName, onBeginSession, onClose]);
  const isAnalyzeDisabled = !selectedImage || !imageDataUrl;
  return /* @__PURE__ */ jsx11(Dialog, { open: isOpen, onOpenChange: (open) => open ? void 0 : onClose(), children: /* @__PURE__ */ jsxs9(DialogContent, { className: "flex h-[92vh] w-full max-w-3xl flex-col overflow-hidden border border-border/60 bg-white dark:bg-slate-900 dark:border-slate-800 backdrop-blur-xl supports-[backdrop-filter]:bg-white/90", children: [
    /* @__PURE__ */ jsxs9(DialogHeader, { className: "flex-shrink-0", children: [
      /* @__PURE__ */ jsxs9(DialogTitle, { className: "flex items-center gap-2 text-xl", children: [
        /* @__PURE__ */ jsx11(Sparkles, { className: "h-5 w-5 text-primary" }),
        "Analyze Image for Tasks"
      ] }),
      /* @__PURE__ */ jsx11(DialogDescription, { children: "Upload a screenshot, whiteboard, or hand-written plan. We'll hand it off to the AI session to extract tasks." })
    ] }),
    /* @__PURE__ */ jsxs9("div", { className: "flex-1 space-y-6 overflow-y-auto px-0 py-2", children: [
      /* @__PURE__ */ jsxs9("div", { className: "rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-900", children: [
        /* @__PURE__ */ jsx11("p", { className: "text-sm font-medium text-slate-700 dark:text-slate-200", children: "Workflow" }),
        /* @__PURE__ */ jsxs9("ol", { className: "mt-2 grid gap-2 text-sm text-slate-600 dark:text-slate-300 sm:grid-cols-3", children: [
          /* @__PURE__ */ jsx11("li", { className: "font-semibold text-primary", children: "1. Upload image" }),
          /* @__PURE__ */ jsx11("li", { children: "2. AI review" }),
          /* @__PURE__ */ jsx11("li", { children: "3. Create tasks" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs9("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsx11(
          ImageUpload,
          {
            selectedImage,
            onImageSelect: handleImageSelect,
            onImageRemove: handleImageRemove
          }
        ),
        /* @__PURE__ */ jsxs9("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxs9(Label3, { htmlFor: "analysis-context", className: "text-sm font-medium", children: [
            "Additional context ",
            /* @__PURE__ */ jsx11("span", { className: "text-xs text-muted-foreground", children: "(optional)" })
          ] }),
          /* @__PURE__ */ jsx11(
            Input,
            {
              id: "analysis-context",
              placeholder: "Describe what the image contains or desired outcomes",
              value: contextNotes,
              onChange: (event) => setContextNotes(event.target.value)
            }
          )
        ] }),
        /* @__PURE__ */ jsxs9("div", { className: "flex flex-col gap-4 sm:flex-row", children: [
          /* @__PURE__ */ jsxs9("div", { className: "flex-1 space-y-2", children: [
            /* @__PURE__ */ jsx11(Label3, { htmlFor: "default-priority", className: "text-sm font-medium", children: "Default priority" }),
            /* @__PURE__ */ jsxs9(Select, { value: defaultPriority, onValueChange: (value) => setDefaultPriority(value), children: [
              /* @__PURE__ */ jsx11(SelectTrigger, { id: "default-priority", className: "capitalize", children: /* @__PURE__ */ jsx11(SelectValue, {}) }),
              /* @__PURE__ */ jsxs9(SelectContent, { children: [
                /* @__PURE__ */ jsx11(SelectItem, { value: "low", children: "Low" }),
                /* @__PURE__ */ jsx11(SelectItem, { value: "medium", children: "Medium" }),
                /* @__PURE__ */ jsx11(SelectItem, { value: "high", children: "High" })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs9("div", { className: "flex-1 space-y-2", children: [
            /* @__PURE__ */ jsx11(Label3, { htmlFor: "default-hours", className: "text-sm font-medium", children: "Default estimate (hrs)" }),
            /* @__PURE__ */ jsx11(
              Input,
              {
                id: "default-hours",
                type: "number",
                min: "0",
                step: "0.25",
                value: defaultHours,
                onChange: (event) => setDefaultHours(Number(event.target.value) || 0)
              }
            )
          ] })
        ] }),
        errorMessage && /* @__PURE__ */ jsxs9("div", { className: "flex items-start gap-2 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700 dark:border-red-900/50 dark:bg-red-950/40 dark:text-red-200", children: [
          /* @__PURE__ */ jsx11(AlertCircle2, { className: "mt-0.5 h-4 w-4" }),
          /* @__PURE__ */ jsx11("span", { children: errorMessage })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs9(DialogFooter, { className: "flex-shrink-0 flex items-center justify-end gap-2 pt-4", children: [
      /* @__PURE__ */ jsx11(Button, { variant: "outline", onClick: onClose, children: "Cancel" }),
      /* @__PURE__ */ jsx11(Button, { onClick: handleBeginSession, disabled: isAnalyzeDisabled, children: isAnalyzeDisabled ? "Upload an image" : "Analyze image" })
    ] })
  ] }) });
}
function ImageAnalysisResults({
  analysis,
  selectedTaskIds,
  onToggleTask,
  onSelectAll,
  onDeselectAll,
  onCreateSelected,
  onCreateSingle,
  isCreatingSelected,
  creatingTaskId,
  imagePreviewUrl,
  defaultPriority = "medium",
  defaultHours = 1
}) {
  const totalTasks = analysis.tasks.length;
  const selectedCount = selectedTaskIds.length;
  return /* @__PURE__ */ jsxs9("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxs9("div", { className: "flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between", children: [
      /* @__PURE__ */ jsxs9("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx11("h3", { className: "text-lg font-semibold text-slate-900 dark:text-slate-100", children: "Analysis Summary" }),
        analysis.summary ? /* @__PURE__ */ jsx11("p", { className: "text-sm text-slate-600 dark:text-slate-300 max-w-2xl leading-relaxed", children: analysis.summary }) : /* @__PURE__ */ jsx11("p", { className: "text-sm text-slate-500", children: "No summary provided by the AI." }),
        /* @__PURE__ */ jsxs9("div", { className: "flex flex-wrap items-center gap-3", children: [
          analysis.confidence !== void 0 && analysis.confidence !== null && /* @__PURE__ */ jsxs9("div", { className: "flex items-center gap-2 rounded-full bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-700 dark:bg-blue-900/30 dark:text-blue-200", children: [
            /* @__PURE__ */ jsx11(Sparkles, { className: "h-3.5 w-3.5" }),
            "Confidence: ",
            (analysis.confidence * 100).toFixed(0),
            "%"
          ] }),
          analysis.totalEstimatedHours !== void 0 && analysis.totalEstimatedHours !== null && /* @__PURE__ */ jsxs9("div", { className: "flex items-center gap-2 rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-700 dark:bg-slate-900/50 dark:text-slate-200", children: [
            /* @__PURE__ */ jsx11(Clock2, { className: "h-3.5 w-3.5" }),
            "Estimated total: ",
            analysis.totalEstimatedHours.toFixed(1),
            " hrs"
          ] }),
          /* @__PURE__ */ jsxs9("div", { className: "flex items-center gap-2 rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-700 dark:bg-slate-900/50 dark:text-slate-200", children: [
            "Tasks suggested: ",
            totalTasks
          ] })
        ] })
      ] }),
      imagePreviewUrl && /* @__PURE__ */ jsx11("div", { className: "hidden sm:block w-36 shrink-0 overflow-hidden rounded-lg border border-slate-200 shadow-sm dark:border-slate-800", children: /* @__PURE__ */ jsx11("img", { src: imagePreviewUrl, alt: "Uploaded reference", className: "h-full w-full object-cover" }) })
    ] }),
    /* @__PURE__ */ jsxs9("div", { className: "flex flex-wrap items-center justify-between gap-3 rounded-lg bg-slate-50 px-4 py-3 dark:bg-slate-900/60", children: [
      /* @__PURE__ */ jsxs9("div", { className: "flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300", children: [
        /* @__PURE__ */ jsx11(
          Checkbox,
          {
            id: "select-all-tasks",
            checked: selectedCount === 0 ? false : selectedCount === totalTasks ? true : "indeterminate",
            onCheckedChange: (checked) => {
              if (checked) {
                onSelectAll();
              } else {
                onDeselectAll();
              }
            }
          }
        ),
        /* @__PURE__ */ jsxs9("label", { htmlFor: "select-all-tasks", className: "cursor-pointer", children: [
          selectedCount,
          " of ",
          totalTasks,
          " tasks selected"
        ] })
      ] }),
      /* @__PURE__ */ jsxs9("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx11(Button, { variant: "ghost", size: "sm", onClick: onSelectAll, disabled: totalTasks === 0, children: "Select all" }),
        /* @__PURE__ */ jsx11(Button, { variant: "ghost", size: "sm", onClick: onDeselectAll, disabled: selectedCount === 0, children: "Clear" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs9("div", { className: "space-y-3", children: [
      analysis.tasks.map((task) => {
        const priority = task.priority ?? defaultPriority;
        const hours = task.estimatedHours ?? defaultHours;
        const isSelected = selectedTaskIds.includes(task.id);
        const isCreating = creatingTaskId === task.id;
        return /* @__PURE__ */ jsx11(
          Card,
          {
            className: cn(
              "border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950/70",
              isSelected && "border-blue-500 shadow-sm"
            ),
            children: /* @__PURE__ */ jsxs9("div", { className: "flex flex-col gap-4 p-5 md:flex-row md:items-start md:justify-between", children: [
              /* @__PURE__ */ jsxs9("div", { className: "flex flex-1 items-start gap-3", children: [
                /* @__PURE__ */ jsx11(
                  Checkbox,
                  {
                    checked: isSelected,
                    onCheckedChange: () => onToggleTask(task.id),
                    className: "mt-1"
                  }
                ),
                /* @__PURE__ */ jsxs9("div", { className: "space-y-2", children: [
                  /* @__PURE__ */ jsxs9("div", { className: "flex flex-wrap items-center gap-2", children: [
                    /* @__PURE__ */ jsx11("h4", { className: "text-base font-semibold text-slate-900 dark:text-slate-100", children: task.title }),
                    /* @__PURE__ */ jsx11(Badge, { className: cn("capitalize", PRIORITY_COLOR[priority]), children: priority }),
                    /* @__PURE__ */ jsxs9(Badge, { variant: "outline", className: "flex items-center gap-1", children: [
                      /* @__PURE__ */ jsx11(Clock2, { className: "h-3.5 w-3.5" }),
                      hours.toFixed(1),
                      " hrs"
                    ] }),
                    isSelected && /* @__PURE__ */ jsxs9(Badge, { variant: "default", className: "bg-blue-600 hover:bg-blue-700", children: [
                      /* @__PURE__ */ jsx11(Check3, { className: "mr-1 h-3 w-3" }),
                      " Selected"
                    ] })
                  ] }),
                  task.description && /* @__PURE__ */ jsx11("p", { className: "text-sm leading-relaxed text-slate-600 dark:text-slate-300", children: task.description }),
                  task.notes && /* @__PURE__ */ jsx11("p", { className: "text-xs italic text-slate-500 dark:text-slate-400", children: task.notes })
                ] })
              ] }),
              /* @__PURE__ */ jsx11("div", { className: "flex shrink-0 items-center gap-3", children: /* @__PURE__ */ jsx11(
                Button,
                {
                  variant: "secondary",
                  size: "sm",
                  onClick: () => onCreateSingle(task),
                  disabled: isCreatingSelected || isCreating,
                  children: isCreating ? /* @__PURE__ */ jsxs9("span", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsx11("span", { className: "h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" }),
                    "Creating\u2026"
                  ] }) : "Create task"
                }
              ) })
            ] })
          },
          task.id
        );
      }),
      analysis.tasks.length === 0 && /* @__PURE__ */ jsx11(Card, { className: "border-dashed p-10 text-center", children: /* @__PURE__ */ jsx11("p", { className: "text-sm text-slate-500", children: "The AI did not find any actionable tasks in this image." }) })
    ] }),
    /* @__PURE__ */ jsxs9("div", { className: "flex flex-col gap-3 rounded-lg border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-900/60 sm:flex-row sm:items-center sm:justify-between", children: [
      /* @__PURE__ */ jsxs9("div", { className: "space-y-1 text-sm text-slate-600 dark:text-slate-300", children: [
        /* @__PURE__ */ jsx11("p", { children: selectedCount > 0 ? `Ready to create ${selectedCount} task${selectedCount === 1 ? "" : "s"}.` : "Select the tasks you want to create." }),
        /* @__PURE__ */ jsxs9("p", { className: "text-xs text-slate-500", children: [
          "Default priority: ",
          defaultPriority,
          ". Default estimate: ",
          defaultHours.toFixed(1),
          " hrs."
        ] })
      ] }),
      /* @__PURE__ */ jsx11(
        Button,
        {
          size: "lg",
          disabled: selectedCount === 0 || isCreatingSelected,
          onClick: onCreateSelected,
          className: "sm:min-w-[220px]",
          children: isCreatingSelected ? /* @__PURE__ */ jsxs9("span", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx11("span", { className: "h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" }),
            "Creating tasks\u2026"
          ] }) : `Create ${selectedCount || "selected"} task${selectedCount === 1 ? "" : "s"}`
        }
      )
    ] }),
    analysis.confidence !== void 0 && analysis.confidence !== null && /* @__PURE__ */ jsxs9("div", { className: "space-y-1 text-xs text-slate-500 dark:text-slate-400", children: [
      /* @__PURE__ */ jsx11("p", { children: "Confidence indicates how certain the AI is about its recommendations. Review tasks before creating them to ensure they match your project goals." }),
      analysis.confidence !== void 0 && /* @__PURE__ */ jsx11(Progress, { value: analysis.confidence * 100, className: "h-1.5" })
    ] })
  ] });
}
function formatMessagePart(part) {
  if (!part) return "";
  if (typeof part === "string") {
    return part;
  }
  if (typeof part === "object") {
    const obj = part;
    if (typeof obj.text === "string") {
      return obj.text;
    }
    if (typeof obj.data === "string") {
      return obj.data;
    }
    if (obj.type === "tool-call") {
      const name = typeof obj.toolName === "string" ? obj.toolName : "tool";
      return `Calling ${name}\u2026`;
    }
    if (obj.type === "tool-result") {
      const toolName = typeof obj.toolName === "string" ? obj.toolName : "tool";
      const output = obj.output;
      if (output?.type === "json") {
        return JSON.stringify(output.value, null, 2);
      }
      if (output?.type === "text") {
        return String(output.value ?? "");
      }
      return `Tool result from ${toolName}`;
    }
    if (obj.type === "reasoning" && typeof obj.text === "string") {
      return obj.text;
    }
    if (obj.type === "redacted-reasoning" && typeof obj.data === "string") {
      return obj.data;
    }
    return JSON.stringify(obj);
  }
  return "";
}
function formatMessageContent(content) {
  if (typeof content === "string") {
    return content;
  }
  if (Array.isArray(content)) {
    return content.map((part) => formatMessagePart(part)).filter(Boolean).join(" ");
  }
  if (content && typeof content === "object") {
    return formatMessagePart(content);
  }
  return "";
}
function ImageAnalysisSessionModal({
  open,
  onClose,
  imageDataUrl,
  context,
  defaultPriority,
  defaultHours,
  projectId,
  projectName,
  onTasksCreated
}) {
  const queryClient = useQueryClient2();
  const createImageAnalysisThread = useConvexAction(api.ai.createImageAnalysisThread);
  const runImageAnalysisAgent = useConvexAction(api.ai.runImageAnalysisAgent);
  const createTasksFromImage = useConvexAction(api.ai.createTasksFromImage);
  const createTaskFromImage = useConvexAction(api.ai.createTaskFromImage);
  const [threadId, setThreadId] = useState5(null);
  const [analysis, setAnalysis] = useState5(null);
  const [selectedTaskIds, setSelectedTaskIds] = useState5([]);
  const [isAnalyzing, setIsAnalyzing] = useState5(false);
  const [isCreatingSelected, setIsCreatingSelected] = useState5(false);
  const [creatingTaskId, setCreatingTaskId] = useState5(null);
  const [errorMessage, setErrorMessage] = useState5(null);
  useEffect7(() => {
    if (!open) {
      setThreadId(null);
      setAnalysis(null);
      setSelectedTaskIds([]);
      setIsAnalyzing(false);
      setIsCreatingSelected(false);
      setCreatingTaskId(null);
      setErrorMessage(null);
      return;
    }
    let cancelled = false;
    async function startSession() {
      try {
        setIsAnalyzing(true);
        setAnalysis(null);
        setSelectedTaskIds([]);
        setErrorMessage(null);
        const { threadId: createdThreadId } = await createImageAnalysisThread({});
        if (cancelled) return;
        setThreadId(createdThreadId);
        const response = await runImageAnalysisAgent({
          threadId: createdThreadId,
          imageDataUrl,
          context
        });
        if (cancelled) return;
        const normalised = ImageAnalysisResultSchema.parse({
          summary: response.analysis?.summary ?? "",
          totalEstimatedHours: response.analysis?.totalEstimatedHours ?? void 0,
          confidence: response.analysis?.confidence ?? void 0,
          tasks: (response.analysis?.tasks ?? []).map((task, index) => ({
            ...task,
            id: task.id ?? `task-${index + 1}`,
            priority: task.priority ?? DEFAULT_ANALYSIS_PRIORITY
          }))
        });
        if (cancelled) return;
        setAnalysis(normalised);
        setSelectedTaskIds(normalised.tasks.map((task) => task.id));
      } catch (error) {
        console.error("Failed to analyze image", error);
        const message = error instanceof Error ? error.message : "Image analysis failed";
        setErrorMessage(message);
      } finally {
        if (!cancelled) {
          setIsAnalyzing(false);
        }
      }
    }
    startSession();
    return () => {
      cancelled = true;
    };
  }, [open, createImageAnalysisThread, runImageAnalysisAgent, imageDataUrl, context]);
  const threadMessages = useThreadMessages(
    api.ai.listImageAnalysisThreadMessages,
    threadId ? { threadId } : "skip",
    {
      initialNumItems: 20,
      stream: true
    }
  );
  const agentLog = useMemo4(() => {
    if (!threadMessages || threadMessages.status === "LoadingFirstPage") {
      return [];
    }
    return threadMessages.results.map((entry) => {
      const { message, streaming, key, status } = entry;
      const role = message?.role ?? "assistant";
      const textContent = formatMessageContent(message?.content);
      const text = textContent || (status === "pending" ? "\u2026" : "(no content)");
      return {
        key,
        role,
        text,
        streaming
      };
    });
  }, [threadMessages]);
  const invalidateTasks = useCallback(async () => {
    await queryClient.invalidateQueries({
      predicate: (query2) => {
        const key = query2.queryKey;
        return Array.isArray(key) && key[0] === api.tasks.listTasks;
      }
    });
  }, [queryClient]);
  const handleSelectAll = useCallback(() => {
    if (!analysis) return;
    setSelectedTaskIds(analysis.tasks.map((task) => task.id));
  }, [analysis]);
  const handleDeselectAll = useCallback(() => {
    setSelectedTaskIds([]);
  }, []);
  const handleToggleTask = useCallback((taskId) => {
    setSelectedTaskIds(
      (current) => current.includes(taskId) ? current.filter((id) => id !== taskId) : [...current, taskId]
    );
  }, []);
  const handleCreateSelected = useCallback(async () => {
    if (!analysis || selectedTaskIds.length === 0) {
      toast3.info("Select at least one task to create.");
      return;
    }
    setIsCreatingSelected(true);
    try {
      const result = await createTasksFromImage({
        analysis,
        selectedTaskIds,
        projectId,
        defaultPriority,
        defaultHrs: defaultHours
      });
      const count = result?.count ?? selectedTaskIds.length;
      toast3.success(count === 1 ? "Created 1 task from the analysis" : `Created ${count} tasks.`);
      await invalidateTasks();
      onTasksCreated?.(count);
      onClose();
    } catch (error) {
      console.error("Failed to create tasks", error);
      const message = error instanceof Error ? error.message : "Unable to create tasks";
      toast3.error(message);
    } finally {
      setIsCreatingSelected(false);
    }
  }, [analysis, selectedTaskIds, createTasksFromImage, projectId, defaultPriority, defaultHours, invalidateTasks, onTasksCreated, onClose]);
  const handleCreateSingle = useCallback(
    async (task) => {
      if (!analysis) return;
      setCreatingTaskId(task.id);
      try {
        await createTaskFromImage({
          analysis,
          task,
          projectId,
          defaultPriority,
          defaultHrs: defaultHours
        });
        toast3.success(`Created task \u201C${task.title}\u201D`);
        await invalidateTasks();
        onTasksCreated?.(1);
        setSelectedTaskIds((current) => current.filter((id) => id !== task.id));
      } catch (error) {
        console.error("Failed to create single task", error);
        const message = error instanceof Error ? error.message : "Unable to create task";
        toast3.error(message);
      } finally {
        setCreatingTaskId(null);
      }
    },
    [analysis, createTaskFromImage, projectId, defaultPriority, defaultHours, invalidateTasks, onTasksCreated]
  );
  const handleRerunAnalysis = useCallback(async () => {
    if (!threadId) return;
    setIsAnalyzing(true);
    setErrorMessage(null);
    try {
      const response = await runImageAnalysisAgent({
        threadId,
        imageDataUrl,
        context
      });
      const normalised = ImageAnalysisResultSchema.parse({
        summary: response.analysis?.summary ?? "",
        totalEstimatedHours: response.analysis?.totalEstimatedHours ?? void 0,
        confidence: response.analysis?.confidence ?? void 0,
        tasks: (response.analysis?.tasks ?? []).map((task, index) => ({
          ...task,
          id: task.id ?? `task-${index + 1}`,
          priority: task.priority ?? DEFAULT_ANALYSIS_PRIORITY
        }))
      });
      setAnalysis(normalised);
      setSelectedTaskIds(normalised.tasks.map((task) => task.id));
    } catch (error) {
      console.error("Failed to re-run analysis", error);
      const message = error instanceof Error ? error.message : "Unable to re-run analysis";
      toast3.error(message);
    } finally {
      setIsAnalyzing(false);
    }
  }, [threadId, runImageAnalysisAgent, imageDataUrl, context]);
  return /* @__PURE__ */ jsx11(
    Dialog,
    {
      open,
      onOpenChange: (nextOpen) => {
        if (!nextOpen) {
          onClose();
        } else {
          onClose();
        }
      },
      children: /* @__PURE__ */ jsxs9(DialogContent, { className: "flex h-[95vh] w-full max-w-5xl flex-col overflow-hidden border border-border/60 bg-white dark:bg-slate-900 dark:border-slate-800 backdrop-blur-xl supports-[backdrop-filter]:bg-white/90", children: [
        /* @__PURE__ */ jsxs9(DialogHeader, { className: "flex-shrink-0 px-6 pt-6", children: [
          /* @__PURE__ */ jsxs9(DialogTitle, { className: "flex items-center gap-2 text-xl", children: [
            /* @__PURE__ */ jsx11(Sparkles, { className: "h-5 w-5 text-primary" }),
            "AI Image Analysis Session"
          ] }),
          /* @__PURE__ */ jsxs9(DialogDescription, { children: [
            "Reviewing tasks generated from your image",
            projectName ? ` for ${projectName}` : "",
            ". You can watch the agent work in real time and create tasks once you're satisfied."
          ] })
        ] }),
        /* @__PURE__ */ jsx11("div", { className: "flex-1 overflow-y-auto px-6 pb-6", children: /* @__PURE__ */ jsxs9("div", { className: "flex min-h-full flex-col gap-5", children: [
          errorMessage && /* @__PURE__ */ jsx11("div", { className: "rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700 dark:border-red-900/50 dark:bg-red-950/40 dark:text-red-200", children: errorMessage }),
          /* @__PURE__ */ jsxs9("div", { className: "flex flex-col gap-6 overflow-hidden", children: [
            /* @__PURE__ */ jsxs9("div", { className: "flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-900", children: [
              /* @__PURE__ */ jsxs9("div", { children: [
                /* @__PURE__ */ jsx11("p", { className: "text-sm font-semibold text-slate-700 dark:text-slate-200", children: "Analysis session" }),
                threadId && /* @__PURE__ */ jsxs9("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: [
                  "Thread ID: ",
                  threadId
                ] })
              ] }),
              /* @__PURE__ */ jsx11("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ jsxs9(Button, { variant: "ghost", onClick: handleRerunAnalysis, disabled: isAnalyzing || !threadId, children: [
                /* @__PURE__ */ jsx11(RefreshCcw, { className: "mr-2 h-4 w-4" }),
                " Re-run analysis"
              ] }) })
            ] }),
            /* @__PURE__ */ jsxs9("div", { className: "flex flex-col gap-6 overflow-hidden", children: [
              /* @__PURE__ */ jsxs9("div", { className: "flex max-h-[40vh] flex-col overflow-hidden rounded-lg border border-slate-200 bg-white p-4 text-sm dark:border-slate-800 dark:bg-slate-900", children: [
                /* @__PURE__ */ jsxs9("div", { className: "mb-3 flex items-center gap-3", children: [
                  isAnalyzing ? /* @__PURE__ */ jsx11(Loader22, { className: "h-5 w-5 animate-spin text-primary" }) : /* @__PURE__ */ jsx11(Sparkles, { className: "h-5 w-5 text-primary" }),
                  /* @__PURE__ */ jsx11("p", { className: "font-semibold text-slate-700 dark:text-slate-200", children: isAnalyzing ? "Analyzing image\u2026" : "Latest agent messages" })
                ] }),
                /* @__PURE__ */ jsx11("div", { className: "flex-1 overflow-y-auto", children: agentLog.length === 0 ? /* @__PURE__ */ jsx11("p", { className: "text-slate-500 dark:text-slate-400", children: "Waiting for agent output\u2026" }) : /* @__PURE__ */ jsx11("div", { className: "space-y-3", children: agentLog.map((entry) => /* @__PURE__ */ jsxs9("div", { className: "flex flex-col gap-1", children: [
                  /* @__PURE__ */ jsxs9("span", { className: "text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400", children: [
                    entry.role === "user" ? "You" : "Agent",
                    entry.streaming ? " (streaming)" : ""
                  ] }),
                  /* @__PURE__ */ jsx11("pre", { className: "whitespace-pre-wrap rounded-md bg-slate-100/70 p-3 text-xs leading-relaxed text-slate-700 dark:bg-slate-900 dark:text-slate-200", children: entry.text })
                ] }, entry.key)) }) })
              ] }),
              /* @__PURE__ */ jsx11("div", { className: "flex min-h-0 flex-col overflow-hidden rounded-lg border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900", children: analysis ? /* @__PURE__ */ jsx11("div", { className: "flex-1 overflow-y-auto pr-1", children: /* @__PURE__ */ jsx11(
                ImageAnalysisResults,
                {
                  analysis,
                  selectedTaskIds,
                  onToggleTask: handleToggleTask,
                  onSelectAll: handleSelectAll,
                  onDeselectAll: handleDeselectAll,
                  onCreateSelected: handleCreateSelected,
                  onCreateSingle: handleCreateSingle,
                  isCreatingSelected,
                  creatingTaskId,
                  imagePreviewUrl: imageDataUrl,
                  defaultPriority,
                  defaultHours
                }
              ) }) : /* @__PURE__ */ jsxs9("div", { className: "flex flex-1 flex-col items-center justify-center gap-3 text-center text-sm text-slate-500 dark:text-slate-400", children: [
                /* @__PURE__ */ jsx11(Loader22, { className: "h-6 w-6 animate-spin text-primary" }),
                /* @__PURE__ */ jsx11("p", { children: "Waiting for the agent to finish analyzing the image\u2026" })
              ] }) })
            ] })
          ] })
        ] }) }),
        /* @__PURE__ */ jsxs9(DialogFooter, { className: "flex-shrink-0 flex items-center justify-end gap-2 px-6 pb-4", children: [
          /* @__PURE__ */ jsx11(Button, { variant: "outline", onClick: onClose, children: "Close" }),
          /* @__PURE__ */ jsx11(
            Button,
            {
              onClick: handleCreateSelected,
              disabled: selectedTaskIds.length === 0 || isCreatingSelected,
              children: isCreatingSelected ? "Creating tasks\u2026" : `Create ${selectedTaskIds.length || 0} selected tasks`
            }
          )
        ] })
      ] })
    }
  );
}
function Separator3({
  className,
  orientation = "horizontal",
  decorative = true,
  ...props
}) {
  return /* @__PURE__ */ jsx11(
    SeparatorPrimitive.Root,
    {
      "data-slot": "separator",
      decorative,
      orientation,
      className: cn(
        "bg-border shrink-0 data-[orientation=horizontal]:h-px data-[orientation=horizontal]:w-full data-[orientation=vertical]:h-full data-[orientation=vertical]:w-px",
        className
      ),
      ...props
    }
  );
}
function EditTaskModal({ open, onOpenChange, task }) {
  const [text, setText] = useState5("");
  const [details, setDetails] = useState5("");
  const [priority, setPriority] = useState5("medium");
  const [status, setStatus] = useState5("todo");
  const [hrs, setHrs] = useState5("1");
  const [refLink, setRefLink] = useState5("");
  const [selectedProjectId, setSelectedProjectId] = useState5("");
  const [isSubmitting, setIsSubmitting] = useState5(false);
  const updateTask = useConvexMutation3(api.tasks.updateTask);
  const projects = useConvexQuery3(api.projects.listProjects, {});
  useEffect7(() => {
    if (!task || !open) return;
    setText(task.text || "");
    setDetails(task.details || "");
    setPriority(task.priority || "medium");
    setStatus(task.status || "todo");
    setHrs(task.hrs?.toString() || "1");
    setRefLink(task.refLink || "");
    setSelectedProjectId(task.projectId || "");
  }, [task, open]);
  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!task || !text.trim()) return;
    setIsSubmitting(true);
    try {
      await updateTask({
        taskId: task._id,
        text: text.trim(),
        details: details.trim() || "",
        priority,
        status,
        hrs: parseFloat(hrs) || 1,
        refLink: refLink.trim() || "",
        projectId: selectedProjectId || task.projectId
      });
      onOpenChange(false);
    } catch (error) {
      console.error("Failed to update task:", error);
    } finally {
      setIsSubmitting(false);
    }
  };
  const handleClose = (nextOpen) => {
    if (!nextOpen && !isSubmitting) {
      onOpenChange(false);
      return;
    }
    if (nextOpen) {
      onOpenChange(true);
    }
  };
  if (!task) {
    return null;
  }
  return /* @__PURE__ */ jsx11(Dialog, { open, onOpenChange: handleClose, children: /* @__PURE__ */ jsxs9(DialogContent, { className: "sm:max-w-[520px]", children: [
    /* @__PURE__ */ jsxs9(DialogHeader, { children: [
      /* @__PURE__ */ jsx11(DialogTitle, { children: "Edit Task" }),
      /* @__PURE__ */ jsx11(DialogDescription, { children: "Update the task information below." })
    ] }),
    /* @__PURE__ */ jsxs9("form", { onSubmit: handleSubmit, className: "space-y-5", children: [
      /* @__PURE__ */ jsxs9("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxs9(Label3, { htmlFor: "edit-task-text", className: "text-sm font-medium", children: [
          "Task Name ",
          /* @__PURE__ */ jsx11("span", { className: "text-destructive", children: "*" })
        ] }),
        /* @__PURE__ */ jsx11(
          Input,
          {
            id: "edit-task-text",
            value: text,
            onChange: (event) => setText(event.target.value),
            required: true,
            disabled: isSubmitting
          }
        )
      ] }),
      /* @__PURE__ */ jsxs9("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx11(Label3, { htmlFor: "edit-task-details", className: "text-sm font-medium", children: "Details" }),
        /* @__PURE__ */ jsx11(
          "textarea",
          {
            id: "edit-task-details",
            value: details,
            onChange: (event) => setDetails(event.target.value),
            rows: 4,
            disabled: isSubmitting,
            className: "w-full rounded-lg border border-input bg-background px-4 py-3 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
          }
        )
      ] }),
      /* @__PURE__ */ jsxs9("div", { className: "grid gap-4 sm:grid-cols-2", children: [
        /* @__PURE__ */ jsxs9("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxs9(Label3, { htmlFor: "edit-task-priority", className: "flex items-center gap-2 text-sm font-medium", children: [
            /* @__PURE__ */ jsx11(Flag2, { className: "h-4 w-4 text-muted-foreground" }),
            "Priority"
          ] }),
          /* @__PURE__ */ jsx11(
            "select",
            {
              id: "edit-task-priority",
              value: priority,
              onChange: (event) => setPriority(event.target.value),
              disabled: isSubmitting,
              className: "h-10 w-full rounded-lg border border-input bg-background px-3 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50",
              children: PRIORITY_OPTIONS2.map((option) => /* @__PURE__ */ jsx11("option", { value: option.value, children: option.label }, option.value))
            }
          )
        ] }),
        /* @__PURE__ */ jsxs9("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxs9(Label3, { htmlFor: "edit-task-status", className: "flex items-center gap-2 text-sm font-medium", children: [
            /* @__PURE__ */ jsx11(Clock2, { className: "h-4 w-4 text-muted-foreground" }),
            "Status"
          ] }),
          /* @__PURE__ */ jsx11(
            "select",
            {
              id: "edit-task-status",
              value: status,
              onChange: (event) => setStatus(event.target.value),
              disabled: isSubmitting,
              className: "h-10 w-full rounded-lg border border-input bg-background px-3 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50",
              children: STATUS_OPTIONS2.map((option) => /* @__PURE__ */ jsx11("option", { value: option.value, children: option.label }, option.value))
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxs9("div", { className: "grid gap-4 sm:grid-cols-2", children: [
        /* @__PURE__ */ jsxs9("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx11(Label3, { htmlFor: "edit-task-hrs", className: "text-sm font-medium", children: "Estimated Hours" }),
          /* @__PURE__ */ jsx11(
            Input,
            {
              id: "edit-task-hrs",
              type: "number",
              min: "0.25",
              step: "0.25",
              value: hrs,
              onChange: (event) => setHrs(event.target.value),
              disabled: isSubmitting
            }
          )
        ] }),
        /* @__PURE__ */ jsxs9("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx11(Label3, { htmlFor: "edit-task-project", className: "text-sm font-medium", children: "Project" }),
          /* @__PURE__ */ jsxs9(
            "select",
            {
              id: "edit-task-project",
              value: selectedProjectId || "",
              onChange: (event) => {
                const value = event.target.value;
                setSelectedProjectId(value ? value : "");
              },
              disabled: isSubmitting,
              className: "h-10 w-full rounded-lg border border-input bg-background px-3 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50",
              children: [
                /* @__PURE__ */ jsx11("option", { value: "", children: "No project" }),
                projects?.map((project) => /* @__PURE__ */ jsx11("option", { value: project._id, children: project.name }, project._id))
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxs9("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxs9(Label3, { htmlFor: "edit-task-ref", className: "flex items-center gap-2 text-sm font-medium", children: [
          /* @__PURE__ */ jsx11(Link22, { className: "h-4 w-4 text-muted-foreground" }),
          "Reference Link",
          /* @__PURE__ */ jsx11("span", { className: "text-xs text-muted-foreground", children: "(optional)" })
        ] }),
        /* @__PURE__ */ jsx11(
          Input,
          {
            id: "edit-task-ref",
            type: "url",
            value: refLink,
            onChange: (event) => setRefLink(event.target.value),
            disabled: isSubmitting,
            placeholder: "https://example.com/reference"
          }
        )
      ] }),
      /* @__PURE__ */ jsxs9(DialogFooter, { children: [
        /* @__PURE__ */ jsx11(Button, { type: "button", variant: "outline", onClick: () => handleClose(false), disabled: isSubmitting, children: "Cancel" }),
        /* @__PURE__ */ jsx11(Button, { type: "submit", disabled: isSubmitting || !text.trim(), children: isSubmitting ? "Saving..." : "Save Changes" })
      ] })
    ] })
  ] }) });
}
function ProjectDetailsModal({
  open,
  onOpenChange,
  projectId
}) {
  const [isTaskModalOpen, setIsTaskModalOpen] = useState5(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState5(false);
  const [editingTask, setEditingTask] = useState5(null);
  const [isEditingName, setIsEditingName] = useState5(false);
  const [isEditingDescription, setIsEditingDescription] = useState5(false);
  const queryClient = useQueryClient2();
  const project = useConvexQuery3(
    api.projects.getProject,
    open ? { projectId } : "skip"
  );
  const allTasks = useConvexQuery3(
    api.tasks.listTasks,
    open ? {} : "skip"
  );
  const tasks = allTasks?.filter((task) => task.projectId === projectId) || [];
  const completedTasks = tasks.filter((task) => task.status === "done");
  const progressPercentage = tasks.length > 0 ? completedTasks.length / tasks.length * 100 : 0;
  const recentTasks = useMemo4(() => {
    if (!tasks.length) return [];
    return [...tasks].sort((a, b) => b._creationTime - a._creationTime).slice(0, 3);
  }, [tasks]);
  const updateProject = useConvexMutation3(api.projects.updateProject);
  const updateTask = useConvexMutation3(api.tasks.updateTask);
  const deleteTask = useConvexMutation3(api.tasks.deleteTask);
  const handleUpdateProjectName = async () => {
    if (!project || !isEditingName) return;
    const newName = prompt("Edit project name:", project.name);
    if (newName && newName !== project.name && newName.trim()) {
      try {
        await updateProject({
          projectId: project._id,
          name: newName.trim()
        });
        queryClient.invalidateQueries({ predicate: (query2) => {
          const key = query2.queryKey;
          return Array.isArray(key) && (key[0] === api.projects.getProject || key[0] === api.projects.listProjects);
        } });
      } catch (error) {
        console.error("Failed to update project name:", error);
        alert("Failed to update project name. Please try again.");
      }
    }
    setIsEditingName(false);
  };
  const handleUpdateProjectDescription = async () => {
    if (!project || !isEditingDescription) return;
    const newDescription = prompt("Edit project description:", project.description || "");
    if (newDescription !== null) {
      try {
        await updateProject({
          projectId: project._id,
          description: newDescription
        });
        queryClient.invalidateQueries({ predicate: (query2) => {
          const key = query2.queryKey;
          return Array.isArray(key) && (key[0] === api.projects.getProject || key[0] === api.projects.listProjects);
        } });
      } catch (error) {
        console.error("Failed to update project description:", error);
        alert("Failed to update project description. Please try again.");
      }
    }
    setIsEditingDescription(false);
  };
  const handleToggleTask = async (task) => {
    const currentStatus = task.status || "todo";
    const newStatus = currentStatus === "done" ? "todo" : "done";
    try {
      await updateTask({
        taskId: task._id,
        status: newStatus
      });
      queryClient.invalidateQueries({ predicate: (query2) => {
        const key = query2.queryKey;
        return Array.isArray(key) && key[0] === api.tasks.listTasks;
      } });
    } catch (error) {
      console.error("Failed to toggle task:", error);
      alert("Failed to update task. Please try again.");
    }
  };
  if (!project) {
    return null;
  }
  return /* @__PURE__ */ jsxs9(Fragment4, { children: [
    /* @__PURE__ */ jsx11(Dialog, { open, onOpenChange, children: /* @__PURE__ */ jsxs9(DialogContent, { className: "max-w-2xl max-h-[90vh] overflow-y-auto bg-white dark:bg-slate-800 border-gray-200 dark:border-slate-700", children: [
      /* @__PURE__ */ jsx11(DialogHeader, { children: /* @__PURE__ */ jsxs9(DialogTitle, { className: "flex items-center gap-3", children: [
        getProjectIcon(project.type),
        /* @__PURE__ */ jsxs9("div", { className: "flex-1", children: [
          /* @__PURE__ */ jsxs9("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx11("h2", { className: "text-xl font-bold", children: project.name || "Unnamed Project" }),
            isEditingName && /* @__PURE__ */ jsxs9("div", { className: "flex gap-2", children: [
              /* @__PURE__ */ jsx11(Button, { size: "sm", onClick: handleUpdateProjectName, children: "Save" }),
              /* @__PURE__ */ jsx11(Button, { size: "sm", variant: "outline", onClick: () => setIsEditingName(false), children: "Cancel" })
            ] }),
            !isEditingName && /* @__PURE__ */ jsx11(
              Button,
              {
                variant: "ghost",
                size: "sm",
                onClick: () => setIsEditingName(true),
                className: "h-6 w-6 p-0",
                children: /* @__PURE__ */ jsx11(Pencil2, { className: "h-3 w-3" })
              }
            )
          ] }),
          /* @__PURE__ */ jsx11("p", { className: "text-sm text-gray-600 dark:text-slate-400 font-normal", children: getProjectTypeLabel(project.type) })
        ] })
      ] }) }),
      /* @__PURE__ */ jsxs9("div", { className: "space-y-6", children: [
        /* @__PURE__ */ jsx11("div", { className: "flex items-center gap-3", children: /* @__PURE__ */ jsx11(
          Badge,
          {
            variant: project.status === "beta" ? "default" : "secondary",
            className: project.status === "beta" ? "bg-black dark:bg-white text-white dark:text-black border-0" : "",
            children: getProjectStatusLabel$1(project.status)
          }
        ) }),
        /* @__PURE__ */ jsxs9("div", { children: [
          /* @__PURE__ */ jsx11("h3", { className: "font-semibold mb-2", children: "Description" }),
          /* @__PURE__ */ jsx11(
            "div",
            {
              className: "text-gray-600 dark:text-slate-300 cursor-pointer hover:bg-muted/50 dark:hover:bg-slate-700/30 p-2 rounded transition-colors min-h-[1.5rem]",
              onClick: () => setIsEditingDescription(true),
              children: project.description || "Click to add description..."
            }
          ),
          isEditingDescription && /* @__PURE__ */ jsxs9("div", { className: "flex gap-2 mt-2", children: [
            /* @__PURE__ */ jsx11(Button, { size: "sm", onClick: handleUpdateProjectDescription, children: "Save" }),
            /* @__PURE__ */ jsx11(Button, { size: "sm", variant: "outline", onClick: () => setIsEditingDescription(false), children: "Cancel" })
          ] })
        ] }),
        tasks.length > 0 && /* @__PURE__ */ jsxs9("div", { children: [
          /* @__PURE__ */ jsx11("h3", { className: "font-semibold mb-3", children: "Progress" }),
          /* @__PURE__ */ jsxs9("div", { className: "space-y-3", children: [
            /* @__PURE__ */ jsxs9("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsx11("span", { className: "text-sm text-gray-600 dark:text-slate-400", children: "Task Completion" }),
              /* @__PURE__ */ jsxs9("span", { className: "text-sm font-medium", children: [
                completedTasks.length,
                "/",
                tasks.length,
                " tasks"
              ] })
            ] }),
            /* @__PURE__ */ jsx11(Progress, { value: progressPercentage, className: "h-2" }),
            /* @__PURE__ */ jsxs9("div", { className: "text-center", children: [
              /* @__PURE__ */ jsxs9("span", { className: "text-2xl font-bold", children: [
                Math.round(progressPercentage),
                "%"
              ] }),
              /* @__PURE__ */ jsx11("span", { className: "text-sm text-gray-500 dark:text-slate-400 ml-1", children: "Complete" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsx11(Separator3, {}),
        /* @__PURE__ */ jsxs9("div", { children: [
          /* @__PURE__ */ jsx11("h3", { className: "font-semibold mb-3", children: "Project Metrics" }),
          /* @__PURE__ */ jsxs9("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-4", children: [
            /* @__PURE__ */ jsxs9("div", { className: "text-center p-3 bg-gray-50 dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700", children: [
              /* @__PURE__ */ jsx11(Star, { className: "h-5 w-5 mx-auto mb-2 text-black dark:text-white" }),
              /* @__PURE__ */ jsx11("div", { className: "text-lg font-bold dark:text-slate-100", children: formatNumber$1(project.githubStars || 0) }),
              /* @__PURE__ */ jsx11("div", { className: "text-xs text-gray-500 dark:text-slate-400", children: "GitHub Stars" })
            ] }),
            /* @__PURE__ */ jsxs9("div", { className: "text-center p-3 bg-gray-50 dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700", children: [
              /* @__PURE__ */ jsx11(GitFork, { className: "h-5 w-5 mx-auto mb-2 text-black dark:text-white" }),
              /* @__PURE__ */ jsx11("div", { className: "text-lg font-bold", children: formatNumber$1(project.githubForks || 0) }),
              /* @__PURE__ */ jsx11("div", { className: "text-xs text-gray-500 dark:text-gray-400", children: "Forks" })
            ] }),
            /* @__PURE__ */ jsxs9("div", { className: "text-center p-3 bg-gray-50 dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700", children: [
              /* @__PURE__ */ jsx11(Package, { className: "h-5 w-5 mx-auto mb-2 text-black dark:text-white" }),
              /* @__PURE__ */ jsx11("div", { className: "text-lg font-bold", children: formatNumber$1(project.npmDownloads || 0) }),
              /* @__PURE__ */ jsx11("div", { className: "text-xs text-gray-500 dark:text-gray-400", children: "Downloads (30d)" })
            ] }),
            /* @__PURE__ */ jsxs9("div", { className: "text-center p-3 bg-gray-50 dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700", children: [
              /* @__PURE__ */ jsx11(Target, { className: "h-5 w-5 mx-auto mb-2 text-black dark:text-white" }),
              /* @__PURE__ */ jsx11("div", { className: "text-lg font-bold dark:text-slate-100", children: tasks.length }),
              /* @__PURE__ */ jsx11("div", { className: "text-xs text-gray-500 dark:text-slate-400", children: "Total Tasks" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsx11(Separator3, {}),
        /* @__PURE__ */ jsxs9("div", { children: [
          /* @__PURE__ */ jsx11("h3", { className: "font-semibold mb-3", children: "Project Information" }),
          /* @__PURE__ */ jsxs9("div", { className: "space-y-3", children: [
            project.launchDate && /* @__PURE__ */ jsxs9("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx11(Calendar, { className: "h-4 w-4 text-blue-500" }),
              /* @__PURE__ */ jsx11("span", { className: "text-sm text-gray-600 dark:text-slate-400", children: "Launch Date:" }),
              /* @__PURE__ */ jsx11("span", { className: "font-medium", children: new Date(project.launchDate).toLocaleDateString() })
            ] }),
            project.githubUrl && /* @__PURE__ */ jsxs9("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx11(Github2, { className: "h-4 w-4 text-gray-700 dark:text-slate-300" }),
              /* @__PURE__ */ jsx11("span", { className: "text-sm text-gray-600 dark:text-slate-400", children: "Repository:" }),
              /* @__PURE__ */ jsxs9(
                Button,
                {
                  variant: "link",
                  size: "sm",
                  className: "p-0 h-auto",
                  onClick: () => window.open(project.githubUrl, "_blank"),
                  children: [
                    "View on GitHub",
                    /* @__PURE__ */ jsx11(ExternalLink, { className: "h-3 w-3 ml-1" })
                  ]
                }
              )
            ] })
          ] })
        ] }),
        (project.npmDownloads ?? project.downloadCount ?? null) !== null || project.userCount !== void 0 && project.userCount !== null ? /* @__PURE__ */ jsxs9(Fragment4, { children: [
          /* @__PURE__ */ jsx11(Separator3, {}),
          /* @__PURE__ */ jsxs9("div", { children: [
            /* @__PURE__ */ jsx11("h3", { className: "font-semibold mb-3", children: "Additional Statistics" }),
            /* @__PURE__ */ jsxs9("div", { className: "grid grid-cols-2 gap-4", children: [
              (project.npmDownloads ?? project.downloadCount ?? null) !== null && /* @__PURE__ */ jsxs9("div", { className: "text-center p-3 bg-gray-50 dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700", children: [
                /* @__PURE__ */ jsx11(TrendingUp, { className: "h-5 w-5 mx-auto mb-2 text-black dark:text-white" }),
                /* @__PURE__ */ jsx11("div", { className: "text-lg font-bold", children: formatNumber$1((project.npmDownloads ?? project.downloadCount) || 0) }),
                /* @__PURE__ */ jsx11("div", { className: "text-xs text-gray-500 dark:text-gray-400", children: "Downloads (30d)" })
              ] }),
              project.userCount !== void 0 && project.userCount !== null && /* @__PURE__ */ jsxs9("div", { className: "text-center p-3 bg-gray-50 dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700", children: [
                /* @__PURE__ */ jsx11(Users3, { className: "h-5 w-5 mx-auto mb-2 text-black dark:text-white" }),
                /* @__PURE__ */ jsx11("div", { className: "text-lg font-bold", children: formatNumber$1(project.userCount) }),
                /* @__PURE__ */ jsx11("div", { className: "text-xs text-gray-500 dark:text-gray-400", children: "Users" })
              ] })
            ] })
          ] })
        ] }) : null,
        /* @__PURE__ */ jsx11(Separator3, {}),
        /* @__PURE__ */ jsxs9("div", { children: [
          /* @__PURE__ */ jsxs9("div", { className: "flex items-center justify-between mb-4", children: [
            /* @__PURE__ */ jsx11("h3", { className: "text-lg font-semibold", children: "Tasks" }),
            /* @__PURE__ */ jsxs9(Button, { onClick: () => setIsTaskModalOpen(true), size: "sm", children: [
              /* @__PURE__ */ jsx11(Plus, { className: "h-4 w-4 mr-2" }),
              "Add Task"
            ] })
          ] }),
          /* @__PURE__ */ jsx11("div", { className: "space-y-3", children: tasks.length === 0 ? /* @__PURE__ */ jsx11(Card, { children: /* @__PURE__ */ jsx11(CardContent, { className: "py-8 text-center text-muted-foreground", children: "No tasks yet. Add one above!" }) }) : /* @__PURE__ */ jsxs9(Fragment4, { children: [
            tasks.length > 3 && /* @__PURE__ */ jsx11("p", { className: "text-xs text-muted-foreground", children: "Showing the three most recent tasks" }),
            recentTasks.map((task) => /* @__PURE__ */ jsx11(Card, { children: /* @__PURE__ */ jsx11(CardContent, { className: "p-4", children: /* @__PURE__ */ jsxs9("div", { className: "flex items-start gap-3", children: [
              /* @__PURE__ */ jsx11(
                "button",
                {
                  onClick: () => handleToggleTask(task),
                  className: "mt-1",
                  title: task.status === "done" ? "Mark as incomplete" : "Mark as complete",
                  children: task.status === "done" ? /* @__PURE__ */ jsx11(CheckCircle22, { className: "h-5 w-5 text-green-600" }) : /* @__PURE__ */ jsx11(XCircle, { className: "h-5 w-5 text-gray-400" })
                }
              ),
              /* @__PURE__ */ jsxs9("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsxs9("div", { className: "flex items-center gap-2 mb-1", children: [
                  /* @__PURE__ */ jsx11(
                    "span",
                    {
                      className: `flex-1 ${task.status === "done" ? "line-through text-muted-foreground" : "font-medium"}`,
                      children: task.text
                    }
                  ),
                  task.priority && /* @__PURE__ */ jsx11(
                    Badge,
                    {
                      variant: task.priority === "high" ? "destructive" : task.priority === "medium" ? "default" : "secondary",
                      className: "text-xs",
                      children: task.priority
                    }
                  ),
                  /* @__PURE__ */ jsx11(
                    Button,
                    {
                      variant: "ghost",
                      size: "icon",
                      className: "h-8 w-8",
                      onClick: () => {
                        setEditingTask({
                          _id: task._id,
                          text: task.text,
                          details: task.details,
                          priority: task.priority,
                          status: task.status,
                          hrs: task.hrs,
                          sharedWith: task.sharedWith,
                          refLink: task.refLink,
                          projectId: task.projectId
                        });
                        setIsEditModalOpen(true);
                      },
                      children: /* @__PURE__ */ jsx11(Pencil2, { className: "h-4 w-4" })
                    }
                  ),
                  /* @__PURE__ */ jsx11(
                    Button,
                    {
                      variant: "ghost",
                      size: "icon",
                      className: "h-8 w-8 text-destructive",
                      onClick: async () => {
                        if (window.confirm(`Are you sure you want to delete "${task.text}"?`)) {
                          try {
                            await deleteTask({ taskId: task._id });
                            queryClient.invalidateQueries({ predicate: (query2) => {
                              const key = query2.queryKey;
                              return Array.isArray(key) && key[0] === api.tasks.listTasks;
                            } });
                          } catch (error) {
                            console.error("Failed to delete task:", error);
                            alert("Failed to delete task. Please try again.");
                          }
                        }
                      },
                      children: /* @__PURE__ */ jsx11(Trash22, { className: "h-4 w-4" })
                    }
                  )
                ] }),
                task.details && /* @__PURE__ */ jsx11("p", { className: "text-sm text-muted-foreground mb-2", children: task.details }),
                task.refLink && /* @__PURE__ */ jsxs9(
                  "a",
                  {
                    href: task.refLink,
                    target: "_blank",
                    rel: "noopener noreferrer",
                    className: "text-sm text-blue-600 hover:underline block mb-2",
                    children: [
                      "\u{1F517} ",
                      task.refLink
                    ]
                  }
                ),
                task.hrs && /* @__PURE__ */ jsxs9("span", { className: "text-xs text-muted-foreground", children: [
                  "Estimated: ",
                  task.hrs,
                  " hrs"
                ] })
              ] })
            ] }) }) }, task._id))
          ] }) })
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsx11(
      AddTaskModal,
      {
        open: isTaskModalOpen,
        onOpenChange: setIsTaskModalOpen,
        projectId
      }
    ),
    editingTask && /* @__PURE__ */ jsx11(
      EditTaskModal,
      {
        open: isEditModalOpen,
        onOpenChange: setIsEditModalOpen,
        task: editingTask
      }
    )
  ] });
}
function SidebarProjectCard({ project, isSelected, onSelect, onShowCollaborators }) {
  const [isDeleting, setIsDeleting] = useState5(false);
  const [isSyncing, setIsSyncing] = useState5(false);
  const [showEditModal, setShowEditModal] = useState5(false);
  const [showDetailsModal, setShowDetailsModal] = useState5(false);
  const queryClient = useQueryClient2();
  const deleteProject = useConvexMutation3(api.projects.deleteProject);
  const syncGitHubMetrics = useConvexAction(api.projects.syncGitHubMetrics);
  const handleDelete = async () => {
    if (!window.confirm(`Delete "${project.name}"? This cannot be undone.`)) {
      return;
    }
    setIsDeleting(true);
    try {
      const projectId = project._id || project.id;
      await deleteProject({ projectId });
      queryClient.invalidateQueries({
        predicate: (query2) => {
          const key = query2.queryKey;
          return Array.isArray(key) && (key[0] === api.projects.listProjects || key[0] === api.projects.getProject);
        }
      });
      toast3.success("Project deleted successfully");
    } catch (error) {
      toast3.error(`Failed to delete project: ${error instanceof Error ? error.message : "Unknown error"}`);
    } finally {
      setIsDeleting(false);
    }
  };
  const handleSyncGitHubMetrics = async () => {
    setIsSyncing(true);
    try {
      const repoUrl = project.githubUrl || (project.githubRepo ? `https://github.com/${project.githubRepo}` : null) || project.websiteUrl || null;
      if (!repoUrl) {
        toast3.error("Add a GitHub URL before syncing metrics.");
        return;
      }
      const projectId = project._id ?? project.id;
      await syncGitHubMetrics({ projectId });
      queryClient.invalidateQueries({
        predicate: (query2) => {
          const key = query2.queryKey;
          return Array.isArray(key) && (key[0] === api.projects.listProjects || key[0] === api.projects.getProject);
        }
      });
      toast3.success("GitHub metrics synced successfully");
    } catch (error) {
      toast3.error(`Failed to sync GitHub metrics: ${error instanceof Error ? error.message : "Unknown error"}`);
    } finally {
      setIsSyncing(false);
    }
  };
  const getProjectIcon2 = (type) => {
    const icons = {
      saas: "\u{1F4BC}",
      mobile: "\u{1F4F1}",
      web: "\u{1F310}",
      desktop: "\u{1F4BB}",
      "open-source": "\u{1F513}",
      library: "\u{1F4DA}",
      tool: "\u{1F527}",
      blog: "\u270D\uFE0F",
      course: "\u{1F393}",
      other: "\u{1F4E6}"
    };
    return icons[type || "other"];
  };
  const getRoleIcon = (role) => {
    switch (role) {
      case "owner":
        return /* @__PURE__ */ jsx11(Crown, { className: "h-3 w-3 text-amber-500" });
      case "collaborator":
        return /* @__PURE__ */ jsx11(Users3, { className: "h-3 w-3 text-emerald-500" });
      default:
        return /* @__PURE__ */ jsx11(Users3, { className: "h-3 w-3 text-slate-500" });
    }
  };
  const getRoleDisplayName = (role) => {
    switch (role) {
      case "owner":
        return "Owner";
      case "collaborator":
        return "Builder";
      default:
        return "Unknown";
    }
  };
  const repoLabel = (() => {
    if (project.githubRepo) return project.githubRepo;
    if (project.githubUrl) {
      try {
        const { pathname } = new URL(project.githubUrl);
        const segments = pathname.replace(/^\/+/, "").split("/");
        if (segments.length >= 2) {
          return `${segments[0]}/${segments[1]}`.replace(/\.git$/, "");
        }
      } catch {
      }
    }
    return null;
  })();
  const descriptionText = project.description?.trim() || "No description provided yet.";
  return /* @__PURE__ */ jsxs9("div", { className: "mt-6 flex justify-center first:mt-0", children: [
    /* @__PURE__ */ jsxs9(
      Card,
      {
        className: `group relative mx-auto w-[90%] flex h-full cursor-pointer flex-col overflow-hidden border border-slate-200/80 bg-gradient-to-br from-white via-slate-50 to-slate-100 backdrop-blur transition-all duration-200 hover:-translate-y-0.5 hover:border-slate-300 hover:shadow-xl dark:border-slate-700 dark:from-slate-800 dark:via-slate-800 dark:to-slate-800 dark:hover:border-slate-600 ${isSelected ? "ring-2 ring-black dark:ring-white ring-offset-2 ring-offset-white dark:ring-offset-black" : ""}`,
        onClick: () => onSelect(isSelected ? null : project.id),
        children: [
          /* @__PURE__ */ jsxs9(CardHeader, { className: "flex flex-col gap-3 px-4 sm:px-6 pb-3 pt-6", children: [
            /* @__PURE__ */ jsxs9("div", { className: "flex items-start gap-3", children: [
              /* @__PURE__ */ jsx11("div", { className: "flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-gradient-to-br from-slate-100 via-white to-slate-50 text-lg shadow-sm dark:border-slate-700 dark:from-slate-700 dark:via-slate-800 dark:to-slate-800", children: getProjectIcon2(project.type) }),
              /* @__PURE__ */ jsxs9("div", { className: "min-w-0 flex-1 space-y-1.5", children: [
                /* @__PURE__ */ jsxs9("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsx11("h3", { className: "truncate text-base font-semibold text-slate-900 dark:text-slate-100", children: project.name || "Unnamed Project" }),
                  project.userRole && /* @__PURE__ */ jsxs9(Badge, { variant: "outline", className: "flex items-center gap-1 border-slate-300 text-xs dark:border-slate-600", children: [
                    getRoleIcon(project.userRole),
                    getRoleDisplayName(project.userRole)
                  ] })
                ] }),
                /* @__PURE__ */ jsx11("p", { className: "line-clamp-2 text-sm leading-relaxed text-slate-600 dark:text-slate-400", children: descriptionText })
              ] })
            ] }),
            (project.userRole === "owner" || project.userRole === "collaborator") && /* @__PURE__ */ jsx11("div", { className: "absolute right-4 top-4 flex-shrink-0", children: /* @__PURE__ */ jsxs9(DropdownMenu, { children: [
              /* @__PURE__ */ jsx11(DropdownMenuTrigger, { asChild: true, children: /* @__PURE__ */ jsx11(Button, { variant: "ghost", size: "icon", className: "h-8 w-8 p-0 flex-shrink-0", children: /* @__PURE__ */ jsx11(MoreHorizontal, { className: "h-4 w-4" }) }) }),
              /* @__PURE__ */ jsxs9(
                DropdownMenuContent,
                {
                  align: "end",
                  sideOffset: 8,
                  className: "z-50 w-48 rounded-xl border border-slate-200/90 dark:border-slate-700 bg-white dark:bg-slate-800 shadow-xl p-1",
                  children: [
                    project.userRole === "owner" && /* @__PURE__ */ jsxs9(Fragment4, { children: [
                      /* @__PURE__ */ jsxs9(
                        DropdownMenuItem,
                        {
                          onClick: (e) => {
                            e.stopPropagation();
                            setShowEditModal(true);
                          },
                          className: "flex items-center gap-2 px-3 py-2 text-sm text-slate-900 dark:text-slate-200 cursor-pointer rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700/50 focus:bg-slate-100 dark:focus:bg-slate-700/50",
                          children: [
                            /* @__PURE__ */ jsx11(Edit, { className: "h-4 w-4" }),
                            "Edit Project"
                          ]
                        }
                      ),
                      /* @__PURE__ */ jsx11(DropdownMenuSeparator, { className: "my-1 bg-slate-200/80 dark:bg-slate-700" })
                    ] }),
                    /* @__PURE__ */ jsxs9(
                      DropdownMenuItem,
                      {
                        onClick: (event) => {
                          event.stopPropagation();
                          onShowCollaborators();
                        },
                        className: "flex items-center gap-2 px-3 py-2 text-sm text-slate-900 dark:text-slate-100 cursor-pointer rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 focus:bg-slate-100 dark:focus:bg-slate-800",
                        children: [
                          /* @__PURE__ */ jsx11(Users3, { className: "h-4 w-4" }),
                          "Collaboration"
                        ]
                      }
                    ),
                    project.userRole === "owner" && /* @__PURE__ */ jsxs9(Fragment4, { children: [
                      /* @__PURE__ */ jsx11(DropdownMenuSeparator, { className: "my-1 bg-slate-200/80 dark:bg-slate-700" }),
                      /* @__PURE__ */ jsxs9(
                        DropdownMenuItem,
                        {
                          onClick: (e) => {
                            e.stopPropagation();
                            handleDelete();
                          },
                          disabled: isDeleting,
                          className: "flex items-center gap-2 px-3 py-2 text-sm text-red-600 dark:text-red-400 cursor-pointer rounded-lg hover:bg-red-50 dark:hover:bg-red-950/20 focus:bg-red-50 dark:focus:bg-red-950/20 focus:text-red-600 dark:focus:text-red-400 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-transparent",
                          children: [
                            /* @__PURE__ */ jsx11(Trash22, { className: "h-4 w-4" }),
                            "Delete"
                          ]
                        }
                      )
                    ] })
                  ]
                }
              )
            ] }) }),
            /* @__PURE__ */ jsxs9("div", { className: "flex flex-wrap gap-2 text-xs", children: [
              /* @__PURE__ */ jsx11(Badge, { variant: "secondary", className: `${getProjectStatusColor(project.status)} border-0`, children: getProjectStatusLabel(project.status) }),
              project.launchDate && /* @__PURE__ */ jsxs9(Badge, { variant: "outline", className: "text-xs text-slate-600 dark:text-slate-300", children: [
                "Launched ",
                new Date(project.launchDate).toLocaleDateString()
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsx11(CardContent, { className: "flex flex-1 flex-col px-0 pb-6 pt-3", children: /* @__PURE__ */ jsxs9("div", { className: "flex flex-1 flex-col gap-5 px-6 w-full", children: [
            repoLabel && /* @__PURE__ */ jsx11("div", { className: "rounded-xl border border-slate-200 bg-slate-100/90 px-4 py-2 text-xs font-medium text-slate-700 shadow-sm dark:border-slate-700 dark:bg-slate-700 dark:text-slate-200", children: /* @__PURE__ */ jsxs9("div", { className: "flex items-center justify-between gap-3", children: [
              /* @__PURE__ */ jsxs9("span", { className: "flex items-center gap-2 text-slate-800 dark:text-slate-100", children: [
                /* @__PURE__ */ jsx11(Github2, { className: "h-3.5 w-3.5" }),
                " Repository"
              ] }),
              /* @__PURE__ */ jsx11("span", { className: "truncate font-mono text-[11px] text-slate-900 dark:text-slate-100", children: repoLabel })
            ] }) }),
            /* @__PURE__ */ jsx11("div", { className: "rounded-2xl border border-slate-200 bg-white/85 px-4 py-4 shadow-sm dark:border-slate-700 dark:bg-slate-800", children: /* @__PURE__ */ jsxs9("div", { className: "grid grid-cols-3 gap-4", children: [
              /* @__PURE__ */ jsx11(MetricPill, { label: "Stars", value: formatNumber(project.githubStars || 0), icon: /* @__PURE__ */ jsx11(Star, { className: "h-3.5 w-3.5 text-amber-500" }) }),
              /* @__PURE__ */ jsx11(MetricPill, { label: "Forks", value: formatNumber(project.githubForks || 0), icon: /* @__PURE__ */ jsx11(GitFork, { className: "h-3.5 w-3.5 text-slate-500" }) }),
              /* @__PURE__ */ jsx11(
                MetricPill,
                {
                  label: "Downloads",
                  value: formatNumber(project.npmDownloads || project.downloadCount || 0),
                  icon: /* @__PURE__ */ jsx11(Download, { className: "h-3.5 w-3.5 text-emerald-500" })
                }
              )
            ] }) }),
            (project.taskCount || project.completedTaskCount) && /* @__PURE__ */ jsxs9("div", { className: "rounded-xl border border-slate-200 bg-white/80 px-4 py-3 text-xs text-slate-600 shadow-sm dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300", children: [
              /* @__PURE__ */ jsxs9("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsx11("span", { className: "font-medium", children: "Tasks" }),
                /* @__PURE__ */ jsxs9("span", { children: [
                  project.completedTaskCount || 0,
                  /* @__PURE__ */ jsxs9("span", { className: "text-slate-400", children: [
                    " / ",
                    project.taskCount || 0
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsx11(Progress, { value: project.progressPercentage || 0, className: "mt-2 h-1.5" })
            ] }),
            project.taskCount && project.taskCount > 0 || project.category === "learning" ? /* @__PURE__ */ jsxs9("div", { className: "rounded-xl border border-dashed border-slate-200 bg-white/70 px-4 py-3 dark:border-slate-700 dark:bg-slate-800/60", children: [
              /* @__PURE__ */ jsxs9("div", { className: "flex items-center justify-between text-xs text-slate-500 dark:text-slate-400", children: [
                /* @__PURE__ */ jsx11("span", { children: "Task progress" }),
                /* @__PURE__ */ jsxs9("span", { children: [
                  project.completedTaskCount || 0,
                  "/",
                  project.taskCount || 0
                ] })
              ] }),
              /* @__PURE__ */ jsx11(Progress, { value: project.progressPercentage || 0, className: "mt-2 h-1.5" })
            ] }) : null,
            /* @__PURE__ */ jsxs9("div", { className: "mt-auto flex items-center gap-2", children: [
              /* @__PURE__ */ jsxs9(
                Button,
                {
                  variant: "outline",
                  size: "sm",
                  className: "flex-1 border-slate-300 text-sm font-medium text-slate-800 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-700",
                  onClick: (e) => {
                    e.stopPropagation();
                    setShowDetailsModal(true);
                  },
                  children: [
                    /* @__PURE__ */ jsx11(Eye, { className: "mr-2 h-4 w-4" }),
                    "View details"
                  ]
                }
              ),
              project.userRole === "owner" && (project.githubUrl || project.githubRepo || project.websiteUrl) && /* @__PURE__ */ jsx11(
                Button,
                {
                  variant: "outline",
                  size: "icon",
                  className: "border-slate-300 text-slate-800 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-700",
                  onClick: (e) => {
                    e.stopPropagation();
                    handleSyncGitHubMetrics();
                  },
                  disabled: isSyncing,
                  children: /* @__PURE__ */ jsx11(RefreshCw, { className: `h-4 w-4 ${isSyncing ? "animate-spin" : ""}` })
                }
              ),
              (project.githubUrl || project.githubRepo || project.websiteUrl) && /* @__PURE__ */ jsx11(
                Button,
                {
                  variant: "ghost",
                  size: "icon",
                  className: "border border-slate-300 bg-white text-slate-800 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700",
                  onClick: (e) => {
                    e.stopPropagation();
                    const repoUrl = project.githubUrl || (project.githubRepo ? `https://github.com/${project.githubRepo}` : void 0) || project.websiteUrl;
                    if (repoUrl) {
                      window.open(repoUrl, "_blank");
                    } else {
                      toast3.error("Repository URL not available.");
                    }
                  },
                  children: /* @__PURE__ */ jsx11(Github2, { className: "h-4 w-4" })
                }
              )
            ] })
          ] }) })
        ]
      }
    ),
    project._id && /* @__PURE__ */ jsx11(
      EditProjectModal,
      {
        project: {
          _id: project._id,
          id: project.id,
          name: project.name,
          description: project.description || "",
          status: project.status,
          githubUrl: project.githubUrl,
          githubStars: project.githubStars,
          githubForks: project.githubForks,
          npmDownloads: project.npmDownloads
        },
        open: showEditModal,
        onOpenChange: setShowEditModal
      }
    ),
    project._id && /* @__PURE__ */ jsx11(ProjectDetailsModal, { projectId: project._id, open: showDetailsModal, onOpenChange: setShowDetailsModal })
  ] });
}
function MetricPill({ label, value, icon }) {
  return /* @__PURE__ */ jsxs9("div", { className: "rounded-xl border border-slate-200 bg-white/80 p-3 text-center shadow-sm transition-transform duration-200 hover:-translate-y-0.5 hover:shadow-lg dark:border-slate-700 dark:bg-slate-800", children: [
    /* @__PURE__ */ jsxs9("div", { className: "flex items-center justify-center gap-1 text-xs font-medium text-slate-500 dark:text-slate-400", children: [
      icon,
      label
    ] }),
    /* @__PURE__ */ jsx11("p", { className: "mt-1 text-sm font-semibold text-slate-800 dark:text-slate-100", children: value })
  ] });
}
function TooltipProvider({
  ...props
}) {
  return /* @__PURE__ */ jsx11(TooltipPrimitive.Provider, { "data-slot": "tooltip-provider", ...props });
}
function Tooltip({
  ...props
}) {
  return /* @__PURE__ */ jsx11(TooltipPrimitive.Root, { "data-slot": "tooltip", ...props });
}
function TooltipTrigger({
  ...props
}) {
  return /* @__PURE__ */ jsx11(TooltipPrimitive.Trigger, { "data-slot": "tooltip-trigger", ...props });
}
function TooltipContent({
  className,
  sideOffset = 4,
  ...props
}) {
  return /* @__PURE__ */ jsx11(TooltipPrimitive.Portal, { children: /* @__PURE__ */ jsx11(
    TooltipPrimitive.Content,
    {
      "data-slot": "tooltip-content",
      sideOffset,
      className: cn(
        "z-50 overflow-hidden rounded-md bg-primary px-3 py-1.5 text-xs text-primary-foreground animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
        className
      ),
      ...props
    }
  ) });
}
function PendingInvitations({ className }) {
  const queryClient = useQueryClient2();
  const invitations = useConvexQuery3(api.projects.getPendingInvitations, {});
  const acceptInvitation = useConvexMutation3(api.projects.acceptProjectInvitation);
  const declineInvitation = useConvexMutation3(api.projects.declineProjectInvitation);
  const sortedInvitations = useMemo4(() => {
    if (!invitations) return [];
    return [...invitations].sort((a, b) => b.invitedAt - a.invitedAt);
  }, [invitations]);
  if (!sortedInvitations.length) {
    return null;
  }
  const refresh = () => {
    queryClient.invalidateQueries({
      predicate: (query2) => {
        const key = query2.queryKey;
        if (!Array.isArray(key)) return false;
        return key[0] === api.projects.getPendingInvitations || key[0] === api.projects.getProjectCollaborators || key[0] === api.projects.listProjectInvitations || key[0] === api.projects.listProjects;
      }
    });
  };
  const handleRespond = async (token, action) => {
    try {
      if (action === "accept") {
        await acceptInvitation({ token });
        toast3.success("Invitation accepted!");
      } else {
        await declineInvitation({ token });
        toast3.success("Invitation declined.");
      }
      refresh();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Unable to respond to invitation.";
      toast3.error(message);
    }
  };
  return /* @__PURE__ */ jsxs9(Card, { className, children: [
    /* @__PURE__ */ jsx11(CardHeader, { className: "pb-2", children: /* @__PURE__ */ jsx11(CardTitle, { className: "text-base font-semibold", children: "Pending Invitations" }) }),
    /* @__PURE__ */ jsx11(CardContent, { className: "space-y-3", children: sortedInvitations.map((invitation) => /* @__PURE__ */ jsxs9(
      "div",
      {
        className: "flex flex-col gap-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-3 sm:flex-row sm:items-center sm:justify-between",
        children: [
          /* @__PURE__ */ jsxs9("div", { children: [
            /* @__PURE__ */ jsxs9("div", { className: "flex items-center gap-2 text-sm font-medium text-slate-900 dark:text-slate-100", children: [
              invitation.projectName,
              /* @__PURE__ */ jsx11(Badge, { variant: "secondary", className: "uppercase", children: invitation.role })
            ] }),
            /* @__PURE__ */ jsxs9("div", { className: "text-xs text-slate-500 dark:text-slate-400 mt-1", children: [
              "Invited by ",
              invitation.inviterName || "a teammate",
              " \xB7",
              " ",
              new Date(invitation.invitedAt).toLocaleString()
            ] }),
            /* @__PURE__ */ jsxs9("div", { className: "text-xs text-slate-400 dark:text-slate-500 mt-1", children: [
              "Expires ",
              new Date(invitation.expiresAt).toLocaleString()
            ] })
          ] }),
          /* @__PURE__ */ jsxs9("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx11(
              Button,
              {
                size: "sm",
                className: "bg-black text-white hover:bg-gray-800 dark:bg-white dark:text-black dark:hover:bg-gray-200",
                onClick: () => handleRespond(invitation.token, "accept"),
                children: "Accept"
              }
            ),
            /* @__PURE__ */ jsx11(
              Button,
              {
                variant: "outline",
                size: "sm",
                onClick: () => handleRespond(invitation.token, "decline"),
                children: "Decline"
              }
            )
          ] })
        ]
      },
      invitation.id
    )) })
  ] });
}
function ProjectsPage() {
  const session = useSession2();
  const [isModalOpen, setIsModalOpen] = useState5(false);
  const [isAddTaskModalOpen, setIsAddTaskModalOpen] = useState5(false);
  const [isImageAnalyticsOpen, setIsImageAnalyticsOpen] = useState5(false);
  const [imageAnalysisSession, setImageAnalysisSession] = useState5(null);
  const [selectedProjectId, setSelectedProjectId] = useState5(null);
  const [filterProject, setFilterProject] = useState5("all");
  const [statusFilter, setStatusFilter] = useState5("all");
  const [priorityFilter, setPriorityFilter] = useState5("all");
  const [viewMode, setViewMode] = useState5("details");
  const [now, setNow] = useState5(() => Date.now());
  const [isEditModalOpen, setIsEditModalOpen] = useState5(false);
  const [editingProject, setEditingProject] = useState5(null);
  const [editingTaskId, setEditingTaskId] = useState5(null);
  const [collaborationProject, setCollaborationProject] = useState5(null);
  const queryClient = useQueryClient2();
  const createDefaultEditForm = () => ({
    text: "",
    details: "",
    priority: "low",
    hrs: 1,
    refLink: "",
    projectId: "",
    sharedWith: ""
  });
  const projects = useConvexQuery3(api.projects.listProjects, {});
  const allTasks = useConvexQuery3(api.tasks.listTasks, {});
  const allCollaborators = useConvexQuery3(api.projects.getAllCollaborators, {});
  const emailToNameMap = useMemo4(() => {
    const map = /* @__PURE__ */ new Map();
    if (!allCollaborators) return map;
    allCollaborators.forEach((collaborator) => {
      const email = collaborator.email.toLowerCase().trim();
      if (collaborator.userName) {
        map.set(email, collaborator.userName);
      }
    });
    return map;
  }, [allCollaborators]);
  const getDisplayName = (email) => {
    const normalizedEmail = email.toLowerCase().trim();
    return emailToNameMap.get(normalizedEmail) || email;
  };
  const filteredTasks = useMemo4(() => {
    const baseTasks = filterProject === "all" ? allTasks ?? [] : filterProject === "none" ? (allTasks ?? []).filter((task) => !task.projectId) : (allTasks ?? []).filter((task) => task.projectId === filterProject);
    return baseTasks.filter((task) => {
      const normalizedStatus = (task.status || "").toLowerCase();
      const normalizedPriority = (task.priority || "").toLowerCase();
      if (statusFilter !== "all" && normalizedStatus !== statusFilter) {
        return false;
      }
      if (priorityFilter !== "all" && normalizedPriority !== priorityFilter) {
        return false;
      }
      return true;
    });
  }, [allTasks, filterProject, statusFilter, priorityFilter]);
  const statusOptions2 = useMemo4(() => {
    const set = /* @__PURE__ */ new Set();
    if (Array.isArray(allTasks)) {
      allTasks.forEach((task) => {
        const normalized = (task.status || "").toLowerCase();
        if (normalized) {
          set.add(normalized);
        }
      });
    }
    return ["all", ...Array.from(set).sort()];
  }, [allTasks]);
  const priorityOptions = useMemo4(() => {
    const set = /* @__PURE__ */ new Set();
    if (Array.isArray(allTasks)) {
      allTasks.forEach((task) => {
        const normalized = (task.priority || "").toLowerCase();
        if (normalized) {
          set.add(normalized);
        }
      });
    }
    return ["all", ...Array.from(set).sort()];
  }, [allTasks]);
  const projectFilterOptions = useMemo4(() => {
    const items = [{
      value: "all",
      label: "All Projects"
    }, {
      value: "none",
      label: "No Project"
    }];
    if (Array.isArray(projects)) {
      projects.forEach((project) => {
        items.push({
          value: project._id,
          label: project.name || "Untitled Project"
        });
      });
    }
    return items;
  }, [projects]);
  const formatFilterLabel = (value) => {
    if (value === "all") return "All";
    return value.split(/[-_\s]+/).filter(Boolean).map((segment) => segment.charAt(0).toUpperCase() + segment.slice(1)).join(" ");
  };
  const getProjectName = (projectId) => {
    if (!projectId || !projects) return null;
    return projects.find((p) => p._id === projectId)?.name || null;
  };
  const getSharedEmails = (sharedWith) => {
    if (!sharedWith) return [];
    try {
      const emails = JSON.parse(sharedWith);
      return Array.isArray(emails) ? emails : [];
    } catch {
      return [];
    }
  };
  useConvexMutation3(api.projects.deleteProject);
  const updateTask = useConvexMutation3(api.tasks.updateTask);
  const deleteTask = useConvexMutation3(api.tasks.deleteTask);
  useConvexMutation3(api.projects.updateProject);
  useConvexAction(api.projects.inviteProjectCollaborator);
  const shareTaskWithCollaborators = useConvexMutation3(api.tasks.shareTaskWithCollaborators);
  const unshareTaskMutation = useConvexMutation3(api.tasks.unshareTask);
  useConvexMutation3(api.projects.removeProjectCollaborator);
  const [editTaskForm, setEditTaskForm] = useState5(createDefaultEditForm);
  const [isSubmitting, setIsSubmitting] = useState5(false);
  useEffect7(() => {
    const interval = window.setInterval(() => setNow(Date.now()), 6e4);
    return () => window.clearInterval(interval);
  }, []);
  const computeTrackedTime = (task) => {
    const base = task.trackedTimeMs ?? 0;
    const normalizedStatus = (task.status || "").toLowerCase();
    const isRunning = normalizedStatus === "in progress" || normalizedStatus === "in-progress" || normalizedStatus === "running";
    const active = task.startedAt && isRunning ? Math.max(0, now - task.startedAt) : 0;
    return base + active;
  };
  const formatDuration2 = (milliseconds) => {
    const totalSeconds = Math.floor(milliseconds / 1e3);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor(totalSeconds % 3600 / 60);
    const seconds = totalSeconds % 60;
    return [hours, minutes, seconds].map((part) => String(part).padStart(2, "0")).join(":");
  };
  const handleCancelEdit = () => {
    setEditingTaskId(null);
    setEditTaskForm(createDefaultEditForm());
  };
  const handleEditTask = (task) => {
    setEditingTaskId(task._id);
    const sharedEmails = getSharedEmails(task.sharedWith);
    setEditTaskForm({
      text: task.text,
      details: task.details || "",
      priority: task.priority || "low",
      hrs: task.hrs || 1,
      refLink: task.refLink || "",
      projectId: task.projectId || "",
      sharedWith: sharedEmails.join(", ")
    });
  };
  const handleSubmitEdit = async () => {
    if (!editingTaskId || !editTaskForm.text.trim()) {
      return;
    }
    const taskId = editingTaskId;
    setIsSubmitting(true);
    try {
      const sharedWithJson = editTaskForm.sharedWith ? JSON.stringify(editTaskForm.sharedWith.split(",").map((email) => email.trim()).filter((email) => email)) : void 0;
      await updateTask({
        taskId,
        text: editTaskForm.text,
        details: editTaskForm.details || "",
        priority: editTaskForm.priority,
        hrs: editTaskForm.hrs,
        refLink: editTaskForm.refLink || "",
        projectId: editTaskForm.projectId || void 0,
        sharedWith: sharedWithJson
      });
      queryClient.invalidateQueries({
        predicate: (query2) => {
          const key = query2.queryKey;
          return Array.isArray(key) && key[0] === api.tasks.listTasks;
        }
      });
      setEditingTaskId(null);
      setEditTaskForm(createDefaultEditForm());
      toast3.success("Task updated successfully!");
    } catch (error) {
      console.error("Failed to update task:", error);
      toast3.error("Failed to update task. Please try again.");
      setEditingTaskId(taskId);
    } finally {
      setIsSubmitting(false);
    }
  };
  const handleImageAnalysisTasksCreated = useCallback(async () => {
    await queryClient.invalidateQueries({
      predicate: (query2) => {
        const key = query2.queryKey;
        return Array.isArray(key) && key[0] === api.tasks.listTasks;
      }
    });
  }, [queryClient]);
  const handleBeginImageAnalysisSession = useCallback((payload) => {
    setImageAnalysisSession(payload);
    setIsImageAnalyticsOpen(false);
  }, []);
  const closeImageAnalysisSession = useCallback(() => {
    setImageAnalysisSession(null);
  }, []);
  const handleToggleTask = async (task) => {
    const currentStatus = task.status || "todo";
    const newStatus = currentStatus === "done" ? "todo" : "done";
    try {
      await updateTask({
        taskId: task._id,
        status: newStatus
      });
      queryClient.invalidateQueries({
        predicate: (query2) => {
          const key = query2.queryKey;
          return Array.isArray(key) && key[0] === api.tasks.listTasks;
        }
      });
    } catch (error) {
      console.error("Failed to toggle task:", error);
      alert("Failed to update task. Please try again.");
    }
  };
  const handleDeleteTask = async (task) => {
    try {
      await deleteTask({
        taskId: task._id
      });
      queryClient.invalidateQueries({
        predicate: (query2) => {
          const key = query2.queryKey;
          return Array.isArray(key) && key[0] === api.tasks.listTasks;
        }
      });
    } catch (error) {
      console.error("Failed to delete task:", error);
      alert("Failed to delete task. Please try again.");
    }
  };
  const handleShareTask = async (task) => {
    try {
      const result = await shareTaskWithCollaborators({
        taskId: task._id
      });
      if (!result?.success) {
        toast3.info(result?.message || "No collaborators to share with yet");
      } else if (result.added === 0) {
        toast3.info(result.message || "Task already shared with collaborators");
      } else {
        toast3.success(result.message || "Task shared with project collaborators");
      }
      queryClient.invalidateQueries({
        predicate: (query2) => {
          const key = query2.queryKey;
          return Array.isArray(key) && key[0] === api.tasks.listTasks;
        }
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to share task";
      toast3.error(message);
    }
  };
  const handleUnshareTask = async (task) => {
    try {
      await unshareTaskMutation({
        taskId: task._id
      });
      toast3.success("Task unshared from collaborators");
      queryClient.invalidateQueries({
        predicate: (query2) => {
          const key = query2.queryKey;
          return Array.isArray(key) && key[0] === api.tasks.listTasks;
        }
      });
    } catch (error) {
      console.error("Failed to unshare task:", error);
      toast3.error("Failed to unshare task. Please try again.");
    }
  };
  const handleProjectSelect = (projectId) => {
    if (projectId) {
      const foundProject = projects?.find((p) => p.id === projectId || p._id === projectId);
      if (foundProject) {
        setSelectedProjectId(foundProject._id);
        setFilterProject(foundProject._id);
      }
    } else {
      setSelectedProjectId(null);
      setFilterProject("all");
    }
  };
  if (!session) {
    return /* @__PURE__ */ jsx11("div", { className: "flex items-center justify-center h-screen", children: /* @__PURE__ */ jsxs9("div", { className: "text-center", children: [
      /* @__PURE__ */ jsx11("p", { className: "text-lg text-muted-foreground mb-4", children: "Please log in to view projects." }),
      /* @__PURE__ */ jsx11(Link3, { to: "/login", children: /* @__PURE__ */ jsx11(Button, { size: "lg", children: "Log In" }) })
    ] }) });
  }
  const projectOptions = useMemo4(() => {
    if (!projects) return [];
    return projects.map((project) => ({
      _id: project._id,
      id: project.id,
      name: project.name,
      description: project.description,
      type: project.type,
      category: project.category,
      status: project.status,
      githubUrl: project.githubUrl,
      userRole: project.userRole
    }));
  }, [projects]);
  const totalTasks = filteredTasks.length;
  const completedTasks = filteredTasks.filter((task) => {
    const normalized = (task.status || "").toLowerCase();
    return normalized === "done" || normalized === "completed";
  }).length;
  const inProgressTasks = filteredTasks.filter((task) => {
    const normalized = (task.status || "").toLowerCase();
    return normalized === "in progress" || normalized === "in-progress" || normalized === "running";
  }).length;
  const backlogTasks = filteredTasks.filter((task) => {
    const normalized = (task.status || "").toLowerCase();
    return !normalized || normalized === "not started" || normalized === "todo" || normalized === "backlog";
  }).length;
  const selectedProject = filterProject === "all" ? null : projects?.find((project) => project._id === filterProject) ?? null;
  const ownedProjects = useMemo4(() => {
    if (!projects) return [];
    return projects.filter((project) => project.userRole === "owner");
  }, [projects]);
  const sharedProjects = useMemo4(() => {
    if (!projects) return [];
    return projects.filter((project) => project.userRole !== "owner");
  }, [projects]);
  return /* @__PURE__ */ jsx11(TooltipProvider, { children: /* @__PURE__ */ jsxs9("div", { className: "h-screen bg-white dark:bg-slate-900 flex", children: [
    session && /* @__PURE__ */ jsxs9("div", { className: "w-16 sm:w-64 lg:w-[25rem] xl:w-[27rem] bg-white dark:bg-slate-800 border-r border-gray-200 dark:border-slate-700 shadow-xl flex flex-col", children: [
      /* @__PURE__ */ jsx11("div", { className: "pt-1 pl-2 pr-1 pb-0 sm:pt-2 sm:pl-3 sm:pr-1.5 sm:pb-0 lg:pt-3 lg:pl-2 lg:pr-1 lg:pb-0", children: /* @__PURE__ */ jsx11("div", { className: "hidden lg:block flex justify-center -mx-2 pb-2 mb-1", children: /* @__PURE__ */ jsxs9(Dock, { iconMagnification: 50, iconDistance: 80, className: "bg-gray-100 dark:bg-slate-800 !mt-0", children: [
        /* @__PURE__ */ jsxs9(DropdownMenu, { children: [
          /* @__PURE__ */ jsx11(DropdownMenuTrigger, { asChild: true, children: /* @__PURE__ */ jsx11(DockIcon, { className: "bg-black dark:bg-white text-white dark:text-black hover:bg-gray-800 dark:hover:bg-gray-200 cursor-pointer", children: /* @__PURE__ */ jsx11(Plus, { className: "w-4 h-4" }) }) }),
          /* @__PURE__ */ jsxs9(DropdownMenuContent, { align: "center", side: "bottom", className: "z-50 mt-2 w-48 rounded-xl border border-slate-200/80 bg-white/95 p-1 shadow-2xl ring-1 ring-black/5 dark:border-slate-700 dark:bg-slate-800 dark:ring-slate-700", children: [
            /* @__PURE__ */ jsxs9(DropdownMenuItem, { onClick: () => setIsAddTaskModalOpen(true), className: "flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-slate-900 transition-colors hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-700/50", children: [
              /* @__PURE__ */ jsx11(CheckSquare2, { className: "h-4 w-4" }),
              "New Task"
            ] }),
            /* @__PURE__ */ jsxs9(DropdownMenuItem, { onClick: () => setIsModalOpen(true), className: "flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-slate-900 transition-colors hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-700/50", children: [
              /* @__PURE__ */ jsx11(FolderOpen, { className: "h-4 w-4" }),
              "New Project"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs9(Tooltip, { children: [
          /* @__PURE__ */ jsx11(TooltipTrigger, { asChild: true, children: /* @__PURE__ */ jsx11(DockIcon, { className: "bg-purple-600 text-white hover:bg-purple-700 dark:bg-purple-500 dark:text-white", onClick: () => setIsImageAnalyticsOpen(true), children: /* @__PURE__ */ jsx11(Sparkles, { className: "h-4 w-4" }) }) }),
          /* @__PURE__ */ jsx11(TooltipContent, { side: "bottom", children: "Analyze image" })
        ] })
      ] }) }) }),
      /* @__PURE__ */ jsxs9("div", { className: "flex-1 p-2 sm:p-3 lg:hidden space-y-2 sm:space-y-3", children: [
        /* @__PURE__ */ jsxs9("button", { type: "button", onClick: () => setIsAddTaskModalOpen(true), className: "w-full inline-flex items-center justify-center sm:justify-start gap-2 sm:gap-3 px-2 sm:px-4 py-2 sm:py-3.5 bg-black dark:bg-white text-white dark:text-black hover:bg-gray-800 dark:hover:bg-gray-200 font-semibold rounded-lg sm:rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 text-xs sm:text-sm transform hover:scale-[1.02] hover:-translate-y-0.5 active:scale-[0.98]", children: [
          /* @__PURE__ */ jsx11("div", { className: "w-5 h-5 bg-white/20 dark:bg-black/20 rounded-full flex items-center justify-center", children: /* @__PURE__ */ jsx11(AddTaskIcon, { className: "w-3.5 h-3.5" }) }),
          /* @__PURE__ */ jsx11("span", { className: "hidden sm:inline", children: "Add New Task" })
        ] }),
        /* @__PURE__ */ jsxs9("button", { type: "button", onClick: () => setIsModalOpen(true), className: "w-full inline-flex items-center justify-center sm:justify-start gap-2 sm:gap-3 px-2 sm:px-4 py-2 sm:py-3.5 bg-black dark:bg-white text-white dark:text-black hover:bg-gray-800 dark:hover:bg-gray-200 font-semibold rounded-lg sm:rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 text-xs sm:text-sm transform hover:scale-[1.02] hover:-translate-y-0.5 active:scale-[0.98]", children: [
          /* @__PURE__ */ jsx11("div", { className: "w-5 h-5 bg-white/20 dark:bg-black/20 rounded-full flex items-center justify-center", children: /* @__PURE__ */ jsx11(FolderOpen, { className: "w-3.5 h-3.5" }) }),
          /* @__PURE__ */ jsx11("span", { className: "hidden sm:inline", children: "New Project" })
        ] }),
        /* @__PURE__ */ jsxs9("button", { type: "button", onClick: () => setIsImageAnalyticsOpen(true), className: "w-full inline-flex items-center justify-center sm:justify-start gap-2 sm:gap-3 px-2 sm:px-4 py-2 sm:py-3.5 bg-purple-600 dark:bg-purple-500 text-white hover:bg-purple-700 dark:hover:bg-purple-400 font-semibold rounded-lg sm:rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 text-xs sm:text-sm transform hover:scale-[1.02] hover:-translate-y-0.5 active:scale-[0.98]", children: [
          /* @__PURE__ */ jsx11("div", { className: "w-5 h-5 bg-white/20 rounded-full flex items-center justify-center", children: /* @__PURE__ */ jsx11(Sparkles, { className: "w-3.5 h-3.5" }) }),
          /* @__PURE__ */ jsx11("span", { className: "hidden sm:inline", children: "Analyze Image" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs9("div", { className: "flex-1 px-3 sm:px-4 py-2 sm:py-3 space-y-4 overflow-y-auto", children: [
        /* @__PURE__ */ jsx11("div", { className: "mb-4" }),
        projects && projects.length > 0 ? /* @__PURE__ */ jsxs9("div", { className: "hidden sm:flex sm:flex-col sm:gap-10", children: [
          ownedProjects.length > 0 && /* @__PURE__ */ jsxs9("div", { className: "flex flex-col gap-6", children: [
            /* @__PURE__ */ jsx11("p", { className: "text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400", children: "My Projects" }),
            /* @__PURE__ */ jsx11("div", { className: "flex flex-col gap-6", children: ownedProjects.map((project) => /* @__PURE__ */ jsx11(SidebarProjectCard, { project: {
              _id: project._id,
              id: project.id,
              name: project.name,
              description: project.description,
              status: project.status,
              githubUrl: project.githubUrl,
              githubStars: project.githubStars,
              githubForks: project.githubForks,
              npmDownloads: project.npmDownloads,
              userRole: project.userRole
            }, isSelected: selectedProjectId === project._id, onSelect: handleProjectSelect, onShowCollaborators: () => {
              setCollaborationProject(project);
            } }, project._id)) })
          ] }),
          sharedProjects.length > 0 && /* @__PURE__ */ jsxs9("div", { className: "mt-8 flex flex-col gap-6 pt-2", children: [
            /* @__PURE__ */ jsx11("p", { className: "pt-1 pb-3 text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400", children: "Shared With Me" }),
            /* @__PURE__ */ jsx11("div", { className: "flex flex-col gap-6", children: sharedProjects.map((project) => /* @__PURE__ */ jsx11(SidebarProjectCard, { project: {
              _id: project._id,
              id: project.id,
              name: project.name,
              description: project.description,
              status: project.status,
              githubUrl: project.githubUrl,
              githubStars: project.githubStars,
              githubForks: project.githubForks,
              npmDownloads: project.npmDownloads,
              userRole: project.userRole
            }, isSelected: selectedProjectId === project._id, onSelect: handleProjectSelect, onShowCollaborators: () => {
              setCollaborationProject(project);
            } }, project._id)) })
          ] })
        ] }) : /* @__PURE__ */ jsxs9("div", { className: "text-center py-8 hidden sm:block", children: [
          /* @__PURE__ */ jsx11("div", { className: "w-16 h-16 bg-gray-100 dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4", children: /* @__PURE__ */ jsx11("svg", { className: "w-8 h-8 text-gray-400 dark:text-slate-500", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx11("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" }) }) }),
          /* @__PURE__ */ jsx11("h3", { className: "text-sm font-medium text-gray-900 dark:text-slate-200 mb-2", children: "No projects yet" }),
          /* @__PURE__ */ jsx11("p", { className: "text-xs text-gray-600 dark:text-slate-400 mb-4", children: "Create your first project to get started" }),
          /* @__PURE__ */ jsxs9(Button, { size: "sm", className: "bg-black dark:bg-white text-white dark:text-black hover:bg-gray-800 dark:hover:bg-gray-200", onClick: () => setIsModalOpen(true), children: [
            /* @__PURE__ */ jsx11(Plus, { className: "h-4 w-4 mr-2" }),
            "Create Project"
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx11("div", { className: "flex-1 overflow-y-auto bg-gradient-to-br from-slate-50 via-white to-slate-100 dark:from-slate-900 dark:via-slate-900 dark:to-slate-900", children: /* @__PURE__ */ jsx11("div", { className: "px-4 pt-3 pb-6 sm:px-6 sm:pt-4 lg:px-8 lg:pt-5", children: /* @__PURE__ */ jsxs9("div", { className: "max-w-5xl mx-auto w-full", children: [
      /* @__PURE__ */ jsxs9("div", { className: "mb-4 flex items-center justify-between", children: [
        /* @__PURE__ */ jsx11("h1", { className: "text-3xl font-bold tracking-tight text-foreground", children: filterProject === "all" ? "Task List" : filterProject === "none" ? "Unassigned Tasks" : getProjectName(filterProject) || "Task List" }),
        /* @__PURE__ */ jsxs9("div", { className: "flex items-center gap-2 rounded-lg border border-slate-200/80 bg-white/90 p-1 shadow-sm dark:border-slate-700 dark:bg-slate-800", children: [
          /* @__PURE__ */ jsxs9("button", { type: "button", onClick: () => setViewMode("details"), className: cn("flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors", viewMode === "details" ? "bg-black text-white dark:bg-white dark:text-black" : "text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100"), children: [
            /* @__PURE__ */ jsx11(LayoutGrid, { className: "h-4 w-4" }),
            "Details"
          ] }),
          /* @__PURE__ */ jsxs9("button", { type: "button", onClick: () => setViewMode("brief"), className: cn("flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors", viewMode === "brief" ? "bg-black text-white dark:bg-white dark:text-black" : "text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100"), children: [
            /* @__PURE__ */ jsx11(List, { className: "h-4 w-4" }),
            "Brief"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsx11(PendingInvitations, { className: "mb-2" }),
      /* @__PURE__ */ jsx11("div", { className: "flex justify-center", style: {
        marginTop: "56px",
        marginBottom: "40px"
      }, children: /* @__PURE__ */ jsxs9("div", { className: "grid w-full max-w-3xl grid-cols-1 gap-4 sm:grid-cols-3", children: [
        /* @__PURE__ */ jsxs9("div", { className: "rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-4 shadow-sm", children: [
          /* @__PURE__ */ jsx11("p", { className: "text-xs text-muted-foreground dark:text-slate-400", children: "Total Tasks" }),
          /* @__PURE__ */ jsx11("p", { className: "mt-1 text-2xl font-bold text-foreground dark:text-slate-100", children: totalTasks })
        ] }),
        /* @__PURE__ */ jsxs9("div", { className: "rounded-2xl border border-emerald-200 dark:border-emerald-800/50 bg-emerald-50 dark:bg-emerald-950/60 p-4 shadow-sm", children: [
          /* @__PURE__ */ jsx11("p", { className: "text-xs text-emerald-700 dark:text-emerald-300", children: "Completed" }),
          /* @__PURE__ */ jsxs9("div", { className: "mt-1 flex items-baseline justify-between gap-2", children: [
            /* @__PURE__ */ jsx11("p", { className: "text-2xl font-bold text-emerald-600 dark:text-emerald-300", children: completedTasks }),
            /* @__PURE__ */ jsxs9("p", { className: "text-xs text-emerald-700/80 dark:text-emerald-300/80 whitespace-nowrap", children: [
              "(",
              totalTasks === 0 ? 0 : Math.round(completedTasks / totalTasks * 100),
              "% done)"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs9("div", { className: "rounded-2xl border border-blue-200 dark:border-blue-800/50 bg-blue-50 dark:bg-blue-950/60 p-4 shadow-sm", children: [
          /* @__PURE__ */ jsx11("p", { className: "text-xs text-blue-700 dark:text-blue-300", children: "In Progress" }),
          /* @__PURE__ */ jsxs9("div", { className: "mt-1 flex items-baseline justify-between gap-2", children: [
            /* @__PURE__ */ jsx11("p", { className: "text-2xl font-bold text-blue-600 dark:text-blue-300", children: inProgressTasks }),
            /* @__PURE__ */ jsxs9("p", { className: "text-xs text-blue-700/80 dark:text-blue-300/80 whitespace-nowrap", children: [
              "(",
              backlogTasks,
              " waiting to start)"
            ] })
          ] })
        ] })
      ] }) }),
      /* @__PURE__ */ jsx11("div", { className: "flex justify-center mb-6", children: /* @__PURE__ */ jsxs9("div", { className: "grid w-full max-w-3xl gap-3 sm:grid-cols-2 lg:grid-cols-4", children: [
        /* @__PURE__ */ jsxs9("div", { className: "flex flex-col gap-0.5", children: [
          /* @__PURE__ */ jsx11("p", { className: "text-xs font-medium uppercase tracking-wide text-slate-500 dark:text-slate-400", children: "Project" }),
          /* @__PURE__ */ jsxs9(Select, { value: filterProject === "all" ? "all" : filterProject === "none" ? "none" : filterProject, onValueChange: (value) => {
            if (value === "all") {
              setFilterProject("all");
            } else if (value === "none") {
              setFilterProject("none");
            } else {
              setFilterProject(value);
            }
          }, children: [
            /* @__PURE__ */ jsx11(SelectTrigger, { className: "flex h-9 items-center justify-between rounded-lg border border-slate-200/80 bg-white/90 px-3 text-sm font-medium shadow-sm transition-colors focus:outline-none focus:ring-2 focus:ring-ring dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100", children: /* @__PURE__ */ jsx11(SelectValue, {}) }),
            /* @__PURE__ */ jsx11(SelectContent, { className: "z-50 rounded-xl border border-slate-200/80 bg-white/95 shadow-xl dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100", children: projectFilterOptions.map((option) => /* @__PURE__ */ jsx11(SelectItem, { value: option.value, children: option.label }, option.value)) })
          ] })
        ] }),
        /* @__PURE__ */ jsxs9("div", { className: "flex flex-col gap-0.5", children: [
          /* @__PURE__ */ jsx11("p", { className: "text-xs font-medium uppercase tracking-wide text-slate-500 dark:text-slate-400", children: "Status" }),
          /* @__PURE__ */ jsxs9(Select, { value: statusFilter, onValueChange: setStatusFilter, children: [
            /* @__PURE__ */ jsx11(SelectTrigger, { className: "flex h-9 items-center justify-between rounded-lg border border-slate-200/80 bg-white/90 px-3 text-sm font-medium shadow-sm transition-colors focus:outline-none focus:ring-2 focus:ring-ring dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100", children: /* @__PURE__ */ jsx11(SelectValue, {}) }),
            /* @__PURE__ */ jsx11(SelectContent, { className: "z-50 rounded-xl border border-slate-200/80 bg-white/95 shadow-xl dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100", children: statusOptions2.map((option) => /* @__PURE__ */ jsx11(SelectItem, { value: option, children: formatFilterLabel(option) }, option)) })
          ] })
        ] }),
        /* @__PURE__ */ jsxs9("div", { className: "flex flex-col gap-0.5", children: [
          /* @__PURE__ */ jsxs9("div", { className: "flex items-center justify-between w-full", children: [
            /* @__PURE__ */ jsx11("p", { className: "text-xs font-medium uppercase tracking-wide text-slate-500 dark:text-slate-400", children: "Priority" }),
            /* @__PURE__ */ jsx11("button", { type: "button", onClick: () => {
              setFilterProject("all");
              setStatusFilter("all");
              setPriorityFilter("all");
            }, className: "text-xs font-medium text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 underline-offset-2 hover:underline transition-colors whitespace-nowrap", children: "Clear Filters" })
          ] }),
          /* @__PURE__ */ jsxs9(Select, { value: priorityFilter, onValueChange: setPriorityFilter, children: [
            /* @__PURE__ */ jsx11(SelectTrigger, { className: "flex h-9 items-center justify-between rounded-lg border border-slate-200/80 bg-white/90 px-3 text-sm font-medium shadow-sm transition-colors focus:outline-none focus:ring-2 focus:ring-ring dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100", children: /* @__PURE__ */ jsx11(SelectValue, {}) }),
            /* @__PURE__ */ jsx11(SelectContent, { className: "z-50 rounded-xl border border-slate-200/80 bg-white/95 shadow-xl dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100", children: priorityOptions.map((option) => /* @__PURE__ */ jsx11(SelectItem, { value: option, children: formatFilterLabel(option) }, option)) })
          ] })
        ] })
      ] }) }),
      filteredTasks.length === 0 ? /* @__PURE__ */ jsxs9("div", { className: "text-center py-16 px-6 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 bg-white/60 dark:bg-slate-800/60 shadow-inner", children: [
        /* @__PURE__ */ jsx11("div", { className: "mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-slate-100 dark:bg-slate-700/50", children: /* @__PURE__ */ jsx11(FolderKanban3, { className: "h-10 w-10 text-muted-foreground dark:text-slate-400" }) }),
        /* @__PURE__ */ jsx11("h3", { className: "text-2xl font-semibold text-foreground mb-3", children: filterProject === "all" ? "No tasks yet" : filterProject === "none" ? "No unassigned tasks yet" : "No tasks in this project" }),
        /* @__PURE__ */ jsx11("p", { className: "text-muted-foreground dark:text-slate-400 max-w-md mx-auto mb-8", children: filterProject === "all" ? "Create your first task to get started and stay organized." : filterProject === "none" ? "Assign tasks to a project to organize them better." : "Add tasks to this project to track your progress." }),
        /* @__PURE__ */ jsxs9(Button, { onClick: () => setIsAddTaskModalOpen(true), size: "lg", className: "shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-[1.02] active:scale-95 bg-black dark:bg-white text-white dark:text-black hover:bg-gray-800 dark:hover:bg-gray-200", children: [
          /* @__PURE__ */ jsx11(Plus, { className: "h-5 w-5 mr-2" }),
          "Add Task"
        ] })
      ] }) : viewMode === "brief" ? /* @__PURE__ */ jsx11("div", { className: "mt-8 w-full max-w-6xl mx-auto", style: {
        paddingTop: "12px"
      }, children: /* @__PURE__ */ jsx11("div", { className: "rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 overflow-hidden shadow-sm", children: /* @__PURE__ */ jsx11("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxs9("table", { className: "w-full", children: [
        /* @__PURE__ */ jsx11("thead", { className: "bg-slate-50 dark:bg-slate-700 border-b border-slate-200 dark:border-slate-600", children: /* @__PURE__ */ jsxs9("tr", { children: [
          /* @__PURE__ */ jsx11("th", { className: "px-6 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-300", children: "Project Name" }),
          /* @__PURE__ */ jsx11("th", { className: "px-6 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-300", children: "Main Task Name" }),
          /* @__PURE__ */ jsx11("th", { className: "px-6 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-300", children: "Priority" }),
          /* @__PURE__ */ jsx11("th", { className: "px-6 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-300", children: "Estimate Hour" }),
          /* @__PURE__ */ jsx11("th", { className: "px-6 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-300", children: "Status" })
        ] }) }),
        /* @__PURE__ */ jsx11("tbody", { className: "divide-y divide-slate-200 dark:divide-slate-700/50", children: filteredTasks.map((task) => {
          const projectName = task.projectId ? getProjectName(task.projectId) : "Unassigned";
          const priority = task.priority || "low";
          const estimateHours = task.hrs || 0;
          const status = task.status || "todo";
          const getPriorityBadgeColor = (priority2) => {
            switch (priority2.toLowerCase()) {
              case "high":
                return "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300";
              case "medium":
                return "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/40 dark:text-yellow-300";
              case "low":
                return "bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300";
              default:
                return "bg-slate-100 text-slate-700 dark:bg-slate-700/50 dark:text-slate-300";
            }
          };
          const getStatusBadgeColor = (status2) => {
            const normalizedStatus = status2.toLowerCase();
            if (normalizedStatus === "done" || normalizedStatus === "completed") {
              return "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300";
            } else if (normalizedStatus === "in progress" || normalizedStatus === "in-progress" || normalizedStatus === "running") {
              return "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300";
            } else {
              return "bg-slate-100 text-slate-700 dark:bg-slate-700/50 dark:text-slate-300";
            }
          };
          return /* @__PURE__ */ jsxs9("tr", { className: "hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors", children: [
            /* @__PURE__ */ jsx11("td", { className: "px-6 py-4 whitespace-nowrap text-sm text-slate-900 dark:text-slate-100", children: projectName }),
            /* @__PURE__ */ jsx11("td", { className: "px-6 py-4 text-sm text-slate-900 dark:text-slate-100", children: task.text }),
            /* @__PURE__ */ jsx11("td", { className: "px-6 py-4 whitespace-nowrap", children: /* @__PURE__ */ jsx11(Badge, { className: cn("text-xs", getPriorityBadgeColor(priority)), children: priority.charAt(0).toUpperCase() + priority.slice(1) }) }),
            /* @__PURE__ */ jsxs9("td", { className: "px-6 py-4 whitespace-nowrap text-sm text-slate-900 dark:text-slate-100", children: [
              estimateHours,
              " ",
              estimateHours === 1 ? "hr" : "hrs"
            ] }),
            /* @__PURE__ */ jsx11("td", { className: "px-6 py-4 whitespace-nowrap", children: /* @__PURE__ */ jsx11(Badge, { className: cn("text-xs", getStatusBadgeColor(status)), children: status.charAt(0).toUpperCase() + status.slice(1) }) })
          ] }, task._id);
        }) })
      ] }) }) }) }) : /* @__PURE__ */ jsx11("div", { className: "mt-8 flex flex-col items-center", children: filteredTasks.map((task, index) => {
        const normalizedStatus = (task.status || "").toLowerCase();
        const totalTrackedMs = computeTrackedTime(task);
        const isRunningTask = normalizedStatus === "in progress" || normalizedStatus === "in-progress" || normalizedStatus === "running";
        const runningTimeLabel = totalTrackedMs > 0 ? formatDuration2(totalTrackedMs) : null;
        const typedTask = {
          ...task,
          priority: task.priority ?? void 0,
          status: task.status,
          hrs: task.hrs ?? void 0,
          startedAt: task.startedAt ? new Date(task.startedAt) : null,
          completedAt: task.completedAt ? new Date(task.completedAt) : null,
          trackedTimeMs: task.trackedTimeMs ?? void 0
        };
        const projectName = typedTask.projectId ? getProjectName(typedTask.projectId) : null;
        const sharedEmails = getSharedEmails(typedTask.sharedWith);
        const sharedDisplayNames = sharedEmails.map((email) => getDisplayName(email));
        const isOwner = session.user.id === typedTask.userId;
        return /* @__PURE__ */ jsx11("div", { className: "mx-auto w-full max-w-3xl", style: {
          paddingTop: index === 0 ? "12px" : "32px"
        }, children: /* @__PURE__ */ jsx11(TaskCard, { task: typedTask, projectName, isOwner, sharedEmails: sharedDisplayNames, isEditing: editingTaskId === typedTask._id, editForm: editTaskForm, isSubmitting, projects: projectOptions, wrapperStyle: {
          margin: 0
        }, onEdit: () => handleEditTask(task), onDelete: () => handleDeleteTask(task), onToggle: () => handleToggleTask(task), onShare: () => handleShareTask(task), onUnshare: () => handleUnshareTask(task), onCancelEdit: handleCancelEdit, onSaveEdit: handleSubmitEdit, onEditFormChange: setEditTaskForm, runningTimeLabel, isRunning: isRunningTask }) }, typedTask._id);
      }) })
    ] }) }) }),
    collaborationProject && /* @__PURE__ */ jsx11(ProjectCollaboratorsModal, { open: Boolean(collaborationProject), onOpenChange: (open) => {
      if (!open) {
        setCollaborationProject(null);
      }
    }, projectId: collaborationProject._id, projectName: collaborationProject.name, isOwner: collaborationProject.userRole === "owner", ownerEmail: collaborationProject.userRole === "owner" ? session.user.email ?? void 0 : void 0, ownerName: collaborationProject.userRole === "owner" ? session.user.name ?? session.user.email ?? "You" : "Project Owner" }),
    /* @__PURE__ */ jsx11(AddProjectModal, { open: isModalOpen, onOpenChange: setIsModalOpen }),
    /* @__PURE__ */ jsx11(AddTaskModal, { open: isAddTaskModalOpen, onOpenChange: setIsAddTaskModalOpen }),
    /* @__PURE__ */ jsx11(ImageAnalyticsModal, { isOpen: isImageAnalyticsOpen, onClose: () => setIsImageAnalyticsOpen(false), projectId: selectedProject?._id ?? void 0, projectName: selectedProject?.name, onBeginSession: handleBeginImageAnalysisSession }),
    /* @__PURE__ */ jsx11(ImageAnalysisSessionModal, { open: imageAnalysisSession !== null, onClose: closeImageAnalysisSession, imageDataUrl: imageAnalysisSession?.imageDataUrl ?? "", context: imageAnalysisSession?.context, defaultPriority: imageAnalysisSession?.defaultPriority ?? "medium", defaultHours: imageAnalysisSession?.defaultHours ?? 1, projectId: imageAnalysisSession?.projectId, projectName: imageAnalysisSession?.projectName, onTasksCreated: handleImageAnalysisTasksCreated }),
    editingProject && /* @__PURE__ */ jsx11(EditProjectModal, { open: isEditModalOpen, onOpenChange: setIsEditModalOpen, project: editingProject })
  ] }) });
}
function ProjectCollaborationPanel({
  projectId,
  projectName,
  ownerEmail,
  ownerName,
  isOwner
}) {
  const queryClient = useQueryClient2();
  const removeCollaborator = useConvexMutation3(api.projects.removeProjectCollaborator);
  const collaboratorsResponse = useConvexQuery3(api.projects.getProjectCollaborators, {
    projectId
  });
  const collaborators = useMemo4(() => (collaboratorsResponse?.collaborators || []).sort((a, b) => (a.addedAt ?? 0) - (b.addedAt ?? 0)), [collaboratorsResponse]);
  const displayOwnerName = ownerName || "Project Owner";
  const displayOwnerEmail = ownerEmail || "Email hidden";
  const refresh = () => {
    queryClient.invalidateQueries({
      predicate: (query2) => {
        const key = query2.queryKey;
        if (!Array.isArray(key)) return false;
        return key[0] === api.projects.getProjectCollaborators || key[0] === api.projects.listProjectInvitations || key[0] === api.projects.listProjects;
      }
    });
  };
  const handleRemoveCollaborator = async (record) => {
    if (!isOwner) return;
    const displayName = record.userName || record.email;
    const confirmed = window.confirm(`Remove ${displayName} from this project?`);
    if (!confirmed) return;
    try {
      await removeCollaborator({
        projectId,
        collaboratorId: record._id
      });
      toast3.success(`${displayName} removed`);
      refresh();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to remove collaborator.";
      toast3.error(message);
    }
  };
  return /* @__PURE__ */ jsxs9(Card, { children: [
    /* @__PURE__ */ jsx11(CardHeader, { children: /* @__PURE__ */ jsxs9(CardTitle, { className: "text-lg font-semibold flex items-center gap-2", children: [
      /* @__PURE__ */ jsx11(Users3, { className: "h-4 w-4" }),
      "Collaborators"
    ] }) }),
    /* @__PURE__ */ jsxs9(CardContent, { className: "space-y-6", children: [
      /* @__PURE__ */ jsxs9("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx11("p", { className: "text-sm font-medium text-slate-900 dark:text-slate-100", children: projectName }),
        /* @__PURE__ */ jsxs9("div", { className: "flex items-center justify-between rounded-md border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-3", children: [
          /* @__PURE__ */ jsxs9("div", { children: [
            /* @__PURE__ */ jsx11("p", { className: "text-sm font-semibold text-slate-800 dark:text-slate-100", children: displayOwnerName }),
            /* @__PURE__ */ jsx11("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: displayOwnerEmail })
          ] }),
          /* @__PURE__ */ jsx11(Badge, { children: "Owner" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs9("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx11("h3", { className: "text-sm font-semibold text-slate-900 dark:text-slate-100", children: "Team members" }),
        collaborators.length === 0 ? /* @__PURE__ */ jsx11("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: "No collaborators have joined this project yet." }) : /* @__PURE__ */ jsx11("div", { className: "space-y-2", children: collaborators.map((collaborator) => /* @__PURE__ */ jsxs9("div", { className: "flex items-center justify-between rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-3", children: [
          /* @__PURE__ */ jsxs9("div", { children: [
            /* @__PURE__ */ jsx11("p", { className: "text-sm font-medium text-slate-900 dark:text-slate-100", children: collaborator.userName || collaborator.email }),
            /* @__PURE__ */ jsxs9("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: [
              collaborator.email,
              collaborator.addedAt && /* @__PURE__ */ jsxs9(Fragment4, { children: [
                " \xB7 joined ",
                new Date(collaborator.addedAt).toLocaleString()
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsx11(Badge, { variant: "secondary", className: "uppercase", children: collaborator.role }),
          isOwner && collaborator.role !== "owner" && /* @__PURE__ */ jsxs9(Button, { variant: "outline", size: "sm", className: "ml-3 border-red-200 text-red-600 hover:bg-red-50 dark:border-red-900 dark:text-red-300 dark:hover:bg-red-900/20", onClick: () => handleRemoveCollaborator(collaborator), children: [
            /* @__PURE__ */ jsx11(Trash22, { className: "mr-2 h-4 w-4" }),
            "Remove"
          ] })
        ] }, collaborator._id)) })
      ] }),
      isOwner && /* @__PURE__ */ jsx11(OwnerInvitationSection, { projectId, projectName, onRefresh: refresh })
    ] })
  ] });
}
function ProjectCollaboratorsModal({
  open,
  onOpenChange,
  ...panelProps
}) {
  return /* @__PURE__ */ jsx11(Dialog, { open, onOpenChange, children: /* @__PURE__ */ jsxs9(DialogContent, { className: "max-w-3xl max-h-[90vh] overflow-y-auto bg-white dark:bg-slate-800 border-gray-200 dark:border-slate-700", children: [
    /* @__PURE__ */ jsx11(DialogHeader, { children: /* @__PURE__ */ jsxs9(DialogTitle, { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ jsx11(Sparkles, { className: "h-5 w-5 text-gray-600 dark:text-gray-400" }),
      "Project Collaboration"
    ] }) }),
    /* @__PURE__ */ jsx11(ProjectCollaborationPanel, { ...panelProps })
  ] }) });
}
function OwnerInvitationSection({
  projectId,
  projectName,
  onRefresh
}) {
  const [email, setEmail] = useState5("");
  const [isSubmitting, setIsSubmitting] = useState5(false);
  useQueryClient2();
  const inviteCollaborator = useConvexAction(api.projects.inviteProjectCollaborator);
  const invitations = useConvexQuery3(api.projects.listProjectInvitations, {
    projectId
  });
  const pendingInvitations = useMemo4(() => (invitations || []).filter((invitation) => invitation.status === "pending"), [invitations]);
  const respondedInvitations = useMemo4(() => (invitations || []).filter((invitation) => invitation.status !== "pending"), [invitations]);
  const handleSubmit = async (event) => {
    event.preventDefault();
    const normalizedEmail = email.trim().toLowerCase();
    if (!normalizedEmail) {
      toast3.error("Please enter an email address.");
      return;
    }
    try {
      setIsSubmitting(true);
      await inviteCollaborator({
        projectId,
        email: normalizedEmail,
        role: "collaborator"
      });
      toast3.success(`Invitation sent to ${normalizedEmail}`);
      setEmail("");
      onRefresh();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to send invitation.";
      toast3.error(message);
    } finally {
      setIsSubmitting(false);
    }
  };
  return /* @__PURE__ */ jsxs9("div", { className: "space-y-4 border-t border-slate-200 dark:border-slate-700 pt-6", children: [
    /* @__PURE__ */ jsxs9("div", { children: [
      /* @__PURE__ */ jsx11("h3", { className: "text-sm font-semibold text-slate-900 dark:text-slate-100", children: "Invite collaborators" }),
      /* @__PURE__ */ jsxs9("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: [
        "Send an email invitation to add someone to ",
        /* @__PURE__ */ jsx11("strong", { children: projectName }),
        "."
      ] })
    ] }),
    /* @__PURE__ */ jsxs9("form", { onSubmit: handleSubmit, className: "flex flex-col gap-3 sm:flex-row sm:items-start", children: [
      /* @__PURE__ */ jsx11(Input, { type: "email", placeholder: "name@example.com", value: email, onChange: (event) => setEmail(event.target.value), className: "sm:flex-1" }),
      /* @__PURE__ */ jsx11(Button, { type: "submit", disabled: isSubmitting, className: "bg-black text-white hover:bg-gray-800 dark:bg-white dark:text-black dark:hover:bg-gray-200", children: isSubmitting ? "Sending..." : "Send invite" })
    ] }),
    pendingInvitations.length > 0 && /* @__PURE__ */ jsxs9("div", { className: "space-y-2", children: [
      /* @__PURE__ */ jsx11("h4", { className: "text-xs font-semibold uppercase text-slate-500 dark:text-slate-400 tracking-wide", children: "Pending" }),
      /* @__PURE__ */ jsx11("div", { className: "space-y-2", children: pendingInvitations.map((invitation) => /* @__PURE__ */ jsxs9("div", { className: "flex items-center justify-between rounded-md border border-dashed border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 p-3", children: [
        /* @__PURE__ */ jsxs9("div", { children: [
          /* @__PURE__ */ jsx11("p", { className: "text-sm font-medium text-slate-800 dark:text-slate-100", children: invitation.email }),
          /* @__PURE__ */ jsxs9("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: [
            "Invited ",
            new Date(invitation.invitedAt).toLocaleString()
          ] })
        ] }),
        /* @__PURE__ */ jsx11(Badge, { variant: "secondary", className: "uppercase", children: invitation.role })
      ] }, invitation._id)) })
    ] }),
    respondedInvitations.length > 0 && /* @__PURE__ */ jsxs9("div", { className: "space-y-2 border-t border-slate-200 dark:border-slate-700 pt-4", children: [
      /* @__PURE__ */ jsx11("h4", { className: "text-xs font-semibold uppercase text-slate-500 dark:text-slate-400 tracking-wide", children: "Recent responses" }),
      /* @__PURE__ */ jsx11("div", { className: "space-y-2", children: respondedInvitations.sort((a, b) => (b.respondedAt ?? 0) - (a.respondedAt ?? 0)).slice(0, 4).map((invitation) => /* @__PURE__ */ jsxs9("div", { className: "flex items-center justify-between rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-3", children: [
        /* @__PURE__ */ jsxs9("div", { children: [
          /* @__PURE__ */ jsx11("p", { className: "text-sm font-medium text-slate-800 dark:text-slate-100", children: invitation.email }),
          /* @__PURE__ */ jsxs9("p", { className: "text-xs text-slate-500 dark:text-slate-400", children: [
            invitation.status === "accepted" ? "Accepted" : invitation.status === "declined" ? "Declined" : invitation.status,
            invitation.respondedAt && /* @__PURE__ */ jsxs9(Fragment4, { children: [
              " \xB7 ",
              new Date(invitation.respondedAt).toLocaleString()
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsx11(Badge, { variant: invitation.status === "accepted" ? "default" : "secondary", children: invitation.status })
      ] }, invitation._id)) })
    ] })
  ] });
}
var statusOptions$1, validateProjectName$1, validateGithubUrl$1, statusOptions, validateProjectName, validateGithubUrl, DEFAULT_MAX_SIZE_MB, DEFAULT_ACCEPTED, ExtractedTaskSchema, ImageAnalysisResultSchema, DEFAULT_ANALYSIS_PRIORITY, Progress, PRIORITY_COLOR, PRIORITY_OPTIONS2, STATUS_OPTIONS2, getProjectStatusLabel$1, formatNumber$1, getProjectIcon, getProjectTypeLabel, getProjectStatusLabel, getProjectStatusColor, formatNumber, DEFAULT_SIZE, DEFAULT_MAGNIFICATION, DEFAULT_DISTANCE, DEFAULT_DISABLEMAGNIFICATION, dockVariants, Dock, DockIcon, AddTaskIcon;
var init_project_jEc4sHYE = __esm({
  "dist/server/assets/project-jEc4sHYE.js"() {
    "use strict";
    init_api_DiONElen();
    init_router_BrR6fF9p();
    init_app_header_DDCic_DU();
    init_select_CNs7Rl3z();
    init_task_card_CGreDeOa();
    init_checkbox_7uLehv8l();
    statusOptions$1 = [
      "planning",
      "development",
      "alpha",
      "beta",
      "official-release"
    ];
    validateProjectName$1 = (value) => {
      if (!value.trim()) {
        return "Project name is required";
      }
      return void 0;
    };
    validateGithubUrl$1 = (value) => {
      const trimmed = value.trim();
      if (!trimmed) {
        return void 0;
      }
      try {
        const parsed = new URL(trimmed);
        if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
          return "Enter a valid URL";
        }
        return void 0;
      } catch {
        return "Enter a valid URL";
      }
    };
    statusOptions = [
      "planning",
      "development",
      "alpha",
      "beta",
      "official-release"
    ];
    validateProjectName = (value) => {
      if (!value.trim()) {
        return "Project name is required";
      }
      return void 0;
    };
    validateGithubUrl = (value) => {
      const trimmed = value.trim();
      if (!trimmed) {
        return void 0;
      }
      try {
        const parsed = new URL(trimmed);
        if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
          return "Enter a valid URL";
        }
        return void 0;
      } catch {
        return "Enter a valid URL";
      }
    };
    DEFAULT_MAX_SIZE_MB = 10;
    DEFAULT_ACCEPTED = ["image/png", "image/jpeg", "image/webp"];
    ExtractedTaskSchema = z.object({
      id: z.string(),
      title: z.string(),
      description: z.string().optional(),
      notes: z.string().optional(),
      priority: z.enum(["low", "medium", "high"]).default("medium"),
      estimatedHours: z.number().nonnegative().optional()
    });
    ImageAnalysisResultSchema = z.object({
      summary: z.string().default(""),
      totalEstimatedHours: z.number().nonnegative().optional(),
      confidence: z.number().min(0).max(1).optional(),
      tasks: z.array(ExtractedTaskSchema).default([])
    });
    DEFAULT_ANALYSIS_PRIORITY = "medium";
    Progress = React3.forwardRef(({ className, value = 0, ...props }, ref) => {
      return /* @__PURE__ */ jsx11(
        "div",
        {
          ref,
          className: cn(
            "relative h-2 w-full overflow-hidden rounded-full bg-gray-200 dark:bg-gray-700",
            className
          ),
          ...props,
          children: /* @__PURE__ */ jsx11(
            "div",
            {
              className: "h-full w-full flex-1 bg-primary transition-all",
              style: { transform: `translateX(-${100 - (value || 0)}%)` }
            }
          )
        }
      );
    });
    Progress.displayName = "Progress";
    PRIORITY_COLOR = {
      low: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-200",
      medium: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-200",
      high: "bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-200"
    };
    PRIORITY_OPTIONS2 = [
      { value: "low", label: "Low" },
      { value: "medium", label: "Medium" },
      { value: "high", label: "High" }
    ];
    STATUS_OPTIONS2 = [
      { value: "todo", label: "To do" },
      { value: "in-progress", label: "In progress" },
      { value: "done", label: "Done" }
    ];
    getProjectStatusLabel$1 = (status) => {
      const labels = {
        planning: "Planning",
        development: "Development",
        alpha: "Alpha",
        beta: "Beta",
        "official-release": "Official Release"
      };
      return labels[status] || status;
    };
    formatNumber$1 = (num) => {
      if (num >= 1e6) return `${(num / 1e6).toFixed(1)}M`;
      if (num >= 1e3) return `${(num / 1e3).toFixed(1)}K`;
      return num.toString();
    };
    getProjectIcon = (type) => {
      const iconMap = {
        web: /* @__PURE__ */ jsx11(Globe, { className: "h-6 w-6" }),
        mobile: /* @__PURE__ */ jsx11(Smartphone, { className: "h-6 w-6" }),
        desktop: /* @__PURE__ */ jsx11(Monitor, { className: "h-6 w-6" }),
        saas: /* @__PURE__ */ jsx11(Database, { className: "h-6 w-6" }),
        library: /* @__PURE__ */ jsx11(Book, { className: "h-6 w-6" }),
        tool: /* @__PURE__ */ jsx11(Wrench, { className: "h-6 w-6" }),
        blog: /* @__PURE__ */ jsx11(Package, { className: "h-6 w-6" }),
        course: /* @__PURE__ */ jsx11(Book, { className: "h-6 w-6" }),
        "open-source": /* @__PURE__ */ jsx11(Github2, { className: "h-6 w-6" }),
        other: /* @__PURE__ */ jsx11(Package, { className: "h-6 w-6" })
      };
      if (!type) return /* @__PURE__ */ jsx11(Package, { className: "h-6 w-6" });
      return iconMap[type] || /* @__PURE__ */ jsx11(Package, { className: "h-6 w-6" });
    };
    getProjectTypeLabel = (type) => {
      const labels = {
        saas: "SaaS Application",
        mobile: "Mobile App",
        web: "Web Application",
        desktop: "Desktop App",
        "open-source": "Open Source",
        library: "Library/Framework",
        tool: "Developer Tool",
        blog: "Blog/Website",
        course: "Course/Education",
        other: "Other"
      };
      if (!type) return "Project";
      return labels[type] || type;
    };
    getProjectStatusLabel = (status) => {
      const labels = {
        planning: "Planning",
        development: "Development",
        alpha: "Alpha",
        beta: "Beta",
        "official-release": "Official Release"
      };
      return labels[status] || status;
    };
    getProjectStatusColor = (status) => {
      const colors = {
        planning: "bg-slate-100 text-slate-700 dark:bg-slate-700/50 dark:text-slate-300",
        development: "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300",
        alpha: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
        beta: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300",
        "official-release": "bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300"
      };
      return colors[status] || colors.planning;
    };
    formatNumber = (num) => {
      if (num >= 1e6) return `${(num / 1e6).toFixed(1)}M`;
      if (num >= 1e3) return `${(num / 1e3).toFixed(1)}K`;
      return num.toString();
    };
    DEFAULT_SIZE = 40;
    DEFAULT_MAGNIFICATION = 60;
    DEFAULT_DISTANCE = 140;
    DEFAULT_DISABLEMAGNIFICATION = false;
    dockVariants = cva3(
      "supports-backdrop-blur:bg-white/10 supports-backdrop-blur:dark:bg-black/10 mx-auto mt-8 flex h-[58px] w-max items-center justify-center gap-2 rounded-2xl border p-2 backdrop-blur-md"
    );
    Dock = React__default.forwardRef(
      ({
        className,
        children,
        iconSize = DEFAULT_SIZE,
        iconMagnification = DEFAULT_MAGNIFICATION,
        disableMagnification = DEFAULT_DISABLEMAGNIFICATION,
        iconDistance = DEFAULT_DISTANCE,
        direction = "middle",
        ...props
      }, ref) => {
        const mouseX = useMotionValue(Infinity);
        const renderChildren = () => {
          return React__default.Children.map(children, (child) => {
            if (React__default.isValidElement(child) && child.type === DockIcon) {
              return React__default.cloneElement(child, {
                ...child.props,
                mouseX,
                size: iconSize,
                magnification: iconMagnification,
                disableMagnification,
                distance: iconDistance
              });
            }
            return child;
          });
        };
        return /* @__PURE__ */ jsx11(
          motion2.div,
          {
            ref,
            onMouseMove: (e) => mouseX.set(e.pageX),
            onMouseLeave: () => mouseX.set(Infinity),
            ...props,
            className: cn(dockVariants({ className }), {
              "items-start": direction === "top",
              "items-center": direction === "middle",
              "items-end": direction === "bottom"
            }),
            children: renderChildren()
          }
        );
      }
    );
    Dock.displayName = "Dock";
    DockIcon = ({
      size = DEFAULT_SIZE,
      magnification = DEFAULT_MAGNIFICATION,
      disableMagnification,
      distance = DEFAULT_DISTANCE,
      mouseX,
      className,
      children,
      ...props
    }) => {
      const ref = useRef3(null);
      const padding = Math.max(6, size * 0.2);
      const defaultMouseX = useMotionValue(Infinity);
      const distanceCalc = useTransform(mouseX ?? defaultMouseX, (val) => {
        const bounds = ref.current?.getBoundingClientRect() ?? { x: 0, width: 0 };
        return val - bounds.x - bounds.width / 2;
      });
      const targetSize = disableMagnification ? size : magnification;
      const sizeTransform = useTransform(
        distanceCalc,
        [-distance, 0, distance],
        [size, targetSize, size]
      );
      const scaleSize = useSpring(sizeTransform, {
        mass: 0.1,
        stiffness: 150,
        damping: 12
      });
      return /* @__PURE__ */ jsx11(
        motion2.div,
        {
          ref,
          style: { width: scaleSize, height: scaleSize, padding },
          className: cn(
            "flex aspect-square cursor-pointer items-center justify-center rounded-full",
            disableMagnification && "transition-colors hover:bg-muted-foreground",
            className
          ),
          ...props,
          children: /* @__PURE__ */ jsx11("div", { children })
        }
      );
    };
    DockIcon.displayName = "DockIcon";
    AddTaskIcon = (props) => /* @__PURE__ */ jsx11("svg", { ...props, fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsx11("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M12 6v6m0 0v6m0-6h6m-6 0H6" }) });
  }
});

// dist/server/assets/live-DxNKWXXM.js
var live_DxNKWXXM_exports = {};
__export(live_DxNKWXXM_exports, {
  component: () => RouteComponent5
});
import { jsxs as jsxs10, jsx as jsx12 } from "react/jsx-runtime";
import { useConvexQuery as useConvexQuery4, useConvexMutation as useConvexMutation4 } from "@convex-dev/react-query";
import { useQueryClient as useQueryClient3 } from "@tanstack/react-query";
import { useState as useState6, useEffect as useEffect8, useMemo as useMemo5, Fragment as Fragment5 } from "react";
import { toast as toast4 } from "sonner";
import { CheckSquare as CheckSquare3, Play as Play2, CheckCircle2 as CheckCircle23, Circle as Circle2, FolderOpen as FolderOpen2, Search, Square, CheckCircle } from "lucide-react";
import "convex/server";
import "@tanstack/react-router";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core";
import "@tanstack/router-core/ssr/server";
import "h3-v2";
import "tiny-invariant";
import "seroval";
import "@tanstack/react-router/ssr/server";
import "@convex-dev/better-auth/react";
import "@convex-dev/better-auth/react-start";
import "clsx";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@tanstack/react-router-with-query";
import "convex/react";
import "tailwind-merge";
import "better-auth/react";
import "@convex-dev/better-auth/client/plugins";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "@radix-ui/react-dialog";
import "@radix-ui/react-visually-hidden";
import "@radix-ui/react-select";
import "@radix-ui/react-checkbox";
function RouteComponent5() {
  const session = useSession2();
  const queryClient = useQueryClient3();
  const [searchQuery, setSearchQuery] = useState6("");
  const [projectFilter, setProjectFilter] = useState6("all");
  const [priorityFilter, setPriorityFilter] = useState6("all");
  const [sessionActive, setSessionActive] = useState6(false);
  const [now, setNow] = useState6(() => Date.now());
  useEffect8(() => {
    const interval = window.setInterval(() => setNow(Date.now()), 6e4);
    return () => window.clearInterval(interval);
  }, []);
  const tasks = useConvexQuery4(api.tasks.listTasks, {});
  const projects = useConvexQuery4(api.projects.listProjects, {});
  const allCollaborators = useConvexQuery4(api.projects.getAllCollaborators, {});
  const emailToNameMap = useMemo5(() => {
    const map = /* @__PURE__ */ new Map();
    if (!allCollaborators) return map;
    allCollaborators.forEach((collaborator) => {
      const email = collaborator.email.toLowerCase().trim();
      if (collaborator.userName) {
        map.set(email, collaborator.userName);
      }
    });
    return map;
  }, [allCollaborators]);
  const getDisplayName = (email) => {
    const normalizedEmail = email.toLowerCase().trim();
    return emailToNameMap.get(normalizedEmail) || email;
  };
  const toggleTaskSelectionMutation = useConvexMutation4(api.tasks.toggleTaskSelection);
  const startTaskMutation = useConvexMutation4(api.tasks.startTask);
  const stopTaskMutation = useConvexMutation4(api.tasks.stopTask);
  const completeTaskMutation = useConvexMutation4(api.tasks.completeTask);
  const userProjectIds = useMemo5(() => {
    const ownedOrShared = /* @__PURE__ */ new Set();
    if (!projects) return ownedOrShared;
    projects.forEach((project) => {
      ownedOrShared.add(String(project._id));
    });
    return ownedOrShared;
  }, [projects]);
  const tasksWithProjects = useMemo5(() => {
    const userId = session?.user?.id;
    const email = session?.user?.email;
    return (tasks ?? []).filter((task) => {
      const projectId = task.projectId ? String(task.projectId) : void 0;
      if (!projectId || !userProjectIds.has(projectId)) return false;
      if (task.userId === userId) return true;
      if (!email) return false;
      try {
        if (task.sharedWith) {
          const sharedEmails = JSON.parse(task.sharedWith);
          if (Array.isArray(sharedEmails) && sharedEmails.includes(email)) {
            return true;
          }
        }
      } catch {
      }
      return false;
    });
  }, [tasks, session?.user?.id, session?.user?.email, userProjectIds]);
  const projectNameMap = useMemo5(() => {
    const map = /* @__PURE__ */ new Map();
    (projects ?? []).forEach((project) => {
      const docId = project._id ? String(project._id) : void 0;
      const customId = project.id ? String(project.id) : void 0;
      const name = project.name || customId || "Untitled Project";
      if (docId) {
        map.set(docId, name);
      }
      if (customId) {
        map.set(customId, name);
      }
    });
    (tasks ?? []).forEach((task) => {
      if (task.project) {
        const docId = task.project._id ? String(task.project._id) : void 0;
        const customId = task.project.id ? String(task.project.id) : void 0;
        const name = task.project.name || customId || "Shared Project";
        if (docId) {
          map.set(docId, name);
        }
        if (customId) {
          map.set(customId, name);
        }
      }
    });
    return map;
  }, [projects, tasks]);
  const getProjectName = (task) => {
    if (!task.projectId) {
      return "No Project";
    }
    const key = String(task.projectId);
    const directMatch = projectNameMap.get(key);
    if (directMatch) {
      return directMatch;
    }
    if (task.project?.name) {
      return task.project.name;
    }
    return "Unknown Project";
  };
  const projectOptions = useMemo5(() => {
    const names = /* @__PURE__ */ new Set();
    tasksWithProjects.forEach((task) => {
      const name = getProjectName(task);
      if (name && name !== "Unknown Project" && name !== "No Project") {
        names.add(name);
      }
    });
    return Array.from(names).sort((a, b) => a.localeCompare(b));
  }, [tasksWithProjects, projectNameMap]);
  const filteredTableTasks = useMemo5(() => {
    const query2 = searchQuery.trim().toLowerCase();
    return tasksWithProjects.filter((task) => {
      const statusNormalized = (task.status || "").toLowerCase();
      if (statusNormalized === "done" || statusNormalized === "completed") {
        return false;
      }
      const projectName = getProjectName(task);
      if (projectFilter !== "all" && projectName !== projectFilter) {
        return false;
      }
      if (priorityFilter !== "all") {
        const priority = normalizePriority(task.priority);
        if (priority !== priorityFilter) {
          return false;
        }
      }
      if (!query2) {
        return true;
      }
      const textMatch = task.text?.toLowerCase().includes(query2);
      const detailsMatch = task.details?.toLowerCase().includes(query2);
      const refMatch = task.refLink?.toLowerCase().includes(query2);
      return Boolean(textMatch || detailsMatch || refMatch);
    });
  }, [tasksWithProjects, searchQuery, projectFilter, priorityFilter]);
  const groupedTasks = useMemo5(() => {
    const groups = {};
    filteredTableTasks.forEach((task) => {
      const projectName = getProjectName(task);
      if (!groups[projectName]) {
        groups[projectName] = [];
      }
      groups[projectName].push(task);
    });
    return groups;
  }, [filteredTableTasks]);
  const sortedProjectNames = useMemo5(() => Object.keys(groupedTasks).sort((a, b) => a.localeCompare(b)), [groupedTasks]);
  const refetchTasks = async () => {
    await queryClient.invalidateQueries({
      predicate: (query2) => {
        const key = query2.queryKey;
        return Array.isArray(key) && key[0] === api.tasks.listTasks;
      }
    });
  };
  const getSelectedByToday = (task) => {
    if (!task.selectedBy) return [];
    try {
      const selectedBy = JSON.parse(task.selectedBy);
      const today = /* @__PURE__ */ new Date();
      today.setHours(0, 0, 0, 0);
      const todayTimestamp = today.getTime();
      const todaySelections = [];
      if (typeof selectedBy === "object" && selectedBy !== null && !Array.isArray(selectedBy)) {
        for (const [email, timestamp] of Object.entries(selectedBy)) {
          if (typeof timestamp === "number") {
            const selectedDate = new Date(timestamp);
            selectedDate.setHours(0, 0, 0, 0);
            const selectedTimestamp = selectedDate.getTime();
            if (selectedTimestamp === todayTimestamp) {
              todaySelections.push({
                email,
                timestamp
              });
            }
          }
        }
      }
      return todaySelections;
    } catch (error) {
      console.error("Error parsing selectedBy:", error, task.selectedBy);
      return [];
    }
  };
  const isTaskSelectedByMeToday = (task) => {
    if (!session?.user?.email) return false;
    const selections = getSelectedByToday(task);
    return selections.some((s) => s.email === session.user.email);
  };
  const isTaskSelectedToday = (task) => {
    return getSelectedByToday(task).length > 0;
  };
  const isTaskRunningForMe = (task) => {
    const statusNormalized = (task.status || "").toLowerCase();
    if (statusNormalized !== "in-progress") {
      return false;
    }
    const isOwner = task.userId === session?.user?.id;
    if (isOwner) {
      return true;
    }
    return isTaskSelectedByMeToday(task);
  };
  const isTaskActiveForMe = (task) => {
    return isTaskSelectedByMeToday(task) || isTaskRunningForMe(task);
  };
  const getSharedEmails = (sharedWith) => {
    if (!sharedWith) return [];
    try {
      const emails = JSON.parse(sharedWith);
      return Array.isArray(emails) ? emails : [];
    } catch {
      return [];
    }
  };
  const activeTasks = useMemo5(() => {
    return tasksWithProjects.filter((task) => {
      const statusNormalized = (task.status || "").toLowerCase();
      return statusNormalized !== "done" && statusNormalized !== "completed";
    });
  }, [tasksWithProjects]);
  const activeOverallCount = useMemo5(() => {
    return activeTasks.filter((task) => {
      const statusNormalized = (task.status || "").toLowerCase();
      if (statusNormalized === "in-progress") {
        return true;
      }
      return isTaskSelectedToday(task);
    }).length;
  }, [activeTasks]);
  const selectedByMeCount = useMemo5(() => {
    return activeTasks.filter((task) => isTaskActiveForMe(task)).length;
  }, [activeTasks]);
  const availableCount = activeTasks.length - activeOverallCount;
  const handleToggleSelection = async (task) => {
    if (!session?.user?.email) {
      console.error("Cannot toggle selection: user email not found in session");
      return;
    }
    const normalizedStatus = (task.status || "").toLowerCase();
    if (normalizedStatus === "in progress" || normalizedStatus === "in-progress" || normalizedStatus === "running") {
      toast4.info("Stop the task before changing its selection.");
      return;
    }
    const isSelectedByToday = getSelectedByToday(task);
    const isSelectedByCurrentUser = isTaskSelectedByMeToday(task);
    const isSelectedBySomeoneElse = isSelectedByToday.length > 0 && !isSelectedByCurrentUser;
    if (isSelectedBySomeoneElse) {
      toast4.info("This task is already selected for today by another teammate.");
      return;
    }
    const isSelected = isSelectedByCurrentUser;
    try {
      await toggleTaskSelectionMutation({
        taskId: task._id,
        selected: !isSelected
      });
      await queryClient.invalidateQueries({
        predicate: (query2) => {
          const key = query2.queryKey;
          return Array.isArray(key) && key[0] === api.tasks.listTasks;
        }
      });
    } catch (error) {
      console.error("Failed to toggle task selection:", error);
      const errorMessage = error instanceof Error ? error.message : String(error);
      toast4.error(`Failed to toggle selection: ${errorMessage}`);
    }
  };
  const handleStartTaskRun = async (task) => {
    try {
      await startTaskMutation({
        taskId: task._id
      });
      await refetchTasks();
      setSessionActive(true);
      toast4.success(`Started "${task.text}"`);
    } catch (error) {
      console.error("Failed to start task:", error);
      const errorMessage = error instanceof Error ? error.message : String(error);
      toast4.error(`Unable to start task: ${errorMessage}`);
    }
  };
  const handleStopTaskRun = async (task) => {
    try {
      await stopTaskMutation({
        taskId: task._id
      });
      await refetchTasks();
      toast4.success(`Stopped "${task.text}"`);
    } catch (error) {
      console.error("Failed to stop task:", error);
      const errorMessage = error instanceof Error ? error.message : String(error);
      toast4.error(`Unable to stop task: ${errorMessage}`);
    }
  };
  const handleCompleteTaskRun = async (task) => {
    try {
      await completeTaskMutation({
        taskId: task._id
      });
      await refetchTasks();
      toast4.success(`Completed "${task.text}"`);
    } catch (error) {
      console.error("Failed to complete task:", error);
      const errorMessage = error instanceof Error ? error.message : String(error);
      toast4.error(`Unable to complete task: ${errorMessage}`);
    }
  };
  const computeTrackedTime = (task) => {
    const base = task.trackedTimeMs ?? 0;
    const active = task.startedAt && task.status === "in-progress" ? Math.max(0, now - task.startedAt) : 0;
    return base + active;
  };
  const mySelectedTasks = useMemo5(() => activeTasks.filter((task) => isTaskActiveForMe(task)), [activeTasks, session?.user?.id, session?.user?.email]);
  const hasRunningTasks = useMemo5(() => {
    return activeTasks.some((task) => {
      const statusNormalized = (task.status || "").toLowerCase();
      if (statusNormalized !== "in-progress") {
        return false;
      }
      const isOwnedByMe = task.userId === session?.user?.id;
      const wasSelectedByMeToday = isTaskSelectedByMeToday(task);
      return isOwnedByMe || wasSelectedByMeToday;
    });
  }, [activeTasks, session?.user?.id, session?.user?.email]);
  const shouldResumeSession = useMemo5(() => {
    if (mySelectedTasks.length > 0) {
      return true;
    }
    return hasRunningTasks;
  }, [hasRunningTasks, mySelectedTasks.length]);
  useEffect8(() => {
    if (!sessionActive && shouldResumeSession) {
      setSessionActive(true);
    }
  }, [sessionActive, shouldResumeSession]);
  useEffect8(() => {
    if (sessionActive && !shouldResumeSession) {
      setSessionActive(false);
    }
  }, [sessionActive, shouldResumeSession]);
  return /* @__PURE__ */ jsxs10("main", { className: "mx-auto flex w-full max-w-6xl flex-col gap-8 px-6 py-10", children: [
    /* @__PURE__ */ jsxs10("section", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxs10("div", { children: [
        /* @__PURE__ */ jsx12("h1", { className: "text-3xl font-bold tracking-tight text-zinc-900 dark:text-zinc-50 mb-6", children: "Task Workflow" }),
        /* @__PURE__ */ jsxs10("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxs10("div", { className: "flex items-start gap-2", children: [
            /* @__PURE__ */ jsx12(CheckSquare3, { className: "h-5 w-5 mt-0.5 text-blue-600 dark:text-blue-400 flex-shrink-0" }),
            /* @__PURE__ */ jsxs10("p", { className: "text-base font-semibold leading-relaxed text-blue-700 dark:text-blue-300", children: [
              "Select one or more tasks from ",
              /* @__PURE__ */ jsx12("span", { className: "font-bold text-blue-800 dark:text-blue-200", children: "Task List" }),
              " section."
            ] })
          ] }),
          /* @__PURE__ */ jsxs10("div", { className: "flex items-start gap-2", children: [
            /* @__PURE__ */ jsx12(Play2, { className: "h-5 w-5 mt-0.5 text-emerald-600 dark:text-emerald-400 flex-shrink-0" }),
            /* @__PURE__ */ jsxs10("p", { className: "text-base font-semibold leading-relaxed text-emerald-700 dark:text-emerald-300", children: [
              "Start running tasks from ",
              /* @__PURE__ */ jsx12("span", { className: "font-bold text-emerald-800 dark:text-emerald-200", children: "Live Run" }),
              " section."
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs10("div", { className: "flex flex-wrap items-center gap-3 pt-2", children: [
        /* @__PURE__ */ jsxs10("span", { className: "inline-flex items-center gap-2 rounded-xl bg-emerald-100 px-4 py-2 text-sm font-semibold text-emerald-700 shadow-sm transition-all hover:shadow-md dark:bg-emerald-900/40 dark:text-emerald-300", children: [
          /* @__PURE__ */ jsx12(CheckCircle23, { className: "h-4 w-4" }),
          selectedByMeCount,
          " selected by you"
        ] }),
        /* @__PURE__ */ jsxs10("span", { className: "inline-flex items-center gap-2 rounded-xl bg-sky-100 px-4 py-2 text-sm font-semibold text-sky-700 shadow-sm transition-all hover:shadow-md dark:bg-sky-900/40 dark:text-sky-300", children: [
          /* @__PURE__ */ jsx12(Circle2, { className: "h-4 w-4" }),
          activeOverallCount,
          " engaged overall"
        ] }),
        /* @__PURE__ */ jsxs10("span", { className: "inline-flex items-center gap-2 rounded-xl bg-slate-100 px-4 py-2 text-sm font-semibold text-slate-700 shadow-sm transition-all hover:shadow-md dark:bg-slate-800 dark:text-slate-300", children: [
          availableCount,
          " available"
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs10(Card, { className: "border border-slate-200/80 shadow-xl shadow-blue-500/5 dark:border-slate-800 dark:shadow-blue-500/10", children: [
      /* @__PURE__ */ jsx12(CardHeader, { className: "border-b border-blue-100/80 bg-gradient-to-br from-white via-blue-50/30 to-white dark:border-blue-900/40 dark:from-slate-900 dark:via-blue-900/20 dark:to-slate-900", children: /* @__PURE__ */ jsx12("div", { className: "flex flex-wrap items-start justify-between gap-4", children: /* @__PURE__ */ jsxs10("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxs10(CardTitle, { className: "flex items-center gap-3 text-xl font-bold text-zinc-900 dark:text-zinc-50", children: [
          /* @__PURE__ */ jsx12("div", { className: "flex h-10 w-10 items-center justify-center rounded-xl bg-blue-100 dark:bg-blue-900/40", children: /* @__PURE__ */ jsx12(FolderOpen2, { className: "h-5 w-5 text-blue-600 dark:text-blue-400" }) }),
          "Task List"
        ] }),
        /* @__PURE__ */ jsxs10(CardDescription, { className: "text-sm text-blue-700 dark:text-blue-300 space-y-2", children: [
          /* @__PURE__ */ jsxs10("div", { className: "flex items-start gap-2", children: [
            /* @__PURE__ */ jsx12("span", { className: "mt-0.5 text-blue-500 dark:text-blue-400", children: "\u2022" }),
            /* @__PURE__ */ jsx12("span", { children: "Show all active tasks including shared tasks." })
          ] }),
          /* @__PURE__ */ jsxs10("div", { className: "flex items-start gap-2", children: [
            /* @__PURE__ */ jsx12("span", { className: "mt-0.5 text-blue-500 dark:text-blue-400", children: "\u2022" }),
            /* @__PURE__ */ jsx12("span", { children: "Selection updates sync in real-time across all team members." })
          ] })
        ] })
      ] }) }) }),
      /* @__PURE__ */ jsxs10(CardContent, { className: "space-y-6 p-6", children: [
        /* @__PURE__ */ jsxs10("div", { className: "grid gap-4 sm:grid-cols-3", children: [
          /* @__PURE__ */ jsxs10("div", { className: "relative sm:col-span-1", children: [
            /* @__PURE__ */ jsx12(Search, { className: "absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-400 dark:text-zinc-500" }),
            /* @__PURE__ */ jsx12(Input, { value: searchQuery, onChange: (event) => setSearchQuery(event.target.value), placeholder: "Search tasks...", className: "h-11 pl-10 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 transition-all focus:ring-2 focus:ring-blue-500" })
          ] }),
          /* @__PURE__ */ jsxs10(Select, { value: projectFilter, onValueChange: setProjectFilter, children: [
            /* @__PURE__ */ jsx12(SelectTrigger, { className: "h-11 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 transition-all focus:ring-2 focus:ring-blue-500", children: /* @__PURE__ */ jsx12(SelectValue, { placeholder: "Filter by project" }) }),
            /* @__PURE__ */ jsxs10(SelectContent, { className: "border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800", children: [
              /* @__PURE__ */ jsx12(SelectItem, { value: "all", children: "All projects" }),
              projectOptions.map((projectName) => /* @__PURE__ */ jsx12(SelectItem, { value: projectName, children: projectName }, projectName))
            ] })
          ] }),
          /* @__PURE__ */ jsxs10(Select, { value: priorityFilter, onValueChange: setPriorityFilter, children: [
            /* @__PURE__ */ jsx12(SelectTrigger, { className: "h-11 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 transition-all focus:ring-2 focus:ring-blue-500", children: /* @__PURE__ */ jsx12(SelectValue, { placeholder: "Filter by priority" }) }),
            /* @__PURE__ */ jsxs10(SelectContent, { className: "border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800", children: [
              /* @__PURE__ */ jsx12(SelectItem, { value: "all", children: "All priorities" }),
              /* @__PURE__ */ jsx12(SelectItem, { value: "high", children: "High" }),
              /* @__PURE__ */ jsx12(SelectItem, { value: "medium", children: "Medium" }),
              /* @__PURE__ */ jsx12(SelectItem, { value: "low", children: "Low" })
            ] })
          ] })
        ] }),
        (searchQuery || projectFilter !== "all" || priorityFilter !== "all") && /* @__PURE__ */ jsx12("div", { className: "flex justify-end", children: /* @__PURE__ */ jsx12(Button, { variant: "ghost", size: "sm", onClick: () => {
          setSearchQuery("");
          setProjectFilter("all");
          setPriorityFilter("all");
        }, className: "text-blue-600 hover:text-blue-800 dark:text-blue-300 dark:hover:text-blue-200", children: "Clear filters" }) }),
        /* @__PURE__ */ jsx12("div", { className: "overflow-hidden rounded-xl border border-blue-100/80 shadow-lg dark:border-blue-900/40", children: /* @__PURE__ */ jsx12("div", { className: "max-h-[480px] overflow-y-auto", children: /* @__PURE__ */ jsxs10("table", { className: "min-w-full border-collapse", children: [
          /* @__PURE__ */ jsx12("thead", { className: "sticky top-0 z-10 bg-blue-50/90 backdrop-blur-sm dark:bg-blue-900/50", children: /* @__PURE__ */ jsxs10("tr", { className: "text-left text-xs font-bold uppercase tracking-wider text-blue-700 dark:text-blue-200", children: [
            /* @__PURE__ */ jsx12("th", { className: "px-4 py-3", children: "Project" }),
            /* @__PURE__ */ jsx12("th", { className: "px-4 py-3", children: "Task" }),
            /* @__PURE__ */ jsx12("th", { className: "px-4 py-3", children: "Shared with" }),
            /* @__PURE__ */ jsx12("th", { className: "px-4 py-3", children: "Priority" }),
            /* @__PURE__ */ jsx12("th", { className: "px-4 py-3 text-center", children: "Select" })
          ] }) }),
          /* @__PURE__ */ jsx12("tbody", { className: "bg-white text-sm dark:bg-slate-900", children: filteredTableTasks.length === 0 ? /* @__PURE__ */ jsx12("tr", { children: /* @__PURE__ */ jsx12("td", { colSpan: 5, className: "px-4 py-16 text-center", children: /* @__PURE__ */ jsxs10("div", { className: "flex flex-col items-center gap-3", children: [
            /* @__PURE__ */ jsx12("div", { className: "flex h-16 w-16 items-center justify-center rounded-full bg-slate-100 dark:bg-slate-800", children: /* @__PURE__ */ jsx12(Search, { className: "h-8 w-8 text-slate-400 dark:text-slate-500" }) }),
            /* @__PURE__ */ jsxs10("div", { children: [
              /* @__PURE__ */ jsx12("p", { className: "text-sm font-semibold text-zinc-900 dark:text-zinc-100", children: "No tasks found" }),
              /* @__PURE__ */ jsx12("p", { className: "mt-1 text-xs text-zinc-500 dark:text-zinc-400", children: "Try adjusting your search or filters" })
            ] })
          ] }) }) }) : sortedProjectNames.map((projectName) => {
            const tasksForProject = groupedTasks[projectName] ?? [];
            if (!tasksForProject.length) {
              return null;
            }
            return /* @__PURE__ */ jsxs10(Fragment5, { children: [
              /* @__PURE__ */ jsx12("tr", { className: "bg-blue-100/80 text-xs font-bold uppercase tracking-wider text-blue-800 dark:bg-blue-900/40 dark:text-blue-200", children: /* @__PURE__ */ jsx12("td", { colSpan: 5, className: "px-4 py-3", children: /* @__PURE__ */ jsxs10("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsx12("div", { className: "flex h-6 w-6 items-center justify-center rounded-md bg-blue-200 dark:bg-blue-800", children: /* @__PURE__ */ jsx12(FolderOpen2, { className: "h-3.5 w-3.5" }) }),
                /* @__PURE__ */ jsx12("span", { children: projectName }),
                /* @__PURE__ */ jsxs10("span", { className: "rounded-full bg-blue-200 px-2 py-0.5 text-xs font-semibold text-blue-700 dark:bg-blue-800 dark:text-blue-300", children: [
                  tasksForProject.length,
                  " task",
                  tasksForProject.length === 1 ? "" : "s"
                ] })
              ] }) }) }),
              tasksForProject.slice().sort((a, b) => {
                const aPriority = priorityOrder[normalizePriority(a.priority)] ?? 3;
                const bPriority = priorityOrder[normalizePriority(b.priority)] ?? 3;
                if (aPriority !== bPriority) {
                  return aPriority - bPriority;
                }
                return a.text.localeCompare(b.text);
              }).map((task) => {
                const priority = normalizePriority(task.priority);
                const priorityClass = getPriorityBadgeClass(priority);
                const selectedBy = getSelectedByToday(task);
                const isSelectedByMe = isTaskSelectedByMeToday(task);
                const isSelectedByAnyone = selectedBy.length > 0;
                const sharedEmails = getSharedEmails(task.sharedWith);
                const isSelectedByOthers = selectedBy.length > 0 && !isSelectedByMe;
                const isSelectionLocked = isSelectedByOthers;
                const normalizedStatus = (task.status || "").toLowerCase();
                const isRunning = normalizedStatus === "in progress" || normalizedStatus === "in-progress" || normalizedStatus === "running";
                const checkboxClasses = cn("h-5 w-5 rounded-md border-2 transition-all", "data-[state=checked]:bg-blue-500 data-[state=checked]:border-blue-500 data-[state=checked]:text-white", "data-[state=checked]:shadow-sm data-[state=checked]:shadow-blue-500/50", (isSelectionLocked || isRunning) && "cursor-not-allowed opacity-60 data-[state=checked]:opacity-100 data-[state=unchecked]:opacity-40 data-[state=unchecked]:border-zinc-200 data-[state=unchecked]:bg-zinc-100 dark:data-[state=unchecked]:border-zinc-800 dark:data-[state=unchecked]:bg-zinc-900");
                return /* @__PURE__ */ jsxs10("tr", { className: cn("align-top transition-all duration-200", isSelectedByMe && "bg-emerald-50/90 dark:bg-emerald-900/30 border-l-4 border-l-emerald-500", !isSelectedByMe && selectedBy.length > 0 && "bg-sky-50/70 dark:bg-sky-900/30 border-l-4 border-l-sky-500", isRunning ? "opacity-70 bg-zinc-100/80 dark:bg-zinc-900/50" : "hover:bg-slate-50 dark:hover:bg-slate-800/50"), children: [
                  /* @__PURE__ */ jsx12("td", { className: "px-4 py-4 text-sm font-semibold text-blue-800 dark:text-blue-200", children: projectName }),
                  /* @__PURE__ */ jsx12("td", { className: "px-4 py-4", children: /* @__PURE__ */ jsx12("div", { className: "space-y-1.5", children: /* @__PURE__ */ jsxs10("div", { className: "flex flex-wrap items-center gap-2", children: [
                    /* @__PURE__ */ jsx12("span", { className: "font-semibold text-zinc-900 dark:text-zinc-100", children: task.text }),
                    typeof task.hrs === "number" && /* @__PURE__ */ jsxs10("span", { className: "rounded-md bg-blue-100 px-2 py-0.5 text-xs font-bold text-blue-700 dark:bg-blue-900/40 dark:text-blue-300", children: [
                      task.hrs,
                      "h"
                    ] })
                  ] }) }) }),
                  /* @__PURE__ */ jsx12("td", { className: "px-4 py-4", children: sharedEmails.length > 0 ? /* @__PURE__ */ jsx12("div", { className: "flex flex-wrap items-center gap-1.5", children: sharedEmails.map((email) => /* @__PURE__ */ jsx12(Badge, { variant: "outline", className: "text-xs border-slate-300 dark:border-slate-700", children: getDisplayName(email) }, email)) }) : /* @__PURE__ */ jsx12("span", { className: "text-xs text-zinc-400 dark:text-zinc-500", children: "\u2014" }) }),
                  /* @__PURE__ */ jsx12("td", { className: "px-4 py-4", children: /* @__PURE__ */ jsx12("span", { className: cn("inline-flex items-center rounded-lg px-2.5 py-1 text-xs font-bold capitalize shadow-sm", priorityClass), children: priority }) }),
                  /* @__PURE__ */ jsx12("td", { className: "px-4 py-4", children: /* @__PURE__ */ jsxs10("div", { className: "flex flex-wrap items-center justify-center gap-2", children: [
                    /* @__PURE__ */ jsx12(Checkbox, { checked: isSelectedByAnyone, disabled: isSelectionLocked || isRunning, onCheckedChange: () => {
                      if (isSelectionLocked || isRunning) {
                        return;
                      }
                      handleToggleSelection(task);
                    }, className: checkboxClasses, "aria-label": `Toggle selection for ${task.text}` }),
                    selectedBy.length > 0 ? /* @__PURE__ */ jsx12("div", { className: "flex flex-wrap items-center gap-1.5", children: selectedBy.map((selection, idx) => /* @__PURE__ */ jsx12(Badge, { variant: selection.email === session?.user?.email ? "default" : "outline", className: cn("text-xs font-semibold shadow-sm transition-all", selection.email === session?.user?.email ? "bg-emerald-500 text-white hover:bg-emerald-600 border-emerald-600" : "border-slate-300 dark:border-slate-700"), children: selection.email === session?.user?.email ? "You" : getDisplayName(selection.email) }, idx)) }) : /* @__PURE__ */ jsx12("span", { className: "text-xs text-zinc-400 dark:text-zinc-500", children: "\u2014" })
                  ] }) })
                ] }, task._id);
              })
            ] }, projectName);
          }) })
        ] }) }) })
      ] })
    ] }),
    sessionActive && /* @__PURE__ */ jsxs10(Card, { className: "border border-emerald-200/80 shadow-xl shadow-emerald-500/10 dark:border-emerald-900/40 dark:shadow-emerald-500/20", children: [
      /* @__PURE__ */ jsx12(CardHeader, { className: "border-b border-emerald-100/80 bg-gradient-to-br from-white via-emerald-50/40 to-white dark:border-emerald-900/40 dark:from-slate-900 dark:via-emerald-900/20 dark:to-slate-900", children: /* @__PURE__ */ jsxs10("div", { className: "flex flex-wrap items-center justify-between gap-4", children: [
        /* @__PURE__ */ jsxs10("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxs10(CardTitle, { className: "flex items-center gap-3 text-xl font-bold text-zinc-900 dark:text-zinc-50", children: [
            /* @__PURE__ */ jsx12("div", { className: "flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-100 dark:bg-emerald-900/40", children: /* @__PURE__ */ jsx12(Play2, { className: "h-5 w-5 text-emerald-600 dark:text-emerald-400" }) }),
            "Live Run"
          ] }),
          /* @__PURE__ */ jsxs10(CardDescription, { className: "text-sm text-emerald-700 dark:text-emerald-300 space-y-2", children: [
            /* @__PURE__ */ jsxs10("div", { className: "flex items-start gap-2", children: [
              /* @__PURE__ */ jsx12("span", { className: "mt-0.5 text-emerald-500 dark:text-emerald-400", children: "\u2022" }),
              /* @__PURE__ */ jsx12("span", { children: "Show all selected tasks from Task List." })
            ] }),
            /* @__PURE__ */ jsxs10("div", { className: "flex items-start gap-2", children: [
              /* @__PURE__ */ jsx12("span", { className: "mt-0.5 text-emerald-500 dark:text-emerald-400", children: "\u2022" }),
              /* @__PURE__ */ jsx12("span", { children: "Click on Start to start running a task, and hit Complete when done." })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs10("div", { className: "rounded-xl bg-emerald-100 px-4 py-2 text-sm font-bold text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300", children: [
          mySelectedTasks.length,
          " task",
          mySelectedTasks.length === 1 ? "" : "s",
          " in focus"
        ] })
      ] }) }),
      /* @__PURE__ */ jsx12(CardContent, { className: "p-6", children: mySelectedTasks.length === 0 ? /* @__PURE__ */ jsx12("div", { className: "rounded-xl border border-dashed border-emerald-200 bg-emerald-50/60 p-8 text-center dark:border-emerald-900 dark:bg-emerald-900/20", children: /* @__PURE__ */ jsxs10("div", { className: "flex flex-col items-center gap-3", children: [
        /* @__PURE__ */ jsx12("div", { className: "flex h-12 w-12 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-900/40", children: /* @__PURE__ */ jsx12(Play2, { className: "h-6 w-6 text-emerald-600 dark:text-emerald-400" }) }),
        /* @__PURE__ */ jsx12("p", { className: "text-sm font-semibold text-emerald-700 dark:text-emerald-300", children: "Select at least one task to begin tracking." })
      ] }) }) : /* @__PURE__ */ jsx12("div", { className: "overflow-hidden rounded-xl border border-emerald-100/80 shadow-lg dark:border-emerald-900/40", children: /* @__PURE__ */ jsxs10("table", { className: "min-w-full border-collapse", children: [
        /* @__PURE__ */ jsx12("thead", { className: "bg-emerald-50/90 text-xs font-bold uppercase tracking-wider text-emerald-700 dark:bg-emerald-900/50 dark:text-emerald-200", children: /* @__PURE__ */ jsxs10("tr", { children: [
          /* @__PURE__ */ jsx12("th", { className: "px-4 py-3 text-left", children: "Task" }),
          /* @__PURE__ */ jsx12("th", { className: "px-4 py-3 text-left", children: "Status" }),
          /* @__PURE__ */ jsx12("th", { className: "px-4 py-3 text-left", children: "Time Logged" }),
          /* @__PURE__ */ jsx12("th", { className: "px-4 py-3 text-right", children: "Actions" })
        ] }) }),
        /* @__PURE__ */ jsx12("tbody", { className: "bg-white text-sm dark:bg-slate-900", children: mySelectedTasks.map((task) => {
          const projectName = getProjectName(task);
          const isRunning = task.status === "in-progress" && !!task.startedAt;
          const isCompleted = task.status === "done";
          const totalTracked = computeTrackedTime(task);
          const formattedTime = formatDuration(totalTracked);
          const statusLabel = isCompleted ? "Completed" : isRunning ? "In Progress" : "Ready";
          const statusBadgeClass = cn("inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold capitalize", isCompleted ? "bg-emerald-500 text-white" : isRunning ? "bg-sky-500 text-white" : "bg-zinc-200 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-200");
          return /* @__PURE__ */ jsxs10("tr", { className: cn("border-t border-emerald-100/80 dark:border-emerald-900/40 align-top transition-all duration-200", isRunning && "bg-emerald-50/70 dark:bg-emerald-900/20", isCompleted && "bg-emerald-500/10 dark:bg-emerald-900/30", !isCompleted && !isRunning && "hover:bg-slate-50 dark:hover:bg-slate-800/50"), children: [
            /* @__PURE__ */ jsx12("td", { className: "px-4 py-4", children: /* @__PURE__ */ jsx12("div", { className: "space-y-2", children: /* @__PURE__ */ jsxs10("div", { className: "flex flex-wrap items-center gap-2", children: [
              /* @__PURE__ */ jsx12("span", { className: "font-semibold text-zinc-900 dark:text-zinc-100", children: task.text }),
              /* @__PURE__ */ jsx12("span", { className: "text-xs font-medium text-zinc-500 dark:text-zinc-400", children: projectName }),
              typeof task.hrs === "number" && /* @__PURE__ */ jsxs10(Badge, { variant: "outline", className: "text-xs border-slate-300 dark:border-slate-700", children: [
                task.hrs,
                "h"
              ] })
            ] }) }) }),
            /* @__PURE__ */ jsx12("td", { className: "px-4 py-4", children: /* @__PURE__ */ jsx12("span", { className: cn(statusBadgeClass, "shadow-sm"), children: statusLabel }) }),
            /* @__PURE__ */ jsx12("td", { className: "px-4 py-4 font-mono text-sm font-semibold text-zinc-700 dark:text-zinc-300", children: formattedTime }),
            /* @__PURE__ */ jsx12("td", { className: "px-4 py-4", children: /* @__PURE__ */ jsxs10("div", { className: "flex items-center justify-end gap-2", children: [
              !isRunning && !isCompleted && /* @__PURE__ */ jsxs10(Button, { variant: "outline", size: "sm", onClick: () => handleStartTaskRun(task), className: "gap-1.5 border-slate-300 dark:border-slate-700 transition-all hover:scale-105", children: [
                /* @__PURE__ */ jsx12(Play2, { className: "h-3.5 w-3.5" }),
                "Start"
              ] }),
              isRunning && /* @__PURE__ */ jsxs10(Button, { variant: "outline", size: "sm", onClick: () => handleStopTaskRun(task), className: "gap-1.5 border-red-300 text-red-600 hover:bg-red-50 dark:border-red-800 dark:text-red-400 dark:hover:bg-red-900/20 transition-all hover:scale-105", children: [
                /* @__PURE__ */ jsx12(Square, { className: "h-3.5 w-3.5" }),
                "Stop"
              ] }),
              /* @__PURE__ */ jsxs10(Button, { size: "sm", onClick: () => handleCompleteTaskRun(task), disabled: isCompleted, className: cn("gap-1.5 font-semibold shadow-sm transition-all hover:scale-105 active:scale-100", isCompleted ? "bg-emerald-500/20 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-200 cursor-default" : "bg-emerald-500 text-white hover:bg-emerald-600"), children: [
                /* @__PURE__ */ jsx12(CheckCircle, { className: "h-3.5 w-3.5" }),
                isCompleted ? "Completed" : "Complete"
              ] })
            ] }) })
          ] }, task._id);
        }) })
      ] }) }) })
    ] })
  ] });
}
var priorityOrder, normalizePriority, getPriorityBadgeClass, formatDuration;
var init_live_DxNKWXXM = __esm({
  "dist/server/assets/live-DxNKWXXM.js"() {
    "use strict";
    init_api_DiONElen();
    init_router_BrR6fF9p();
    init_app_header_DDCic_DU();
    init_select_CNs7Rl3z();
    init_checkbox_7uLehv8l();
    priorityOrder = {
      high: 0,
      medium: 1,
      low: 2
    };
    normalizePriority = (priority) => {
      const value = String(priority ?? "low").toLowerCase().trim();
      if (value === "high" || value === "medium" || value === "low") {
        return value;
      }
      return "low";
    };
    getPriorityBadgeClass = (priority) => {
      switch (priority) {
        case "high":
          return "bg-red-500/10 text-red-600 border border-red-200 dark:border-red-900/60 dark:text-red-300";
        case "medium":
          return "bg-blue-500/10 text-blue-600 border border-blue-200 dark:border-blue-900/60 dark:text-blue-300";
        default:
          return "bg-zinc-500/10 text-zinc-600 border border-zinc-200 dark:border-zinc-800 dark:text-zinc-300";
      }
    };
    formatDuration = (milliseconds) => {
      if (!milliseconds || milliseconds <= 0) {
        return "00:00";
      }
      const totalSeconds = Math.floor(milliseconds / 1e3);
      const hours = Math.floor(totalSeconds / 3600);
      const minutes = Math.floor(totalSeconds % 3600 / 60);
      return [hours, minutes].map((value) => String(value).padStart(2, "0")).join(":");
    };
  }
});

// dist/server/assets/router-BrR6fF9p.js
var router_BrR6fF9p_exports = {};
__export(router_BrR6fF9p_exports, {
  B: () => Badge,
  C: () => Card,
  R: () => Route$8,
  a: () => CardHeader,
  b: () => CardTitle,
  c: () => CardContent,
  d: () => CardDescription,
  r: () => router,
  u: () => useSession2
});
import { jsx as jsx13, jsxs as jsxs11 } from "react/jsx-runtime";
import { createRootRouteWithContext as createRootRouteWithContext2, useRouteContext as useRouteContext2, Outlet as Outlet3, HeadContent as HeadContent2, Scripts as Scripts2, createFileRoute, lazyRouteComponent, useNavigate as useNavigate4, useSearch as useSearch2, Link as Link4, createRouter } from "@tanstack/react-router";
import { ConvexBetterAuthProvider as ConvexBetterAuthProvider2 } from "@convex-dev/better-auth/react";
import { fetchSession as fetchSession2, getCookieName as getCookieName2, reactStartHandler } from "@convex-dev/better-auth/react-start";
import { useEffect as useEffect9 } from "react";
import { Loader2 as Loader23 } from "lucide-react";
import { toast as toast5 } from "sonner";
import { useConvexMutation as useConvexMutation5, ConvexQueryClient } from "@convex-dev/react-query";
import "clsx";
import { Slot as Slot2 } from "@radix-ui/react-slot";
import { cva as cva4 } from "class-variance-authority";
import { routerWithQueryClient } from "@tanstack/react-router-with-query";
import { ConvexReactClient, ConvexProvider } from "convex/react";
import { QueryClient } from "@tanstack/react-query";
function RootComponent2() {
  const context = useRouteContext2({
    from: Route$9.id
  });
  return /* @__PURE__ */ jsx13(ConvexBetterAuthProvider2, { client: context.convexClient, authClient, children: /* @__PURE__ */ jsx13(RootDocument2, { children: /* @__PURE__ */ jsx13(Outlet3, {}) }) });
}
function RootDocument2({
  children
}) {
  return /* @__PURE__ */ jsxs11("html", { lang: "en", className: "h-full", children: [
    /* @__PURE__ */ jsxs11("head", { children: [
      /* @__PURE__ */ jsx13("script", { dangerouslySetInnerHTML: {
        __html: `
              (function() {
                const stored = localStorage.getItem('theme');
                const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
                const shouldUseDark = stored === 'dark' || (!stored && prefersDark);
                if (shouldUseDark) {
                  document.documentElement.classList.add('dark');
                }
              })();
            `
      } }),
      /* @__PURE__ */ jsx13(HeadContent2, {})
    ] }),
    /* @__PURE__ */ jsxs11("body", { className: "h-full", children: [
      /* @__PURE__ */ jsx13(AppHeader, {}),
      /* @__PURE__ */ jsx13("main", { className: "w-full", children }),
      /* @__PURE__ */ jsx13(Scripts2, {})
    ] })
  ] });
}
function useSession2() {
  const {
    data: session
  } = authClient.useSession();
  return session;
}
function Card({ className, ...props }) {
  return /* @__PURE__ */ jsx13(
    "div",
    {
      "data-slot": "card",
      className: cn(
        "bg-card text-card-foreground flex flex-col gap-6 rounded-xl border py-6 shadow-sm",
        className
      ),
      ...props
    }
  );
}
function CardHeader({ className, ...props }) {
  return /* @__PURE__ */ jsx13(
    "div",
    {
      "data-slot": "card-header",
      className: cn(
        "@container/card-header grid auto-rows-min grid-rows-[auto_auto] items-start gap-2 px-6 has-data-[slot=card-action]:grid-cols-[1fr_auto] [.border-b]:pb-6",
        className
      ),
      ...props
    }
  );
}
function CardTitle({ className, ...props }) {
  return /* @__PURE__ */ jsx13(
    "div",
    {
      "data-slot": "card-title",
      className: cn("leading-none font-semibold", className),
      ...props
    }
  );
}
function CardDescription({ className, ...props }) {
  return /* @__PURE__ */ jsx13(
    "div",
    {
      "data-slot": "card-description",
      className: cn("text-muted-foreground text-sm", className),
      ...props
    }
  );
}
function CardContent({ className, ...props }) {
  return /* @__PURE__ */ jsx13(
    "div",
    {
      "data-slot": "card-content",
      className: cn("px-6", className),
      ...props
    }
  );
}
function InvitationResponse() {
  const navigate = useNavigate4();
  const { token, action } = useSearch2({ from: "/email/invitation-response" });
  const acceptInvitation = useConvexMutation5(api.projects.acceptProjectInvitation);
  const declineInvitation = useConvexMutation5(api.projects.declineProjectInvitation);
  const isAccepting = action === "accept";
  useEffect9(() => {
    if (!token) {
      toast5.error("Invalid or missing invitation token.");
      navigate({ to: "/project" });
      return;
    }
    const respond = async () => {
      try {
        if (isAccepting) {
          const result = await acceptInvitation({ token });
          toast5.success(result.message ?? "Invitation accepted!");
        } else {
          const result = await declineInvitation({ token });
          toast5.success(result.message ?? "Invitation declined.");
        }
      } catch (error) {
        const message = error instanceof Error ? error.message : "Failed to process invitation.";
        toast5.error(message);
      } finally {
        setTimeout(() => {
          navigate({ to: "/project" });
        }, 2e3);
      }
    };
    void respond();
  }, [acceptInvitation, declineInvitation, isAccepting, navigate, token]);
  return /* @__PURE__ */ jsx13("div", { className: "min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center p-4", children: /* @__PURE__ */ jsxs11(Card, { className: "w-full max-w-md", children: [
    /* @__PURE__ */ jsx13(CardHeader, { className: "text-center", children: /* @__PURE__ */ jsxs11(CardTitle, { className: "flex items-center justify-center gap-2", children: [
      /* @__PURE__ */ jsx13(Loader23, { className: "h-6 w-6 animate-spin" }),
      isAccepting ? "Accepting invitation..." : "Declining invitation..."
    ] }) }),
    /* @__PURE__ */ jsxs11(CardContent, { className: "text-center space-y-4", children: [
      /* @__PURE__ */ jsx13("p", { className: "text-sm text-gray-600 dark:text-gray-400", children: "We're finishing up. You'll be redirected to your projects shortly." }),
      /* @__PURE__ */ jsx13(Button, { onClick: () => navigate({ to: "/project" }), variant: "outline", className: "w-full", children: "Go to Projects" })
    ] })
  ] }) });
}
function Badge({
  className,
  variant,
  asChild = false,
  ...props
}) {
  const Comp = asChild ? Slot2 : "span";
  return /* @__PURE__ */ jsx13(
    Comp,
    {
      "data-slot": "badge",
      className: cn(badgeVariants({ variant }), className),
      ...props
    }
  );
}
function getConvexSiteUrl() {
  let convexSiteUrl = "https://app.cogrind.workers.dev";
  return convexSiteUrl;
}
async function handleAuthRequest({ request }) {
  try {
    const convexSiteUrl = getConvexSiteUrl();
    const url = new URL(request.url);
    console.log("Auth request:", {
      path: url.pathname,
      method: request.method,
      convexSiteUrl: convexSiteUrl ? "set" : "missing",
      origin: request.headers.get("origin")
    });
    if (!convexSiteUrl) ;
    const response = await reactStartHandler(request, { convexSiteUrl });
    if (response.status >= 400) {
      const responseClone = response.clone();
      const responseText = await responseClone.text();
      console.error("Auth handler error response:", {
        status: response.status,
        statusText: response.statusText,
        headers: Object.fromEntries(response.headers.entries()),
        body: responseText.substring(0, 500)
        // First 500 chars
      });
    }
    const headers = new Headers(response.headers);
    if (!headers.has("Access-Control-Allow-Origin")) {
      headers.set("Access-Control-Allow-Origin", "*");
    }
    if (!headers.has("Access-Control-Allow-Methods")) {
      headers.set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    }
    if (!headers.has("Access-Control-Allow-Headers")) {
      headers.set("Access-Control-Allow-Headers", "Content-Type, Authorization");
    }
    return new Response(response.body, {
      status: response.status,
      statusText: response.statusText,
      headers
    });
  } catch (error) {
    console.error("Auth handler error:", error);
    return new Response(
      JSON.stringify({
        error: error instanceof Error ? error.message : "Internal server error",
        type: error instanceof Error ? error.constructor.name : "Unknown"
      }),
      {
        status: 500,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        }
      }
    );
  }
}
async function handleOptions() {
  return new Response(null, {
    status: 204,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Access-Control-Max-Age": "86400"
    }
  });
}
function DefaultNotFound() {
  return /* @__PURE__ */ jsxs11("div", { className: "space-y-2 p-2", children: [
    /* @__PURE__ */ jsx13("p", { children: "The page you are looking for does not exist." }),
    /* @__PURE__ */ jsxs11("p", { className: "flex flex-wrap items-center gap-2", children: [
      /* @__PURE__ */ jsx13(Button, { type: "button", onClick: () => window.history.back(), children: "Go back" }),
      /* @__PURE__ */ jsx13(Button, { asChild: true, variant: "secondary", children: /* @__PURE__ */ jsx13(Link4, { to: "/", children: "Home" }) })
    ] })
  ] });
}
function getRouter() {
  const CONVEX_URL = "https://utmost-swan-132.convex.cloud";
  const convex2 = new ConvexReactClient(CONVEX_URL, {
    unsavedChangesWarning: false
  });
  const convexQueryClient = new ConvexQueryClient(convex2);
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        queryKeyHashFn: convexQueryClient.hashFn(),
        queryFn: convexQueryClient.queryFn(),
        staleTime: 3e4,
        // Consider data fresh for 30 seconds
        refetchOnWindowFocus: false,
        // Disable refetch on window focus to reduce updates
        refetchOnReconnect: true,
        // Still refetch on reconnect
        refetchOnMount: false
        // Don't refetch on mount if data exists
      }
    }
  });
  convexQueryClient.connect(queryClient);
  const router2 = routerWithQueryClient(
    createRouter({
      routeTree,
      defaultPreload: "intent",
      scrollRestoration: true,
      context: { queryClient, convexClient: convex2, convexQueryClient },
      Wrap: ({ children }) => /* @__PURE__ */ jsx13(ConvexProvider, { client: convexQueryClient.convexClient, children }),
      defaultNotFoundComponent: DefaultNotFound
    }),
    queryClient
  );
  return router2;
}
var createSsrRpc, fetchAuth_createServerFn_handler2, fetchAuth2, Route$9, $$splitComponentImporter$6, Route$8, $$splitComponentImporter$5, Route$7, $$splitComponentImporter$4, Route$6, $$splitComponentImporter$3, Route$5, Route$4, $$splitComponentImporter$2, Route$3, badgeVariants, $$splitComponentImporter$1, Route$2, $$splitComponentImporter, Route$1, Route2, authenticatedRouteRoute, IndexRoute, LoginIndexRoute, LoginCallbackRoute, EmailInvitationResponseRoute, authenticatedRefineRoute, authenticatedProjectRoute, authenticatedLiveRoute, ApiAuthSplatRoute, authenticatedRouteRouteChildren, authenticatedRouteRouteWithChildren, rootRouteChildren, routeTree, router;
var init_router_BrR6fF9p = __esm({
  "dist/server/assets/router-BrR6fF9p.js"() {
    "use strict";
    init_server();
    init_app_header_DDCic_DU();
    init_api_DiONElen();
    createSsrRpc = (functionId) => {
      const url = "/_serverFn/" + functionId;
      const fn = async (...args) => {
        const serverFn = await getServerFnById(functionId);
        return serverFn(...args);
      };
      return Object.assign(fn, {
        url,
        functionId,
        [TSS_SERVER_FUNCTION]: true
      });
    };
    fetchAuth_createServerFn_handler2 = createSsrRpc("6154ff9ba122adcee8332d695693036b02edeab9765af4af6c11e985f19736d6");
    fetchAuth2 = createServerFn({
      method: "GET"
    }).handler(fetchAuth_createServerFn_handler2, async () => {
      const {
        createAuth: createAuth2
      } = await Promise.resolve().then(() => (init_auth_BOVWFHt3(), auth_BOVWFHt3_exports));
      const {
        session
      } = await fetchSession2(getRequest());
      const sessionCookieName = getCookieName2(createAuth2);
      const token = getCookie(sessionCookieName);
      return {
        userId: session?.user.id,
        token
      };
    });
    Route$9 = createRootRouteWithContext2()({
      head: () => ({
        meta: [{
          charSet: "utf-8"
        }, {
          name: "viewport",
          content: "width=device-width, initial-scale=1"
        }],
        links: [{
          rel: "icon",
          href: "/favicon.ico"
        }]
      }),
      beforeLoad: async (ctx) => {
        const {
          userId,
          token
        } = await fetchAuth2();
        if (token) {
          ctx.context.convexQueryClient.serverHttpClient?.setAuth(token);
        }
        return {
          userId,
          token
        };
      },
      component: RootComponent2
    });
    $$splitComponentImporter$6 = () => Promise.resolve().then(() => (init_route_BR6Ftn3K(), route_BR6Ftn3K_exports));
    Route$8 = createFileRoute("/(authenticated)")({
      component: lazyRouteComponent($$splitComponentImporter$6, "component")
    });
    $$splitComponentImporter$5 = () => Promise.resolve().then(() => (init_index_ClHeH7Ce(), index_ClHeH7Ce_exports));
    Route$7 = createFileRoute("/")({
      component: lazyRouteComponent($$splitComponentImporter$5, "component")
    });
    $$splitComponentImporter$4 = () => Promise.resolve().then(() => (init_index_x2YHdY2P(), index_x2YHdY2P_exports));
    Route$6 = createFileRoute("/login/")({
      component: lazyRouteComponent($$splitComponentImporter$4, "component")
    });
    $$splitComponentImporter$3 = () => Promise.resolve().then(() => (init_callback_DfYxWBcJ(), callback_DfYxWBcJ_exports));
    Route$5 = createFileRoute("/login/callback")({
      component: lazyRouteComponent($$splitComponentImporter$3, "component"),
      validateSearch: (search) => {
        return {
          redirect: search.redirect || void 0
        };
      }
    });
    Route$4 = createFileRoute("/email/invitation-response")({
      component: InvitationResponse,
      validateSearch: (search) => ({
        token: search.token || "",
        action: search.action || "accept"
      })
    });
    $$splitComponentImporter$2 = () => Promise.resolve().then(() => (init_refine_D_ImU73t(), refine_D_ImU73t_exports));
    Route$3 = createFileRoute("/(authenticated)/refine")({
      component: lazyRouteComponent($$splitComponentImporter$2, "component")
    });
    badgeVariants = cva4(
      "inline-flex items-center justify-center rounded-full border px-2 py-0.5 text-xs font-medium w-fit whitespace-nowrap shrink-0 [&>svg]:size-3 gap-1 [&>svg]:pointer-events-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive transition-[color,box-shadow] overflow-hidden",
      {
        variants: {
          variant: {
            default: "border-transparent bg-primary text-primary-foreground [a&]:hover:bg-primary/90",
            secondary: "border-transparent bg-secondary text-secondary-foreground [a&]:hover:bg-secondary/90",
            destructive: "border-transparent bg-destructive text-white [a&]:hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",
            outline: "text-foreground [a&]:hover:bg-accent [a&]:hover:text-accent-foreground"
          }
        },
        defaultVariants: {
          variant: "default"
        }
      }
    );
    $$splitComponentImporter$1 = () => Promise.resolve().then(() => (init_project_jEc4sHYE(), project_jEc4sHYE_exports));
    Route$2 = createFileRoute("/(authenticated)/project")({
      component: lazyRouteComponent($$splitComponentImporter$1, "component")
    });
    $$splitComponentImporter = () => Promise.resolve().then(() => (init_live_DxNKWXXM(), live_DxNKWXXM_exports));
    Route$1 = createFileRoute("/(authenticated)/live")({
      component: lazyRouteComponent($$splitComponentImporter, "component")
    });
    Route2 = createFileRoute("/api/auth/$")({
      server: {
        handlers: {
          GET: handleAuthRequest,
          POST: handleAuthRequest,
          OPTIONS: handleOptions
        }
      }
    });
    authenticatedRouteRoute = Route$8.update({
      id: "/(authenticated)",
      getParentRoute: () => Route$9
    });
    IndexRoute = Route$7.update({
      id: "/",
      path: "/",
      getParentRoute: () => Route$9
    });
    LoginIndexRoute = Route$6.update({
      id: "/login/",
      path: "/login/",
      getParentRoute: () => Route$9
    });
    LoginCallbackRoute = Route$5.update({
      id: "/login/callback",
      path: "/login/callback",
      getParentRoute: () => Route$9
    });
    EmailInvitationResponseRoute = Route$4.update({
      id: "/email/invitation-response",
      path: "/email/invitation-response",
      getParentRoute: () => Route$9
    });
    authenticatedRefineRoute = Route$3.update({
      id: "/refine",
      path: "/refine",
      getParentRoute: () => authenticatedRouteRoute
    });
    authenticatedProjectRoute = Route$2.update({
      id: "/project",
      path: "/project",
      getParentRoute: () => authenticatedRouteRoute
    });
    authenticatedLiveRoute = Route$1.update({
      id: "/live",
      path: "/live",
      getParentRoute: () => authenticatedRouteRoute
    });
    ApiAuthSplatRoute = Route2.update({
      id: "/api/auth/$",
      path: "/api/auth/$",
      getParentRoute: () => Route$9
    });
    authenticatedRouteRouteChildren = {
      authenticatedLiveRoute,
      authenticatedProjectRoute,
      authenticatedRefineRoute
    };
    authenticatedRouteRouteWithChildren = authenticatedRouteRoute._addFileChildren(authenticatedRouteRouteChildren);
    rootRouteChildren = {
      IndexRoute,
      authenticatedRouteRoute: authenticatedRouteRouteWithChildren,
      EmailInvitationResponseRoute,
      LoginCallbackRoute,
      LoginIndexRoute,
      ApiAuthSplatRoute
    };
    routeTree = Route$9._addFileChildren(rootRouteChildren)._addFileTypes();
    router = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
      __proto__: null,
      getRouter
    }, Symbol.toStringTag, { value: "Module" }));
  }
});

// dist/server/assets/start-HYkvq4Ni.js
var start_HYkvq4Ni_exports = {};
__export(start_HYkvq4Ni_exports, {
  startInstance: () => startInstance
});
var startInstance;
var init_start_HYkvq4Ni = __esm({
  "dist/server/assets/start-HYkvq4Ni.js"() {
    "use strict";
    startInstance = void 0;
  }
});

// dist/server/server.js
import { createMemoryHistory } from "@tanstack/history";
import { mergeHeaders, json } from "@tanstack/router-core/ssr/client";
import { isRedirect, isNotFound, defaultSerovalPlugins, makeSerovalPlugin, rootRouteId, createSerializationAdapter, isResolvedRedirect, executeRewriteInput } from "@tanstack/router-core";
import { AsyncLocalStorage } from "node:async_hooks";
import { getOrigin, attachRouterServerSsrUtils } from "@tanstack/router-core/ssr/server";
import { H3Event, toResponse, parseCookies } from "h3-v2";
import invariant from "tiny-invariant";
import { toCrossJSONStream, toCrossJSONAsync, fromJSON } from "seroval";
import { jsx as jsx14 } from "react/jsx-runtime";
import { defineHandlerCallback, renderRouterToStream } from "@tanstack/react-router/ssr/server";
import { RouterProvider } from "@tanstack/react-router";
function StartServer(props) {
  return /* @__PURE__ */ jsx14(RouterProvider, { router: props.router });
}
async function runWithStartContext(context, fn) {
  return startStorage.run(context, fn);
}
function getStartContext(opts) {
  const context = startStorage.getStore();
  if (!context && opts?.throwIfNotFound !== false) {
    throw new Error(
      `No Start context found in AsyncLocalStorage. Make sure you are using the function within the server runtime.`
    );
  }
  return context;
}
async function executeMiddleware$1(middlewares, env, opts) {
  const globalMiddlewares = getStartOptions()?.functionMiddleware || [];
  const flattenedMiddlewares = flattenMiddlewares([
    ...globalMiddlewares,
    ...middlewares
  ]);
  const next = async (ctx) => {
    const nextMiddleware = flattenedMiddlewares.shift();
    if (!nextMiddleware) {
      return ctx;
    }
    if ("inputValidator" in nextMiddleware.options && nextMiddleware.options.inputValidator && env === "server") {
      ctx.data = await execValidator(
        nextMiddleware.options.inputValidator,
        ctx.data
      );
    }
    let middlewareFn = void 0;
    if (env === "client") {
      if ("client" in nextMiddleware.options) {
        middlewareFn = nextMiddleware.options.client;
      }
    } else if ("server" in nextMiddleware.options) {
      middlewareFn = nextMiddleware.options.server;
    }
    if (middlewareFn) {
      return applyMiddleware(middlewareFn, ctx, async (newCtx) => {
        return next(newCtx).catch((error) => {
          if (isRedirect(error) || isNotFound(error)) {
            return {
              ...newCtx,
              error
            };
          }
          throw error;
        });
      });
    }
    return next(ctx);
  };
  return next({
    ...opts,
    headers: opts.headers || {},
    sendContext: opts.sendContext || {},
    context: opts.context || {}
  });
}
function flattenMiddlewares(middlewares) {
  const seen = /* @__PURE__ */ new Set();
  const flattened = [];
  const recurse = (middleware) => {
    middleware.forEach((m) => {
      if (m.options.middleware) {
        recurse(m.options.middleware);
      }
      if (!seen.has(m)) {
        seen.add(m);
        flattened.push(m);
      }
    });
  };
  recurse(middlewares);
  return flattened;
}
function execValidator(validator, input) {
  if (validator == null) return {};
  if ("~standard" in validator) {
    const result = validator["~standard"].validate(input);
    if (result instanceof Promise)
      throw new Error("Async validation not supported");
    if (result.issues)
      throw new Error(JSON.stringify(result.issues, void 0, 2));
    return result.value;
  }
  if ("parse" in validator) {
    return validator.parse(input);
  }
  if (typeof validator === "function") {
    return validator(input);
  }
  throw new Error("Invalid validator type!");
}
function serverFnBaseToMiddleware(options) {
  return {
    _types: void 0,
    options: {
      inputValidator: options.inputValidator,
      client: async ({ next, sendContext, ...ctx }) => {
        const payload = {
          ...ctx,
          // switch the sendContext over to context
          context: sendContext
        };
        const res = await options.extractedFn?.(payload);
        return next(res);
      },
      server: async ({ next, ...ctx }) => {
        const result = await options.serverFn?.(ctx);
        return next({
          ...ctx,
          result
        });
      }
    }
  };
}
function getDefaultSerovalPlugins() {
  const start = getStartOptions();
  const adapters = start?.serializationAdapters;
  return [
    ...adapters?.map(makeSerovalPlugin) ?? [],
    ...defaultSerovalPlugins
  ];
}
function requestHandler(handler) {
  return (request, requestOpts) => {
    const h3Event = new H3Event(request);
    const response = eventStorage.run(
      { h3Event },
      () => handler(request, requestOpts)
    );
    return toResponse(response, h3Event);
  };
}
function getH3Event() {
  const event = eventStorage.getStore();
  if (!event) {
    throw new Error(
      `No StartEvent found in AsyncLocalStorage. Make sure you are using the function within the server runtime.`
    );
  }
  return event.h3Event;
}
function getRequest() {
  const event = getH3Event();
  return event.req;
}
function getCookies() {
  const event = getH3Event();
  return parseCookies(event);
}
function getCookie(name) {
  return getCookies()[name] || void 0;
}
function getResponse() {
  const event = getH3Event();
  return event._res;
}
async function getStartManifest() {
  const { tsrStartManifest: tsrStartManifest2 } = await Promise.resolve().then(() => (init_tanstack_start_manifest_v_1I4XAs5H(), tanstack_start_manifest_v_1I4XAs5H_exports));
  const startManifest = tsrStartManifest2();
  const rootRoute = startManifest.routes[rootRouteId] = startManifest.routes[rootRouteId] || {};
  rootRoute.assets = rootRoute.assets || [];
  let script = `import('${startManifest.clientEntry}')`;
  rootRoute.assets.push({
    tag: "script",
    attrs: {
      type: "module",
      suppressHydrationWarning: true,
      async: true
    },
    children: script
  });
  const manifest2 = {
    ...startManifest,
    routes: Object.fromEntries(
      Object.entries(startManifest.routes).map(([k, v]) => {
        const { preloads, assets } = v;
        const result = {};
        if (preloads) {
          result["preloads"] = preloads;
        }
        if (assets) {
          result["assets"] = assets;
        }
        return [k, result];
      })
    )
  };
  return manifest2;
}
async function getServerFnById(id) {
  const serverFnInfo = manifest[id];
  if (!serverFnInfo) {
    throw new Error("Server function info not found for " + id);
  }
  const fnModule = await serverFnInfo.importer();
  if (!fnModule) {
    console.info("serverFnInfo", serverFnInfo);
    throw new Error("Server function module not resolved for " + id);
  }
  const action = fnModule[serverFnInfo.functionName];
  if (!action) {
    console.info("serverFnInfo", serverFnInfo);
    console.info("fnModule", fnModule);
    throw new Error(
      `Server function module export not resolved for serverFn ID: ${id}`
    );
  }
  return action;
}
function isNotFoundResponse(error) {
  const { headers, ...rest } = error;
  return new Response(JSON.stringify(rest), {
    status: 404,
    headers: {
      "Content-Type": "application/json",
      ...headers || {}
    }
  });
}
function getStartResponseHeaders(opts) {
  const headers = mergeHeaders(
    {
      "Content-Type": "text/html; charset=utf-8"
    },
    ...opts.router.state.matches.map((match) => {
      return match.headers;
    })
  );
  return headers;
}
function createStartHandler(cb) {
  const ROUTER_BASEPATH = "/";
  let startRoutesManifest = null;
  let startEntry = null;
  let routerEntry = null;
  const getEntries = async () => {
    if (routerEntry === null) {
      routerEntry = await Promise.resolve().then(() => (init_router_BrR6fF9p(), router_BrR6fF9p_exports)).then((n) => n.r);
    }
    if (startEntry === null) {
      startEntry = await Promise.resolve().then(() => (init_start_HYkvq4Ni(), start_HYkvq4Ni_exports));
    }
    return {
      startEntry,
      routerEntry
    };
  };
  const originalFetch = globalThis.fetch;
  const startRequestResolver = async (request, requestOpts) => {
    const origin = getOrigin(request);
    globalThis.fetch = async function(input, init) {
      function resolve(url2, requestOptions) {
        const fetchRequest = new Request(url2, requestOptions);
        return startRequestResolver(fetchRequest, requestOpts);
      }
      if (typeof input === "string" && input.startsWith("/")) {
        const url2 = new URL(input, origin);
        return resolve(url2, init);
      } else if (typeof input === "object" && "url" in input && typeof input.url === "string" && input.url.startsWith("/")) {
        const url2 = new URL(input.url, origin);
        return resolve(url2, init);
      }
      return originalFetch(input, init);
    };
    const url = new URL(request.url);
    const href = url.href.replace(url.origin, "");
    let router2 = null;
    const getRouter2 = async () => {
      if (router2) return router2;
      router2 = await (await getEntries()).routerEntry.getRouter();
      const isPrerendering = process.env.TSS_PRERENDERING === "true";
      let isShell = process.env.TSS_SHELL === "true";
      if (isPrerendering && !isShell) {
        isShell = request.headers.get(HEADERS.TSS_SHELL) === "true";
      }
      const history = createMemoryHistory({
        initialEntries: [href]
      });
      router2.update({
        history,
        isShell,
        isPrerendering,
        origin: router2.options.origin ?? origin,
        ...{
          defaultSsr: startOptions.defaultSsr,
          serializationAdapters: [
            ...startOptions.serializationAdapters || [],
            ...router2.options.serializationAdapters || []
          ]
        },
        basepath: ROUTER_BASEPATH
      });
      return router2;
    };
    const startOptions = await (await getEntries()).startEntry.startInstance?.getOptions() || {};
    startOptions.serializationAdapters = startOptions.serializationAdapters || [];
    startOptions.serializationAdapters.push(ServerFunctionSerializationAdapter);
    const requestHandlerMiddleware = handlerToMiddleware(
      async ({ context }) => {
        const response2 = await runWithStartContext(
          {
            getRouter: getRouter2,
            startOptions,
            contextAfterGlobalMiddlewares: context,
            request
          },
          async () => {
            try {
              if (href.startsWith("/_serverFn/")) {
                return await handleServerAction({
                  request,
                  context: requestOpts?.context
                });
              }
              const executeRouter = async ({
                serverContext
              }) => {
                const requestAcceptHeader = request.headers.get("Accept") || "*/*";
                const splitRequestAcceptHeader = requestAcceptHeader.split(",");
                const supportedMimeTypes = ["*/*", "text/html"];
                const isRouterAcceptSupported = supportedMimeTypes.some(
                  (mimeType) => splitRequestAcceptHeader.some(
                    (acceptedMimeType) => acceptedMimeType.trim().startsWith(mimeType)
                  )
                );
                if (!isRouterAcceptSupported) {
                  return json(
                    {
                      error: "Only HTML requests are supported here"
                    },
                    {
                      status: 500
                    }
                  );
                }
                if (startRoutesManifest === null) {
                  startRoutesManifest = await getStartManifest();
                }
                const router22 = await getRouter2();
                attachRouterServerSsrUtils({
                  router: router22,
                  manifest: startRoutesManifest
                });
                router22.update({ additionalContext: { serverContext } });
                await router22.load();
                if (router22.state.redirect) {
                  return router22.state.redirect;
                }
                await router22.serverSsr.dehydrate();
                const responseHeaders = getStartResponseHeaders({ router: router22 });
                const response4 = await cb({
                  request,
                  router: router22,
                  responseHeaders
                });
                return response4;
              };
              const response3 = await handleServerRoutes({
                getRouter: getRouter2,
                request,
                executeRouter,
                context
              });
              return response3;
            } catch (err) {
              if (err instanceof Response) {
                return err;
              }
              throw err;
            }
          }
        );
        return response2;
      }
    );
    const flattenedMiddlewares = startOptions.requestMiddleware ? flattenMiddlewares(startOptions.requestMiddleware) : [];
    const middlewares = flattenedMiddlewares.map((d) => d.options.server);
    const ctx = await executeMiddleware(
      [...middlewares, requestHandlerMiddleware],
      {
        request,
        context: requestOpts?.context || {}
      }
    );
    const response = ctx.response;
    if (isRedirect(response)) {
      if (isResolvedRedirect(response)) {
        if (request.headers.get("x-tsr-redirect") === "manual") {
          return json(
            {
              ...response.options,
              isSerializedRedirect: true
            },
            {
              headers: response.headers
            }
          );
        }
        return response;
      }
      if (response.options.to && typeof response.options.to === "string" && !response.options.to.startsWith("/")) {
        throw new Error(
          `Server side redirects must use absolute paths via the 'href' or 'to' options. The redirect() method's "to" property accepts an internal path only. Use the "href" property to provide an external URL. Received: ${JSON.stringify(response.options)}`
        );
      }
      if (["params", "search", "hash"].some(
        (d) => typeof response.options[d] === "function"
      )) {
        throw new Error(
          `Server side redirects must use static search, params, and hash values and do not support functional values. Received functional values for: ${Object.keys(
            response.options
          ).filter((d) => typeof response.options[d] === "function").map((d) => `"${d}"`).join(", ")}`
        );
      }
      const router22 = await getRouter2();
      const redirect = router22.resolveRedirect(response);
      if (request.headers.get("x-tsr-redirect") === "manual") {
        return json(
          {
            ...response.options,
            isSerializedRedirect: true
          },
          {
            headers: response.headers
          }
        );
      }
      return redirect;
    }
    return response;
  };
  return requestHandler(startRequestResolver);
}
async function handleServerRoutes({
  getRouter: getRouter2,
  request,
  executeRouter,
  context
}) {
  const router2 = await getRouter2();
  let url = new URL(request.url);
  url = executeRewriteInput(router2.rewrite, url);
  const pathname = url.pathname;
  const { matchedRoutes, foundRoute, routeParams } = router2.getMatchedRoutes(
    pathname,
    void 0
  );
  const middlewares = flattenMiddlewares(
    matchedRoutes.flatMap((r) => r.options.server?.middleware).filter(Boolean)
  ).map((d) => d.options.server);
  const server2 = foundRoute?.options.server;
  if (server2) {
    if (server2.handlers) {
      const handlers = typeof server2.handlers === "function" ? server2.handlers({
        createHandlers: (d) => d
      }) : server2.handlers;
      const requestMethod = request.method.toUpperCase();
      const handler = handlers[requestMethod] ?? handlers["ANY"];
      if (handler) {
        const mayDefer = !!foundRoute.options.component;
        if (typeof handler === "function") {
          middlewares.push(handlerToMiddleware(handler, mayDefer));
        } else {
          const { middleware } = handler;
          if (middleware && middleware.length) {
            middlewares.push(
              ...flattenMiddlewares(middleware).map((d) => d.options.server)
            );
          }
          if (handler.handler) {
            middlewares.push(handlerToMiddleware(handler.handler, mayDefer));
          }
        }
      }
    }
  }
  middlewares.push(
    handlerToMiddleware((ctx2) => executeRouter({ serverContext: ctx2.context }))
  );
  const ctx = await executeMiddleware(middlewares, {
    request,
    context,
    params: routeParams,
    pathname
  });
  const response = ctx.response;
  return response;
}
function throwRouteHandlerError() {
  if (process.env.NODE_ENV === "development") {
    throw new Error(
      `It looks like you forgot to return a response from your server route handler. If you want to defer to the app router, make sure to have a component set in this route.`
    );
  }
  throw new Error("Internal Server Error");
}
function throwIfMayNotDefer() {
  if (process.env.NODE_ENV === "development") {
    throw new Error(
      `You cannot defer to the app router if there is no component defined on this route.`
    );
  }
  throw new Error("Internal Server Error");
}
function handlerToMiddleware(handler, mayDefer = false) {
  if (mayDefer) {
    return handler;
  }
  return async ({ next: _next, ...rest }) => {
    const response = await handler({ ...rest, next: throwIfMayNotDefer });
    if (!response) {
      throwRouteHandlerError();
    }
    return response;
  };
}
function executeMiddleware(middlewares, ctx) {
  let index = -1;
  const next = async (ctx2) => {
    index++;
    const middleware = middlewares[index];
    if (!middleware) return ctx2;
    let result;
    try {
      result = await middleware({
        ...ctx2,
        // Allow the middleware to call the next middleware in the chain
        next: async (nextCtx) => {
          const nextResult = await next({
            ...ctx2,
            ...nextCtx,
            context: {
              ...ctx2.context,
              ...nextCtx?.context || {}
            }
          });
          return Object.assign(ctx2, handleCtxResult(nextResult));
        }
        // Allow the middleware result to extend the return context
      });
    } catch (err) {
      if (isSpecialResponse(err)) {
        result = {
          response: err
        };
      } else {
        throw err;
      }
    }
    return Object.assign(ctx2, handleCtxResult(result));
  };
  return handleCtxResult(next(ctx));
}
function handleCtxResult(result) {
  if (isSpecialResponse(result)) {
    return {
      response: result
    };
  }
  return result;
}
function isSpecialResponse(err) {
  return isResponse(err) || isRedirect(err);
}
function isResponse(response) {
  return response instanceof Response;
}
function createServerEntry(entry) {
  return {
    async fetch(...args) {
      return await entry.fetch(...args);
    }
  };
}
var defaultStreamHandler, TSS_FORMDATA_CONTEXT, TSS_SERVER_FUNCTION, TSS_SERVER_FUNCTION_FACTORY, X_TSS_SERIALIZED, X_TSS_RAW_RESPONSE, startStorage, getStartOptions, getStartContextServerOnly, createServerFn, applyMiddleware, eventStorage, manifest, regex, handleServerAction, HEADERS, createServerRpc, ServerFunctionSerializationAdapter, fetch2, server;
var init_server = __esm({
  "dist/server/server.js"() {
    "use strict";
    defaultStreamHandler = defineHandlerCallback(
      ({ request, router: router2, responseHeaders }) => renderRouterToStream({
        request,
        router: router2,
        responseHeaders,
        children: /* @__PURE__ */ jsx14(StartServer, { router: router2 })
      })
    );
    TSS_FORMDATA_CONTEXT = "__TSS_CONTEXT";
    TSS_SERVER_FUNCTION = Symbol.for("TSS_SERVER_FUNCTION");
    TSS_SERVER_FUNCTION_FACTORY = Symbol.for(
      "TSS_SERVER_FUNCTION_FACTORY"
    );
    X_TSS_SERIALIZED = "x-tss-serialized";
    X_TSS_RAW_RESPONSE = "x-tss-raw";
    startStorage = new AsyncLocalStorage();
    getStartOptions = () => getStartContext().startOptions;
    getStartContextServerOnly = getStartContext;
    createServerFn = (options, __opts) => {
      const resolvedOptions = __opts || options || {};
      if (typeof resolvedOptions.method === "undefined") {
        resolvedOptions.method = "GET";
      }
      const res = {
        options: resolvedOptions,
        middleware: (middleware) => {
          const newMiddleware = [...resolvedOptions.middleware || []];
          middleware.map((m) => {
            if (TSS_SERVER_FUNCTION_FACTORY in m) {
              if (m.options.middleware) {
                newMiddleware.push(...m.options.middleware);
              }
            } else {
              newMiddleware.push(m);
            }
          });
          const newOptions = {
            ...resolvedOptions,
            middleware: newMiddleware
          };
          const res2 = createServerFn(void 0, newOptions);
          res2[TSS_SERVER_FUNCTION_FACTORY] = true;
          return res2;
        },
        inputValidator: (inputValidator) => {
          const newOptions = { ...resolvedOptions, inputValidator };
          return createServerFn(void 0, newOptions);
        },
        handler: (...args) => {
          const [extractedFn, serverFn] = args;
          const newOptions = { ...resolvedOptions, extractedFn, serverFn };
          const resolvedMiddleware = [
            ...newOptions.middleware || [],
            serverFnBaseToMiddleware(newOptions)
          ];
          return Object.assign(
            async (opts) => {
              return executeMiddleware$1(resolvedMiddleware, "client", {
                ...extractedFn,
                ...newOptions,
                data: opts?.data,
                headers: opts?.headers,
                signal: opts?.signal,
                context: {}
              }).then((d) => {
                if (d.error) throw d.error;
                return d.result;
              });
            },
            {
              // This copies over the URL, function ID
              ...extractedFn,
              // The extracted function on the server-side calls
              // this function
              __executeServer: async (opts, signal) => {
                const startContext = getStartContextServerOnly();
                const serverContextAfterGlobalMiddlewares = startContext.contextAfterGlobalMiddlewares;
                const ctx = {
                  ...extractedFn,
                  ...opts,
                  context: {
                    ...serverContextAfterGlobalMiddlewares,
                    ...opts.context
                  },
                  signal,
                  request: startContext.request
                };
                return executeMiddleware$1(resolvedMiddleware, "server", ctx).then(
                  (d) => ({
                    // Only send the result and sendContext back to the client
                    result: d.result,
                    error: d.error,
                    context: d.sendContext
                  })
                );
              }
            }
          );
        }
      };
      const fun = (options2) => {
        return {
          ...res,
          options: {
            ...res.options,
            ...options2
          }
        };
      };
      return Object.assign(fun, res);
    };
    applyMiddleware = async (middlewareFn, ctx, nextFn) => {
      return middlewareFn({
        ...ctx,
        next: async (userCtx = {}) => {
          return nextFn({
            ...ctx,
            ...userCtx,
            context: {
              ...ctx.context,
              ...userCtx.context
            },
            sendContext: {
              ...ctx.sendContext,
              ...userCtx.sendContext ?? {}
            },
            headers: mergeHeaders(ctx.headers, userCtx.headers),
            result: userCtx.result !== void 0 ? userCtx.result : userCtx instanceof Response ? userCtx : ctx.result,
            error: userCtx.error ?? ctx.error
          });
        }
      });
    };
    eventStorage = new AsyncLocalStorage();
    manifest = { "6154ff9ba122adcee8332d695693036b02edeab9765af4af6c11e985f19736d6": {
      functionName: "fetchAuth_createServerFn_handler",
      importer: () => Promise.resolve().then(() => (init_root_B0zzklJl(), root_B0zzklJl_exports))
    } };
    regex = void 0;
    handleServerAction = async ({
      request,
      context
    }) => {
      const controller = new AbortController();
      const signal = controller.signal;
      const abort = () => controller.abort();
      request.signal.addEventListener("abort", abort);
      if (regex === void 0) {
        regex = new RegExp(`${"/_serverFn/"}([^/?#]+)`);
      }
      const method = request.method;
      const url = new URL(request.url, "http://localhost:3000");
      const match = url.pathname.match(regex);
      const serverFnId = match ? match[1] : null;
      const search = Object.fromEntries(url.searchParams.entries());
      const isCreateServerFn = "createServerFn" in search;
      if (typeof serverFnId !== "string") {
        throw new Error("Invalid server action param for serverFnId: " + serverFnId);
      }
      const action = await getServerFnById(serverFnId);
      const formDataContentTypes = [
        "multipart/form-data",
        "application/x-www-form-urlencoded"
      ];
      const contentType = request.headers.get("Content-Type");
      const serovalPlugins = getDefaultSerovalPlugins();
      function parsePayload(payload) {
        const parsedPayload = fromJSON(payload, { plugins: serovalPlugins });
        return parsedPayload;
      }
      const response = await (async () => {
        try {
          let result = await (async () => {
            if (formDataContentTypes.some(
              (type) => contentType && contentType.includes(type)
            )) {
              invariant(
                method.toLowerCase() !== "get",
                "GET requests with FormData payloads are not supported"
              );
              const formData = await request.formData();
              const serializedContext = formData.get(TSS_FORMDATA_CONTEXT);
              formData.delete(TSS_FORMDATA_CONTEXT);
              const params = {
                context,
                data: formData
              };
              if (typeof serializedContext === "string") {
                try {
                  const parsedContext = JSON.parse(serializedContext);
                  if (typeof parsedContext === "object" && parsedContext) {
                    params.context = { ...context, ...parsedContext };
                  }
                } catch {
                }
              }
              return await action(params, signal);
            }
            if (method.toLowerCase() === "get") {
              invariant(
                isCreateServerFn,
                "expected GET request to originate from createServerFn"
              );
              let payload = search.payload;
              payload = payload ? parsePayload(JSON.parse(payload)) : {};
              payload.context = { ...context, ...payload.context };
              return await action(payload, signal);
            }
            if (method.toLowerCase() !== "post") {
              throw new Error("expected POST method");
            }
            let jsonPayload;
            if (contentType?.includes("application/json")) {
              jsonPayload = await request.json();
            }
            if (isCreateServerFn) {
              const payload = jsonPayload ? parsePayload(jsonPayload) : {};
              payload.context = { ...payload.context, ...context };
              return await action(payload, signal);
            }
            return await action(...jsonPayload);
          })();
          if (result.result instanceof Response) {
            result.result.headers.set(X_TSS_RAW_RESPONSE, "true");
            return result.result;
          }
          if (!isCreateServerFn) {
            result = result.result;
            if (result instanceof Response) {
              return result;
            }
          }
          if (isNotFound(result)) {
            return isNotFoundResponse(result);
          }
          const response2 = getResponse();
          let nonStreamingBody = void 0;
          if (result !== void 0) {
            let done = false;
            const callbacks = {
              onParse: (value) => {
                nonStreamingBody = value;
              },
              onDone: () => {
                done = true;
              },
              onError: (error) => {
                throw error;
              }
            };
            toCrossJSONStream(result, {
              refs: /* @__PURE__ */ new Map(),
              plugins: serovalPlugins,
              onParse(value) {
                callbacks.onParse(value);
              },
              onDone() {
                callbacks.onDone();
              },
              onError: (error) => {
                callbacks.onError(error);
              }
            });
            if (done) {
              return new Response(
                nonStreamingBody ? JSON.stringify(nonStreamingBody) : void 0,
                {
                  status: response2?.status,
                  statusText: response2?.statusText,
                  headers: {
                    "Content-Type": "application/json",
                    [X_TSS_SERIALIZED]: "true"
                  }
                }
              );
            }
            const stream = new ReadableStream({
              start(controller2) {
                callbacks.onParse = (value) => controller2.enqueue(JSON.stringify(value) + "\n");
                callbacks.onDone = () => {
                  try {
                    controller2.close();
                  } catch (error) {
                    controller2.error(error);
                  }
                };
                callbacks.onError = (error) => controller2.error(error);
                if (nonStreamingBody !== void 0) {
                  callbacks.onParse(nonStreamingBody);
                }
              }
            });
            return new Response(stream, {
              status: response2?.status,
              statusText: response2?.statusText,
              headers: {
                "Content-Type": "application/x-ndjson",
                [X_TSS_SERIALIZED]: "true"
              }
            });
          }
          return new Response(void 0, {
            status: response2?.status,
            statusText: response2?.statusText
          });
        } catch (error) {
          if (error instanceof Response) {
            return error;
          }
          if (isNotFound(error)) {
            return isNotFoundResponse(error);
          }
          console.info();
          console.info("Server Fn Error!");
          console.info();
          console.error(error);
          console.info();
          const serializedError = JSON.stringify(
            await Promise.resolve(
              toCrossJSONAsync(error, {
                refs: /* @__PURE__ */ new Map(),
                plugins: serovalPlugins
              })
            )
          );
          const response2 = getResponse();
          return new Response(serializedError, {
            status: response2?.status ?? 500,
            statusText: response2?.statusText,
            headers: {
              "Content-Type": "application/json",
              [X_TSS_SERIALIZED]: "true"
            }
          });
        }
      })();
      request.signal.removeEventListener("abort", abort);
      return response;
    };
    HEADERS = {
      TSS_SHELL: "X-TSS_SHELL"
    };
    createServerRpc = (functionId, splitImportFn) => {
      return Object.assign(splitImportFn, {
        functionId,
        [TSS_SERVER_FUNCTION]: true
      });
    };
    ServerFunctionSerializationAdapter = createSerializationAdapter({
      key: "$TSS/serverfn",
      test: (v) => {
        if (typeof v !== "function") return false;
        if (!(TSS_SERVER_FUNCTION in v)) return false;
        return !!v[TSS_SERVER_FUNCTION];
      },
      toSerializable: ({ functionId }) => ({ functionId }),
      fromSerializable: ({ functionId }) => {
        const fn = async (opts, signal) => {
          const serverFn = await getServerFnById(functionId);
          const result = await serverFn(opts ?? {}, signal);
          return result.result;
        };
        return createServerRpc(functionId, fn);
      }
    });
    fetch2 = createStartHandler(defaultStreamHandler);
    server = createServerEntry({ fetch: fetch2 });
  }
});

// .netlify/v1/functions/server.mjs
init_server();
if (typeof server?.fetch !== "function") {
  console.error("The server entry point must have a default export with a property `fetch: (req: Request) => Promise<Response>`");
}
var server_default = server.fetch;
var config = {
  name: "@netlify/vite-plugin server handler",
  generator: "@netlify/vite-plugin@2.7.12",
  path: "/*",
  preferStatic: true
};
export {
  config,
  server_default as default
};
